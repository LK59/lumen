"use strict";
(() => {
  // src/journal.ts
  var MIN_WAIT_MS = 250;
  var KEPT = 50;
  var PlaybackRecorder = class {
    entry;
    constructor(itemId, title) {
      this.entry = { itemId, title, player: "jellyfin", playMethod: null, transcodeReasons: null, refusal: null, audio: null, firstFrameMs: null, seeksMs: [], streamChangesMs: [], waits: 0, waitsMs: 0, watchedSeconds: 0, errors: 0 };
    }
    get itemId() {
      return this.entry.itemId;
    }
    /** Une image est-elle déjà venue ? Avant elle, tout arrêt fait partie de l'ouverture. */
    get opened() {
      return this.entry.firstFrameMs !== null;
    }
    /** Ce que le serveur sert pour ce flux — redit à chaque changement de flux, le dernier compte. */
    stream(facts) {
      Object.assign(this.entry, facts);
    }
    refused(reason) {
      this.entry.refusal = reason.slice(0, 300);
    }
    /** La première image d'un flux : celle de l'ouverture, ou celle qui suit un changement de flux. */
    frame(ms) {
      if (this.entry.firstFrameMs === null) this.entry.firstFrameMs = Math.round(ms);
      else if (this.entry.streamChangesMs.length < KEPT) this.entry.streamChangesMs.push(Math.round(ms));
    }
    seek(ms) {
      if (this.entry.seeksMs.length < KEPT) this.entry.seeksMs.push(Math.round(ms));
    }
    wait(ms) {
      if (ms < MIN_WAIT_MS) return;
      this.entry.waits += 1;
      this.entry.waitsMs += Math.round(ms);
    }
    watched(seconds) {
      if (seconds > 0 && seconds < 2) this.entry.watchedSeconds += seconds;
    }
    error() {
      this.entry.errors += 1;
    }
    finish() {
      return { ...this.entry, watchedSeconds: Math.round(this.entry.watchedSeconds) };
    }
  };
  function transcodeReasonsOf(url) {
    const match = /[?&]TranscodeReasons=([^&]+)/i.exec(url ?? "");
    return match ? decodeURIComponent(match[1]) : null;
  }

  // src/rules.ts
  var PLUGIN_NAME = "lumenPlayer";
  function eligible(item) {
    if (!item?.Id || item.MediaType !== "Video" || item.IsPlaceHolder) return false;
    if (item.LocationType && item.LocationType !== "FileSystem") return false;
    if (item.VideoType && item.VideoType !== "VideoFile") return false;
    return !["TvChannel", "LiveTvChannel", "Program", "LiveTvProgram", "Recording"].includes(item.Type ?? "");
  }
  function streamAddress(server, itemId, mediaSourceId) {
    return `${server.replace(/\/+$/, "")}/Videos/${encodeURIComponent(itemId)}/stream?static=true&mediaSourceId=${encodeURIComponent(mediaSourceId)}`;
  }
  function lumenProfile(base) {
    return { ...base, DirectPlayProfiles: [{ Type: "Video" }], CodecProfiles: [], ContainerProfiles: [] };
  }
  function audioTrackFor(streams, wantedIndex, trackNumbers) {
    if (wantedIndex === null || wantedIndex === void 0 || wantedIndex < 0) return null;
    const internal = (streams ?? []).filter((s) => s.Type === "Audio" && !s.IsExternal).sort((a, b) => (a.Index ?? 0) - (b.Index ?? 0));
    const rank = internal.findIndex((s) => s.Index === wantedIndex);
    if (rank < 0 || internal.length !== trackNumbers.length) return null;
    return trackNumbers[rank] ?? null;
  }

  // src/bridge.ts
  var w = window;
  var script = document.currentScript;
  var config = { enabled: true, base: script?.src ? new URL(".", script.src).href : new URL("lumen/", document.baseURI).href, build: "dev", ...w.LumenConfig ?? {} };
  var log = (...args) => console.info("[Lumen]", ...args);
  var states = /* @__PURE__ */ new WeakMap();
  var instance = null;
  var VERDICT_MS = 10 * 6e4;
  var CHECK_TIMEOUT_MS = 8e3;
  var core = null;
  function loadCore() {
    core ??= import(
      /* @vite-ignore */
      new URL("lumen-core.js", config.base).href
    ).catch((error) => {
      core = null;
      throw error;
    });
    return core;
  }
  var LumenPlayer = class {
    name = "Lumen";
    type = "mediaplayer";
    id = "lumenplayer";
    /** Avant le lecteur de jellyfin-web (1) : à type de média égal, le premier de la liste est pris. */
    priority = -1;
    isLocalPlayer = true;
    constructor(deps) {
      states.set(this, { deps, adopted: null, playback: null, opening: 0, verdicts: /* @__PURE__ */ new Map(), settings: /* @__PURE__ */ new Map(), recorder: null, recorderServerId: void 0, askedAt: null, element: null, busy: 0 });
      instance = this;
    }
    canPlayMediaType(mediaType) {
      return adopt(this) ? this.canPlayMediaType(mediaType) : false;
    }
    // jellyfin-web greffe `getVolume`/`setVolume` sur un lecteur qui ne les a pas, à l'enregistrement —
    // des propriétés de l'objet, qui masqueraient ensuite celles du lecteur adopté. Elles existent donc
    // d'avance ; rien ne les appelle tant que ce lecteur ne lit rien.
    getVolume() {
      return 100;
    }
    setVolume() {
    }
  };
  function adopt(self) {
    const state = states.get(self);
    if (state.adopted !== null) return state.adopted;
    const html = state.deps.playbackManager.getPlayers().find((player) => player.id === "htmlvideoplayer");
    if (!html) return false;
    const Base = html.constructor;
    const own = { ...self };
    const before = Object.getPrototypeOf(self);
    try {
      for (const name of ["getDeviceProfile", "setCurrentSrc", "play", "currentTime", "stop", "destroy", "canPlayMediaType"]) {
        if (typeof Base.prototype[name] !== "function") throw new Error(`le lecteur de jellyfin-web n'a pas de m\xE9thode \xAB ${name} \xBB`);
      }
      Object.setPrototypeOf(self, lumenPrototype(Base.prototype));
      Base.call(self);
      Object.assign(self, own);
      state.adopted = true;
      log("pr\xEAt \u2014 greff\xE9 sur le lecteur vid\xE9o de jellyfin-web");
    } catch (error) {
      Object.setPrototypeOf(self, before);
      state.adopted = false;
      console.warn("[Lumen] inactif : le lecteur vid\xE9o de cette version de jellyfin-web ne se laisse pas \xE9tendre \u2014", error);
    }
    return state.adopted;
  }
  function lumenPrototype(base) {
    return Object.assign(Object.create(base), {
      canPlayMediaType(mediaType) {
        return config.enabled && (mediaType ?? "").toLowerCase() === "video";
      },
      /** Seulement les fichiers vidéo de la bibliothèque : pour le reste, jellyfin-web prend son lecteur. */
      canPlayItem(item) {
        return config.enabled && eligible(item);
      },
      /**
       * Le profil annoncé au serveur — c'est ici que se décide qui lira.
       *
       * jellyfin-web le demande avant de négocier la lecture. On pose donc la question au moteur à ce
       * moment-là, sur le fichier : s'il le porte, le profil dit « lecture directe » et le serveur répond
       * par l'adresse du fichier brut ; s'il le refuse, le profil est celui de jellyfin-web et tout se
       * passe comme sans Lumen, transcodage compris. Le refus ne coûte ainsi ni erreur à l'écran ni
       * seconde négociation.
       *
       * `isRetry` : jellyfin-web renégocie après une erreur de lecture, pour obtenir un transcodage. Ce
       * n'est plus le moment de proposer le chemin qui vient d'échouer.
       */
      async getDeviceProfile(item, options) {
        const state = states.get(this);
        state.askedAt = performance.now();
        if (options?.isRetry) state.recorder?.error();
        const profile = await base.getDeviceProfile.call(this, item, options);
        if (!config.enabled || options?.isRetry || !eligible(item)) return profile;
        if (!(await settings(state, item)).enabled) return profile;
        const verdict = await check(this, item);
        return verdict?.ok ? lumenProfile(profile) : profile;
      },
      /**
       * La source. jellyfin-web appelle ceci avec l'élément `<video>` qu'il vient de créer et ce que le
       * serveur a répondu.
       *
       * Hors lecture directe d'un fichier accepté, c'est le lecteur de jellyfin-web tel quel. Sinon, sa
       * méthode est tout de même appelée — elle prépare les sous-titres, la piste son, l'état que le reste
       * du lecteur relit — mais sur un élément dont deux gestes sont détournés : poser `src` ne fait rien,
       * et `play()` ouvre Lumen sur le vrai élément avant de lancer la lecture. Un échec de l'ouverture
       * rejette `play()`, que jellyfin-web traite comme toute erreur de lecture : il renégocie.
       */
      /**
       * Le départ d'un flux : une ouverture, ou un changement de flux pendant la lecture (piste son,
       * qualité, repli). Rien n'est changé à ce que fait jellyfin-web ; le journal de la lecture s'ouvre ici.
       */
      async play(options) {
        const state = states.get(this);
        const item = options.item;
        if (item?.Id && (await settings(state, item)).journal) {
          if (state.recorder?.itemId !== item.Id) {
            flush(state);
            state.recorderServerId = item.ServerId;
            state.recorder = new PlaybackRecorder(item.Id, [item.SeriesName, item.Name].filter(Boolean).join(", "));
          }
          const verdict = state.verdicts.get(item.Id);
          if (verdict && !verdict.ok && verdict.reason) state.recorder.refused(verdict.reason);
        } else {
          state.recorder = null;
        }
        return base.play.call(this, options);
      },
      async setCurrentSrc(element, options) {
        const state = states.get(this);
        close(state);
        observe(state, element, options);
        const verdict = options.item?.Id ? state.verdicts.get(options.item.Id) : void 0;
        if (!config.enabled || options.playMethod !== "DirectPlay" || !verdict?.ok || !options.mediaSource?.Id || !options.item?.Id) {
          return base.setCurrentSrc.call(this, element, options);
        }
        const self = this;
        const shield = new Proxy(element, {
          set(target, property, value) {
            if (property !== "src" && property !== "autoplay") target[property] = value;
            return true;
          },
          get(target, property) {
            if (property === "play") return () => open(self, target, options, verdict);
            if (property === "addEventListener") return (type, ...rest) => type === "error" ? void 0 : target.addEventListener(type, ...rest);
            const value = target[property];
            return typeof value === "function" ? value.bind(target) : value;
          }
        });
        return base.setCurrentSrc.call(this, shield, options);
      },
      /** La position, en millisecondes. Un saut passe par le moteur ; la position lue est celle du film. */
      currentTime(ms) {
        const state = states.get(this);
        const playback = state.playback;
        const seeking = ms !== void 0 && ms !== null;
        if (seeking) timeSeek(state);
        if (!playback) return base.currentTime.call(this, ms);
        if (seeking) {
          void playback.seek(ms / 1e3);
          return void 0;
        }
        return playback.position * 1e3;
      },
      /**
       * Changer de piste son dans le tampon vivant : jamais. jellyfin-web renégocie alors le flux, et
       * rappelle `setCurrentSrc` avec la nouvelle piste et la position — la reconstruction que le moteur
       * demande de toute façon.
       */
      canSetAudioStreamIndex() {
        if (states.get(this).playback) return false;
        return base.canSetAudioStreamIndex.call(this);
      },
      stop(destroyPlayer) {
        flush(states.get(this));
        close(states.get(this));
        return base.stop.call(this, destroyPlayer);
      },
      destroy() {
        flush(states.get(this));
        close(states.get(this));
        base.destroy.call(this);
      }
    });
  }
  function close(state) {
    state.opening += 1;
    const playback = state.playback;
    state.playback = null;
    try {
      playback?.destroy();
    } catch (error) {
      console.warn("[Lumen] fermeture :", error);
    }
  }
  function settings(state, item) {
    const api = state.deps.ServerConnections.getApiClient(item.ServerId);
    const key = `${api.serverAddress()}|${api.getCurrentUserId()}`;
    let answer = state.settings.get(key);
    if (!answer) {
      answer = fetch(`${api.serverAddress().replace(/\/+$/, "")}/Lumen/Settings`, { headers: { Authorization: `MediaBrowser Token="${api.accessToken()}"` } }).then(async (response) => {
        if (response.status === 401 || response.status === 403) return { enabled: false, journal: false };
        if (!response.ok) return { enabled: true, journal: false };
        const answered = await response.json();
        if (answered.Enabled === false) log("lecture par jellyfin-web : Lumen ne lit pas pour ce compte (r\xE9glages du plugin)");
        return { enabled: answered.Enabled !== false, journal: answered.Journal === true };
      }).catch(() => ({ enabled: true, journal: false }));
      state.settings.set(key, answer);
    }
    return answer;
  }
  function nextFrame(element, cap = 12e4) {
    return new Promise((resolve) => {
      const until = performance.now() + cap;
      const arrived = () => {
        if (!element.seeking) return resolve(performance.now());
        if (performance.now() > until || !element.isConnected) return resolve(null);
        element.requestVideoFrameCallback?.(arrived);
      };
      if (typeof element.requestVideoFrameCallback !== "function") return resolve(null);
      element.requestVideoFrameCallback(arrived);
      setTimeout(() => resolve(null), cap);
    });
  }
  var watched = /* @__PURE__ */ new WeakSet();
  function observe(state, element, options) {
    const recorder = state.recorder;
    state.element = element;
    if (!recorder) return;
    try {
      const startedAt = state.askedAt ?? performance.now();
      state.askedAt = null;
      state.busy += 1;
      void nextFrame(element).then((at) => {
        state.busy -= 1;
        if (state.recorder !== recorder || at === null) return;
        recorder.stream({
          player: state.playback ? "lumen" : "jellyfin",
          playMethod: options.playMethod ?? null,
          transcodeReasons: transcodeReasonsOf(options.url),
          audio: state.playback?.diagnostics["Traitement audio"] ?? null
        });
        recorder.frame(at - startedAt);
      });
      if (watched.has(element)) return;
      watched.add(element);
      let waitingSince = null;
      let lastTime = null;
      element.addEventListener("waiting", () => {
        if (state.busy === 0 && !element.seeking && state.recorder?.opened) waitingSince ??= performance.now();
      });
      const resumed = () => {
        if (waitingSince !== null) state.recorder?.wait(performance.now() - waitingSince);
        waitingSince = null;
      };
      element.addEventListener("playing", resumed);
      element.addEventListener("seeking", () => waitingSince = null);
      element.addEventListener("timeupdate", () => {
        if (lastTime !== null) state.recorder?.watched(element.currentTime - lastTime);
        lastTime = element.currentTime;
      });
    } catch {
    }
  }
  function timeSeek(state) {
    const recorder = state.recorder;
    const element = state.element;
    if (!recorder || !element) return;
    const startedAt = performance.now();
    state.busy += 1;
    setTimeout(() => {
      void nextFrame(element, 6e4).then((at) => {
        state.busy -= 1;
        if (state.recorder === recorder && at !== null) recorder.seek(at - startedAt);
      });
    }, 0);
  }
  function flush(state) {
    const recorder = state.recorder;
    state.recorder = null;
    if (!recorder) return;
    try {
      const entry = recorder.finish();
      if (entry.firstFrameMs === null && entry.errors === 0 && !entry.refusal) return;
      const api = state.deps.ServerConnections.getApiClient(state.recorderServerId);
      void fetch(`${api.serverAddress().replace(/\/+$/, "")}/Lumen/Journal`, {
        method: "POST",
        keepalive: true,
        headers: { "Content-Type": "application/json", Authorization: `MediaBrowser Token="${api.accessToken()}"` },
        body: JSON.stringify(entry)
      }).catch(() => {
      });
    } catch (error) {
      console.debug("[Lumen] journal non envoy\xE9 :", error);
    }
  }
  function hostFor(state, core2, item) {
    const api = state.deps.ServerConnections.getApiClient(item.ServerId);
    core2.configureHost({ build: config.build, requestHeaders: () => ({ Authorization: `MediaBrowser Token="${api.accessToken()}"` }) });
    return api;
  }
  async function check(self, item) {
    const state = states.get(self);
    const id = item.Id;
    const known = state.verdicts.get(id);
    if (known && Date.now() - known.at < VERDICT_MS) return known;
    const source = item.MediaSources?.find((s) => s.Id === id) ?? item.MediaSources?.[0];
    const mediaSourceId = source?.Id ?? id;
    let engine;
    try {
      engine = await loadCore();
    } catch (error) {
      log("moteur introuvable, lecture par jellyfin-web \u2014", error instanceof Error ? error.message : error);
      return null;
    }
    try {
      const api = hostFor(state, engine, item);
      const video = source?.MediaStreams?.find((s) => s.Type === "Video");
      const asked = engine.probePlaybackPath({
        streamUrl: streamAddress(api.serverAddress(), id, mediaSourceId),
        knownSize: source?.Size ?? null,
        fileVersion: source?.ETag ?? null,
        videoRangeType: video?.VideoRangeType ?? null,
        startSeconds: 0,
        onError: () => {
        }
      });
      const timeout = new Promise((resolve) => setTimeout(() => resolve("timeout"), CHECK_TIMEOUT_MS));
      const probe = await Promise.race([asked, timeout]);
      if (probe === "timeout") {
        void asked.then((late) => late.discard()).catch(() => {
        });
        log(`v\xE9rification trop longue (${CHECK_TIMEOUT_MS / 1e3} s) \u2014 lecture par jellyfin-web`);
        return null;
      }
      const verdict = { at: Date.now(), ok: true, mediaSourceId, audioTracks: probe.audioTracks.map((track) => track.number) };
      probe.discard();
      state.verdicts.set(id, verdict);
      return verdict;
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      if (error instanceof engine.NetworkUnavailable || error instanceof engine.SessionEnded) {
        log("v\xE9rification impossible, lecture par jellyfin-web \u2014", reason);
        return null;
      }
      const verdict = { at: Date.now(), ok: false, reason, mediaSourceId, audioTracks: [] };
      state.verdicts.set(id, verdict);
      log("refus, lecture par jellyfin-web \u2014", reason);
      return verdict;
    }
  }
  async function open(self, element, options, verdict) {
    const state = states.get(self);
    const mine = ++state.opening;
    const item = options.item;
    const source = options.mediaSource;
    const engine = await loadCore();
    const api = hostFor(state, engine, item);
    const video = source.MediaStreams?.find((s) => s.Type === "Video");
    const ask = (audioTrackNumber) => engine.probePlaybackPath({
      streamUrl: streamAddress(api.serverAddress(), item.Id, source.Id),
      knownSize: source.Size ?? null,
      fileVersion: source.ETag ?? null,
      videoRangeType: video?.VideoRangeType ?? null,
      startSeconds: (options.playerStartPositionTicks ?? 0) / 1e7,
      audioTrackNumber,
      // Le moteur a épuisé ses reprises : c'est une erreur de lecture pour jellyfin-web, qui renégocie.
      onError: (message, kind) => {
        if (states.get(self).opening !== mine) return;
        log("le moteur renonce \u2014", message);
        state.deps.events.trigger(self, "error", [{ type: kind === "network" ? "network" : "mediadecodeerror" }]);
      }
    });
    const known = verdict.mediaSourceId === source.Id ? verdict.audioTracks : [];
    let probe = await ask(audioTrackFor(source.MediaStreams, source.DefaultAudioStreamIndex, known));
    if (known.length === 0) {
      const wanted = audioTrackFor(source.MediaStreams, source.DefaultAudioStreamIndex, probe.audioTracks.map((track) => track.number));
      if (wanted !== null && wanted !== probe.audioTrack) {
        probe.discard();
        probe = await ask(wanted);
      }
    }
    if (state.opening !== mine) {
      probe.discard();
      return;
    }
    const playback = await probe.start(element);
    if (state.opening !== mine) {
      playback.destroy();
      return;
    }
    state.playback = playback;
    await (playback.openingHold() ?? Promise.resolve());
    if (state.opening !== mine) return;
    log(`lecture \u2014 ${playback.diagnostics["Vid\xE9o"] ?? "?"}, son ${playback.diagnostics["Traitement audio"] ?? "?"}`);
    await element.play();
  }
  w[PLUGIN_NAME] = async () => LumenPlayer;
  window.addEventListener("pagehide", (event) => {
    if (event.target !== document && event.target !== window) return;
    const state = instance ? states.get(instance) : null;
    if (state) flush(state);
  });
  w.Lumen = {
    config,
    trace: () => core?.then((engine) => engine.traceText()) ?? Promise.resolve(""),
    status() {
      const state = instance ? states.get(instance) : null;
      if (!state) return null;
      return {
        adopted: state.adopted,
        playing: state.playback !== null,
        position: state.playback?.position ?? null,
        audioTrack: state.playback?.currentAudioTrack ?? null,
        diagnostics: state.playback?.diagnostics ?? null,
        verdicts: [...state.verdicts].map(([id, verdict]) => ({ id, ok: verdict.ok, reason: verdict.reason ?? null }))
      };
    }
  };
})();
//# sourceMappingURL=lumen-jellyfin.js.map
