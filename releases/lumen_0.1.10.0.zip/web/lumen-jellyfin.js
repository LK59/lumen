"use strict";
(() => {
  // src/journal.ts
  var MIN_WAIT_MS = 250;
  var KEPT = 50;
  var PlaybackRecorder = class {
    entry;
    constructor(itemId, title) {
      this.entry = { itemId, title, player: "jellyfin", playMethod: null, transcodeReasons: null, refusal: null, audio: null, firstFrameMs: null, openingSteps: null, seeksMs: [], streamChangesMs: [], waits: 0, waitsMs: 0, watchedSeconds: 0, rebuilds: 0, errors: 0 };
    }
    get itemId() {
      return this.entry.itemId;
    }
    /** Une image est-elle déjà venue ? Avant elle, tout arrêt fait partie de l'ouverture. */
    get opened() {
      return this.entry.firstFrameMs !== null;
    }
    /** Ce que le serveur sert pour ce flux — redit à chaque changement de flux, le dernier compte. */
    stream(facts) {
      Object.assign(this.entry, facts);
    }
    refused(reason) {
      this.entry.refusal = reason.slice(0, 300);
    }
    /** La première image d'un flux : celle de l'ouverture, ou celle qui suit un changement de flux. */
    frame(ms) {
      if (this.entry.firstFrameMs === null) this.entry.firstFrameMs = Math.round(ms);
      else if (this.entry.streamChangesMs.length < KEPT) this.entry.streamChangesMs.push(Math.round(ms));
    }
    opening(steps) {
      this.entry.openingSteps = steps;
    }
    seek(ms) {
      if (this.entry.seeksMs.length < KEPT) this.entry.seeksMs.push(Math.round(ms));
    }
    wait(ms) {
      if (ms < MIN_WAIT_MS) return;
      this.entry.waits += 1;
      this.entry.waitsMs += Math.round(ms);
    }
    watched(seconds) {
      if (seconds > 0 && seconds < 2) this.entry.watchedSeconds += seconds;
    }
    rebuilt() {
      this.entry.rebuilds += 1;
    }
    error() {
      this.entry.errors += 1;
    }
    finish() {
      return { ...this.entry, watchedSeconds: Math.round(this.entry.watchedSeconds) };
    }
  };
  function transcodeReasonsOf(url) {
    const match = /[?&]TranscodeReasons=([^&]+)/i.exec(url ?? "");
    return match ? decodeURIComponent(match[1]) : null;
  }

  // src/rules.ts
  var PLUGIN_NAME = "lumenPlayer";
  function eligible(item) {
    if (!item?.Id || item.MediaType !== "Video" || item.IsPlaceHolder) return false;
    if (item.LocationType && item.LocationType !== "FileSystem") return false;
    if (item.VideoType && item.VideoType !== "VideoFile") return false;
    return !["TvChannel", "LiveTvChannel", "Program", "LiveTvProgram", "Recording"].includes(item.Type ?? "");
  }
  function streamAddress(server, itemId, mediaSourceId) {
    return `${server.replace(/\/+$/, "")}/Videos/${encodeURIComponent(itemId)}/stream?static=true&mediaSourceId=${encodeURIComponent(mediaSourceId)}`;
  }
  function lumenProfile(base) {
    return { ...base, DirectPlayProfiles: [{ Type: "Video" }], CodecProfiles: [], ContainerProfiles: [] };
  }
  function audioTrackFor(streams, wantedIndex, trackNumbers) {
    if (wantedIndex === null || wantedIndex === void 0 || wantedIndex < 0) return null;
    const internal = (streams ?? []).filter((s) => s.Type === "Audio" && !s.IsExternal).sort((a, b) => (a.Index ?? 0) - (b.Index ?? 0));
    const rank = internal.findIndex((s) => s.Index === wantedIndex);
    if (rank < 0 || internal.length !== trackNumbers.length) return null;
    return trackNumbers[rank] ?? null;
  }
  function televisionClient(userAgent) {
    return /web0s|webos|tizen|smart-?tv|netcast|vidaa|viera|hbbtv|playstation|xbox/i.test(userAgent);
  }

  // src/bridge.ts
  var w = window;
  var script = document.currentScript;
  var config = { enabled: true, base: script?.src ? new URL(".", script.src).href : new URL("lumen/", document.baseURI).href, build: "dev", ...w.LumenConfig ?? {} };
  var log = (...args) => console.info("[Lumen]", ...args);
  var states = /* @__PURE__ */ new WeakMap();
  var instance = null;
  var VERDICT_MS = 10 * 6e4;
  var REFUSALS_BEFORE_HANDOVER = 4;
  var REFUSAL_WINDOW_MS = 1e4;
  var SETTINGS_MS = 5e3;
  var CHECK_TIMEOUT_MS = 8e3;
  var core = null;
  function loadCore() {
    core ??= import(
      /* @vite-ignore */
      new URL("lumen-core.js", config.base).href
    ).catch((error) => {
      core = null;
      throw error;
    });
    return core;
  }
  var LumenPlayer = class {
    name = "Lumen";
    type = "mediaplayer";
    id = "lumenplayer";
    /** Avant le lecteur de jellyfin-web (1) : à type de média égal, le premier de la liste est pris. */
    priority = -1;
    isLocalPlayer = true;
    constructor(deps) {
      states.set(this, { deps, adopted: null, playback: null, opening: 0, verdicts: /* @__PURE__ */ new Map(), settings: /* @__PURE__ */ new Map(), recorder: null, recorderServerId: void 0, askedAt: null, element: null, busy: 0, seekTarget: null, steps: {}, stepsFrom: 0, offered: null, current: null, rebuilds: [], rebuilding: null, seekAfterRebuild: null, lastPosition: 0, wasPaused: false, handedOver: false, onRangeRefused: null });
      instance = this;
    }
    canPlayMediaType(mediaType) {
      return adopt(this) ? this.canPlayMediaType(mediaType) : false;
    }
    // jellyfin-web greffe `getVolume`/`setVolume` sur un lecteur qui ne les a pas, à l'enregistrement —
    // des propriétés de l'objet, qui masqueraient ensuite celles du lecteur adopté. Elles existent donc
    // d'avance ; rien ne les appelle tant que ce lecteur ne lit rien.
    getVolume() {
      return 100;
    }
    setVolume() {
    }
  };
  function adopt(self) {
    const state = states.get(self);
    if (state.adopted !== null) return state.adopted;
    if (televisionClient(navigator.userAgent)) {
      state.adopted = false;
      log("t\xE9l\xE9viseur ou console : lecture laiss\xE9e \xE0 jellyfin-web");
      return false;
    }
    const html = state.deps.playbackManager.getPlayers().find((player) => player.id === "htmlvideoplayer");
    if (!html) return false;
    const Base = html.constructor;
    const own = { ...self };
    const before = Object.getPrototypeOf(self);
    try {
      for (const name of ["getDeviceProfile", "setCurrentSrc", "play", "currentTime", "stop", "destroy", "canPlayMediaType"]) {
        if (typeof Base.prototype[name] !== "function") throw new Error(`le lecteur de jellyfin-web n'a pas de m\xE9thode \xAB ${name} \xBB`);
      }
      Object.setPrototypeOf(self, lumenPrototype(Base.prototype));
      Base.call(self);
      const htmlName = String(self.name || "Html Video Player");
      Object.assign(self, own);
      Object.defineProperty(self, "name", { configurable: true, enumerable: true, get: () => state.playback ? "Lumen" : htmlName });
      state.adopted = true;
      log("pr\xEAt \u2014 greff\xE9 sur le lecteur vid\xE9o de jellyfin-web");
    } catch (error) {
      Object.setPrototypeOf(self, before);
      state.adopted = false;
      console.warn("[Lumen] inactif : le lecteur vid\xE9o de cette version de jellyfin-web ne se laisse pas \xE9tendre \u2014", error);
    }
    return state.adopted;
  }
  function lumenPrototype(base) {
    return Object.assign(Object.create(base), {
      canPlayMediaType(mediaType) {
        return config.enabled && (mediaType ?? "").toLowerCase() === "video";
      },
      /** Seulement les fichiers vidéo de la bibliothèque : pour le reste, jellyfin-web prend son lecteur. */
      canPlayItem(item) {
        return config.enabled && eligible(item);
      },
      /**
       * Le profil annoncé au serveur — c'est ici que se décide qui lira.
       *
       * jellyfin-web le demande avant de négocier la lecture. On pose donc la question au moteur à ce
       * moment-là, sur le fichier : s'il le porte, le profil dit « lecture directe » et le serveur répond
       * par l'adresse du fichier brut ; s'il le refuse, le profil est celui de jellyfin-web et tout se
       * passe comme sans Lumen, transcodage compris. Le refus ne coûte ainsi ni erreur à l'écran ni
       * seconde négociation.
       *
       * `isRetry` : jellyfin-web renégocie après une erreur de lecture, pour obtenir un transcodage. Ce
       * n'est plus le moment de proposer le chemin qui vient d'échouer.
       */
      async getDeviceProfile(item, options) {
        const state = states.get(this);
        state.askedAt = performance.now();
        state.stepsFrom = state.askedAt;
        state.steps = {};
        state.offered = null;
        if (options?.isRetry) state.recorder?.error();
        const profile = await base.getDeviceProfile.call(this, item, options);
        step(state, "profile");
        if (!config.enabled || options?.isRetry || !eligible(item)) return profile;
        const allowed = (await settings(state, item)).enabled;
        step(state, "settings");
        if (!allowed) return profile;
        const verdict = await check(this, item);
        step(state, "check");
        if (!verdict?.ok) return profile;
        state.offered = item.Id ?? null;
        return lumenProfile(profile);
      },
      /**
       * La source. jellyfin-web appelle ceci avec l'élément `<video>` qu'il vient de créer et ce que le
       * serveur a répondu.
       *
       * Hors lecture directe d'un fichier accepté, c'est le lecteur de jellyfin-web tel quel. Sinon, sa
       * méthode est tout de même appelée — elle prépare les sous-titres, la piste son, l'état que le reste
       * du lecteur relit — mais sur un élément dont deux gestes sont détournés : poser `src` ne fait rien,
       * et `play()` ouvre Lumen sur le vrai élément avant de lancer la lecture. Un échec de l'ouverture
       * rejette `play()`, que jellyfin-web traite comme toute erreur de lecture : il renégocie.
       */
      /**
       * Le départ d'un flux : une ouverture, ou un changement de flux pendant la lecture (piste son,
       * qualité, repli). Rien n'est changé à ce que fait jellyfin-web ; le journal de la lecture s'ouvre ici.
       */
      async play(options) {
        const state = states.get(this);
        const item = options.item;
        claimPlaybackAudio();
        if (item?.Id && (await settings(state, item)).journal) {
          if (state.recorder?.itemId !== item.Id) {
            flush(state);
            state.recorderServerId = item.ServerId;
            state.recorder = new PlaybackRecorder(item.Id, [item.SeriesName, item.Name].filter(Boolean).join(", "));
          }
          const verdict = state.verdicts.get(item.Id);
          if (verdict && !verdict.ok && verdict.reason) state.recorder.refused(verdict.reason);
        } else {
          state.recorder = null;
        }
        return base.play.call(this, options);
      },
      async setCurrentSrc(element, options) {
        const state = states.get(this);
        close(state);
        step(state, "negotiated");
        observe(state, element, options);
        alignSubtitles(state, element);
        const verdict = options.item?.Id ? state.verdicts.get(options.item.Id) : void 0;
        if (!config.enabled || options.playMethod !== "DirectPlay" || !verdict?.ok || !options.mediaSource?.Id || !options.item?.Id || state.offered !== options.item.Id) {
          return base.setCurrentSrc.call(this, element, options);
        }
        const self = this;
        const shield = new Proxy(element, {
          set(target, property, value) {
            if (property !== "src" && property !== "autoplay") target[property] = value;
            return true;
          },
          get(target, property) {
            if (property === "play") {
              return () => {
                state.current = { element: target, options, verdict };
                state.rebuilds = [];
                state.wasPaused = false;
                return open(self, target, options, verdict);
              };
            }
            if (property === "addEventListener") return (type, ...rest) => type === "error" ? void 0 : target.addEventListener(type, ...rest);
            const value = target[property];
            return typeof value === "function" ? value.bind(target) : value;
          }
        });
        return base.setCurrentSrc.call(this, shield, options);
      },
      /** La position, en millisecondes. Un saut passe par le moteur ; la position lue est celle du film. */
      currentTime(ms) {
        const state = states.get(this);
        const playback = state.playback;
        const seeking = ms !== void 0 && ms !== null;
        if (seeking) timeSeek(state);
        if (state.rebuilding !== null) {
          if (seeking) state.seekAfterRebuild = ms / 1e3;
          return seeking ? void 0 : (state.seekAfterRebuild ?? state.rebuilding) * 1e3;
        }
        if (!playback) return base.currentTime.call(this, ms);
        if (seeking) {
          const seconds = ms / 1e3;
          const element = state.element;
          if (element && !playback.seekPending && !element.seeking && loadedAt(element, seconds)) {
            state.seekTarget = null;
            element.currentTime = seconds;
          } else {
            state.seekTarget = seconds;
            void playback.seek(seconds);
          }
          return void 0;
        }
        if (state.seekTarget !== null && !playback.seekPending) state.seekTarget = null;
        const position = playback.lost && playback.position === 0 ? state.lastPosition : playback.position;
        return (state.seekTarget ?? position) * 1e3;
      },
      /**
       * Changer de piste son dans le tampon vivant : jamais. jellyfin-web renégocie alors le flux, et
       * rappelle `setCurrentSrc` avec la nouvelle piste et la position — la reconstruction que le moteur
       * demande de toute façon.
       */
      canSetAudioStreamIndex() {
        if (states.get(this).playback) return false;
        return base.canSetAudioStreamIndex.call(this);
      },
      /**
       * Les statistiques du panneau « Playback Info » : celles de jellyfin-web, et quand Lumen lit, ce que
       * le moteur fait du fichier — c'est là qu'on vérifie d'un coup d'œil qui lit, et comment.
       */
      async getStats() {
        const stats = await base.getStats?.call(this) ?? {};
        const diagnostics = states.get(this).playback?.diagnostics;
        if (!diagnostics) return stats;
        const lines = [
          ["Video", diagnostics["Vid\xE9o"]],
          ["Audio", diagnostics["Audio"]?.replace(/ canaux?$/, " ch")],
          ["Audio handling", englishAudio(diagnostics["Traitement audio"])],
          ["Buffered ahead", diagnostics["Avance sur la t\xEAte"]]
        ].filter((line) => !!line[1]);
        return { ...stats, categories: [...stats.categories ?? [], { type: "lumen", name: "Lumen", stats: lines.map(([label, value]) => ({ label, value })) }] };
      },
      stop(destroyPlayer) {
        releasePlaybackAudio();
        flush(states.get(this));
        close(states.get(this));
        return base.stop.call(this, destroyPlayer);
      },
      destroy() {
        releasePlaybackAudio();
        flush(states.get(this));
        close(states.get(this));
        base.destroy.call(this);
      }
    });
  }
  var audioSessionBefore = null;
  function claimPlaybackAudio() {
    try {
      const session = navigator.audioSession;
      if (!session || typeof session.type !== "string" || session.type === "playback") return;
      audioSessionBefore ??= session.type;
      session.type = "playback";
    } catch {
    }
  }
  function releasePlaybackAudio() {
    try {
      const session = navigator.audioSession;
      if (session && audioSessionBefore !== null) session.type = audioSessionBefore;
    } catch {
    }
    audioSessionBefore = null;
  }
  function englishAudio(text) {
    if (text === "copi\xE9 tel quel") return "copied as is";
    const encoded = /^décodé puis ré-encodé en (.+)$/.exec(text ?? "");
    return encoded ? `decoded here, re-encoded to ${encoded[1]}` : text;
  }
  function close(state, rebuilding = false) {
    if (!rebuilding) {
      state.handedOver = false;
      state.current = null;
      state.rebuilding = null;
      state.seekAfterRebuild = null;
    }
    state.opening += 1;
    state.onRangeRefused = null;
    const playback = state.playback;
    state.playback = null;
    state.seekTarget = null;
    try {
      playback?.destroy();
    } catch (error) {
      console.warn("[Lumen] fermeture :", error);
    }
  }
  function settings(state, item) {
    const api = state.deps.ServerConnections.getApiClient(item.ServerId);
    const key = `${api.serverAddress()}|${api.getCurrentUserId()}`;
    const known = state.settings.get(key);
    let answer = known && Date.now() - known.at < SETTINGS_MS ? known.answer : null;
    if (!answer) {
      answer = fetch(`${api.serverAddress().replace(/\/+$/, "")}/Lumen/Settings`, { headers: { Authorization: `MediaBrowser Token="${api.accessToken()}"` } }).then(async (response) => {
        if (response.status === 401 || response.status === 403) return { enabled: false, journal: false };
        if (!response.ok) return { enabled: true, journal: false };
        const answered = await response.json();
        if (answered.Enabled === false) log("lecture par jellyfin-web : Lumen ne lit pas pour ce compte (r\xE9glages du plugin)");
        return { enabled: answered.Enabled !== false, journal: answered.Journal === true };
      }).catch(() => ({ enabled: true, journal: false }));
      state.settings.set(key, { at: Date.now(), answer });
    }
    return answer;
  }
  function nextFrame(element, cap = 12e4) {
    return new Promise((resolve) => {
      const until = performance.now() + cap;
      const arrived = () => {
        if (!element.seeking) return resolve(performance.now());
        if (performance.now() > until || !element.isConnected) return resolve(null);
        element.requestVideoFrameCallback?.(arrived);
      };
      if (typeof element.requestVideoFrameCallback !== "function") return resolve(null);
      element.requestVideoFrameCallback(arrived);
      setTimeout(() => resolve(null), cap);
    });
  }
  var watched = /* @__PURE__ */ new WeakSet();
  function observe(state, element, options) {
    const recorder = state.recorder;
    state.element = element;
    if (!recorder) return;
    try {
      const startedAt = state.askedAt ?? performance.now();
      state.askedAt = null;
      state.busy += 1;
      void nextFrame(element).then((at) => {
        state.busy -= 1;
        if (state.recorder !== recorder || at === null) return;
        recorder.stream({
          player: state.playback ? "lumen" : "jellyfin",
          playMethod: options.playMethod ?? null,
          transcodeReasons: transcodeReasonsOf(options.url),
          audio: state.playback?.diagnostics["Traitement audio"] ?? null
        });
        if (!recorder.opened) recorder.opening({ ...state.steps });
        recorder.frame(at - startedAt);
      });
      if (watched.has(element)) return;
      watched.add(element);
      let waitingSince = null;
      let lastTime = null;
      element.addEventListener("waiting", () => {
        if (state.busy === 0 && !element.seeking && state.recorder?.opened) waitingSince ??= performance.now();
      });
      const resumed = () => {
        if (waitingSince !== null) state.recorder?.wait(performance.now() - waitingSince);
        waitingSince = null;
      };
      element.addEventListener("playing", resumed);
      for (const type of ["pause", "play", "playing"]) {
        element.addEventListener(type, () => {
          if (state.playback && !state.playback.lost && state.rebuilding === null && element.readyState > 0) state.wasPaused = element.paused;
        });
      }
      element.addEventListener("seeking", () => waitingSince = null);
      element.addEventListener("timeupdate", () => {
        if (state.playback && !element.seeking && element.currentTime > 0) state.lastPosition = element.currentTime;
        if (lastTime !== null) state.recorder?.watched(element.currentTime - lastTime);
        lastTime = element.currentTime;
      });
    } catch {
    }
  }
  var aligned = /* @__PURE__ */ new WeakSet();
  var shifted = /* @__PURE__ */ new WeakSet();
  function alignSubtitles(state, element) {
    if (aligned.has(element)) return;
    aligned.add(element);
    element.addEventListener("timeupdate", () => {
      try {
        const delay = state.playback?.presentationDelay ?? 0;
        if (!(delay > 0.02)) return;
        for (const track of Array.from(element.textTracks)) {
          const cues = track.cues;
          if (!cues || cues.length === 0 || shifted.has(cues[0]) && shifted.has(cues[cues.length - 1])) continue;
          for (const cue of Array.from(cues)) {
            if (shifted.has(cue)) continue;
            shifted.add(cue);
            cue.endTime += delay;
            cue.startTime += delay;
          }
        }
      } catch {
      }
    });
  }
  function step(state, name) {
    if (!(name in state.steps)) state.steps[name] = Math.round(performance.now() - state.stepsFrom);
  }
  var LOADED_MARGIN_S = 1;
  function loadedAt(element, seconds) {
    const spans = element.buffered;
    for (let i = 0; i < spans.length; i += 1) {
      if (seconds >= spans.start(i) && seconds <= spans.end(i) - LOADED_MARGIN_S) return true;
    }
    return false;
  }
  function timeSeek(state) {
    const recorder = state.recorder;
    const element = state.element;
    if (!recorder || !element) return;
    const startedAt = performance.now();
    state.busy += 1;
    setTimeout(() => {
      void nextFrame(element, 6e4).then((at) => {
        state.busy -= 1;
        if (state.recorder === recorder && at !== null) recorder.seek(at - startedAt);
      });
    }, 0);
  }
  function flush(state) {
    const recorder = state.recorder;
    state.recorder = null;
    if (!recorder) return;
    try {
      const entry = recorder.finish();
      if (entry.firstFrameMs === null && entry.errors === 0 && !entry.refusal) return;
      const api = state.deps.ServerConnections.getApiClient(state.recorderServerId);
      void fetch(`${api.serverAddress().replace(/\/+$/, "")}/Lumen/Journal`, {
        method: "POST",
        keepalive: true,
        headers: { "Content-Type": "application/json", Authorization: `MediaBrowser Token="${api.accessToken()}"` },
        body: JSON.stringify(entry)
      }).catch(() => {
      });
    } catch (error) {
      console.debug("[Lumen] journal non envoy\xE9 :", error);
    }
  }
  function hostFor(state, core2, item) {
    const api = state.deps.ServerConnections.getApiClient(item.ServerId);
    core2.configureHost({
      build: config.build,
      requestHeaders: () => ({ Authorization: `MediaBrowser Token="${api.accessToken()}"` }),
      rangeRefused: (status) => state.onRangeRefused?.(status)
    });
    return api;
  }
  async function check(self, item) {
    const state = states.get(self);
    const id = item.Id;
    const known = state.verdicts.get(id);
    if (known && Date.now() - known.at < VERDICT_MS) return known;
    const source = item.MediaSources?.find((s) => s.Id === id) ?? item.MediaSources?.[0];
    const mediaSourceId = source?.Id ?? id;
    let engine;
    try {
      engine = await loadCore();
    } catch (error) {
      log("moteur introuvable, lecture par jellyfin-web \u2014", error instanceof Error ? error.message : error);
      return null;
    }
    try {
      const api = hostFor(state, engine, item);
      const video = source?.MediaStreams?.find((s) => s.Type === "Video");
      const asked = engine.probePlaybackPath({
        streamUrl: streamAddress(api.serverAddress(), id, mediaSourceId),
        knownSize: source?.Size ?? null,
        fileVersion: source?.ETag ?? null,
        videoRangeType: video?.VideoRangeType ?? null,
        startSeconds: 0,
        onError: () => {
        }
      });
      const timeout = new Promise((resolve) => setTimeout(() => resolve("timeout"), CHECK_TIMEOUT_MS));
      const probe = await Promise.race([asked, timeout]);
      if (probe === "timeout") {
        void asked.then((late) => late.discard()).catch(() => {
        });
        log(`v\xE9rification trop longue (${CHECK_TIMEOUT_MS / 1e3} s) \u2014 lecture par jellyfin-web`);
        return null;
      }
      const verdict = { at: Date.now(), ok: true, mediaSourceId, audioTracks: probe.audioTracks.map((track) => track.number) };
      probe.discard();
      state.verdicts.set(id, verdict);
      return verdict;
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      if (error instanceof engine.NetworkUnavailable || error instanceof engine.SessionEnded) {
        log("v\xE9rification impossible, lecture par jellyfin-web \u2014", reason);
        return null;
      }
      const verdict = { at: Date.now(), ok: false, reason, mediaSourceId, audioTracks: [] };
      state.verdicts.set(id, verdict);
      log("refus, lecture par jellyfin-web \u2014", reason);
      return verdict;
    }
  }
  async function open(self, element, options, verdict, resume) {
    const state = states.get(self);
    const mine = ++state.opening;
    const item = options.item;
    const source = options.mediaSource;
    step(state, "play");
    const engine = await loadCore();
    const api = hostFor(state, engine, item);
    const video = source.MediaStreams?.find((s) => s.Type === "Video");
    const ask = (audioTrackNumber) => engine.probePlaybackPath({
      streamUrl: streamAddress(api.serverAddress(), item.Id, source.Id),
      knownSize: source.Size ?? null,
      fileVersion: source.ETag ?? null,
      videoRangeType: video?.VideoRangeType ?? null,
      startSeconds: resume?.seconds ?? (options.playerStartPositionTicks ?? 0) / 1e7,
      // Une reconstruction ne relance pas un film que le spectateur avait mis en pause.
      startPaused: resume?.paused ?? false,
      audioTrackNumber,
      onWarning: (warning) => log("avertissement du moteur \u2014", warning.code, warning.detail ?? ""),
      // Le moteur a épuisé ses reprises sur cette source. On la rouvre à la même position, quelques
      // fois ; au-delà, c'est une erreur de lecture pour jellyfin-web, qui renégocie et transcode.
      onError: (message, kind) => {
        if (states.get(self).opening !== mine) return;
        log("le moteur renonce \u2014", message);
        void rebuild(self, kind === "network" ? "r\xE9seau" : "source perdue").then((rebuilt) => {
          if (!rebuilt) handOver(self, kind === "network" ? "network" : "mediadecodeerror");
        });
      }
    });
    let refusals = 0;
    let lastRefusal = 0;
    state.onRangeRefused = (status) => {
      if (states.get(self).opening !== mine) return;
      const now = performance.now();
      refusals = now - lastRefusal > REFUSAL_WINDOW_MS ? 1 : refusals + 1;
      lastRefusal = now;
      if (refusals !== REFUSALS_BEFORE_HANDOVER) return;
      log(`le serveur refuse le fichier (statut ${status}) \u2014 lecture rendue \xE0 jellyfin-web`);
      handOver(self, "network");
    };
    const known = verdict.mediaSourceId === source.Id ? verdict.audioTracks : [];
    let probe = await ask(audioTrackFor(source.MediaStreams, source.DefaultAudioStreamIndex, known));
    if (known.length === 0) {
      const wanted = audioTrackFor(source.MediaStreams, source.DefaultAudioStreamIndex, probe.audioTracks.map((track) => track.number));
      if (wanted !== null && wanted !== probe.audioTrack) {
        probe.discard();
        probe = await ask(wanted);
      }
    }
    if (state.opening !== mine) {
      probe.discard();
      return;
    }
    step(state, "probed");
    if (resume?.paused) element.autoplay = false;
    const playback = await probe.start(element);
    step(state, "started");
    if (state.opening !== mine) {
      playback.destroy();
      return;
    }
    state.playback = playback;
    await (playback.openingHold() ?? Promise.resolve());
    step(state, "released");
    if (state.opening !== mine) return;
    log(`lecture \u2014 ${playback.diagnostics["Vid\xE9o"] ?? "?"}, son ${playback.diagnostics["Traitement audio"] ?? "?"}`);
    if (!resume?.paused) await element.play();
  }
  function handOver(self, type) {
    const state = states.get(self);
    if (state.handedOver) return;
    state.handedOver = true;
    state.deps.events.trigger(self, "error", [{ type }]);
  }
  var MAX_REBUILDS = 3;
  var REBUILD_WINDOW_MS = 3 * 6e4;
  var SAME_PLACE_S = 2;
  async function rebuild(self, why) {
    const state = states.get(self);
    const current = state.current;
    const playback = state.playback;
    if (!current || !playback || state.rebuilding !== null) return state.rebuilding !== null;
    const now = performance.now();
    state.rebuilds = state.rebuilds.filter((past) => now - past.at < REBUILD_WINDOW_MS);
    if (state.rebuilds.length >= MAX_REBUILDS) {
      log(`${MAX_REBUILDS} reconstructions en ${REBUILD_WINDOW_MS / 6e4} minutes \u2014 lecture rendue \xE0 jellyfin-web`);
      return false;
    }
    let seconds = playback.position > 0 ? playback.position : state.lastPosition;
    const last = state.rebuilds[state.rebuilds.length - 1];
    if (last && Math.abs(last.seconds - seconds) < SAME_PLACE_S) seconds = playback.nextKeyframeAfter(seconds) ?? seconds;
    state.rebuilds.push({ at: now, seconds });
    const paused = state.wasPaused;
    log(`reconstruction (${why}) \xE0 ${seconds.toFixed(1)} s${paused ? ", en pause" : ""} \u2014 moteur ${playback.position.toFixed(1)} s, derni\xE8re position jou\xE9e ${state.lastPosition.toFixed(1)} s`);
    state.recorder?.rebuilt();
    state.rebuilding = seconds;
    close(state, true);
    try {
      if (navigator.onLine === false) await new Promise((resolve) => window.addEventListener("online", () => resolve(), { once: true }));
      if (state.current !== current) return true;
      state.busy += 1;
      try {
        await open(self, current.element, current.options, current.verdict, { seconds, paused });
      } finally {
        state.busy -= 1;
      }
      if (state.current !== current) return true;
      const wanted = state.seekAfterRebuild;
      state.rebuilding = null;
      state.seekAfterRebuild = null;
      if (wanted !== null) void state.playback?.seek(wanted);
      return true;
    } catch (error) {
      if (state.current !== current) return true;
      state.rebuilding = null;
      log("reconstruction impossible \u2014", error instanceof Error ? error.message : error);
      return false;
    }
  }
  function checkAfterReturn() {
    if (document.visibilityState !== "visible") return;
    const look = () => {
      const state = instance ? states.get(instance) : null;
      if (!instance || !state?.playback?.lost || state.rebuilding !== null) return;
      const self = instance;
      void rebuild(self, "retour au premier plan").then((rebuilt) => {
        if (!rebuilt) handOver(self, "mediadecodeerror");
      });
    };
    look();
    setTimeout(look, 400);
  }
  document.addEventListener("visibilitychange", checkAfterReturn);
  w[PLUGIN_NAME] = async () => LumenPlayer;
  window.addEventListener("pagehide", (event) => {
    if (event.target !== document && event.target !== window) return;
    const state = instance ? states.get(instance) : null;
    if (state) flush(state);
  });
  w.Lumen = {
    config,
    trace: () => core?.then((engine) => engine.traceText()) ?? Promise.resolve(""),
    status() {
      const state = instance ? states.get(instance) : null;
      if (!state) return null;
      return {
        adopted: state.adopted,
        playing: state.playback !== null,
        position: state.playback?.position ?? null,
        audioTrack: state.playback?.currentAudioTrack ?? null,
        diagnostics: state.playback?.diagnostics ?? null,
        verdicts: [...state.verdicts].map(([id, verdict]) => ({ id, ok: verdict.ok, reason: verdict.reason ?? null }))
      };
    }
  };
})();
//# sourceMappingURL=lumen-jellyfin.js.map
