import {
  clusterOffsetForTime,
  createSampleReader
} from "./lumen-chunk-NSCTZZLO.js";
import {
  openAc3DtsDecoder
} from "./lumen-chunk-US5YVFRR.js";
import {
  noteLumenDecoderClosed,
  noteLumenDecoderOpened,
  noteLumenFacts
} from "./lumen-chunk-TM3DN4G5.js";
import "./lumen-chunk-XI2GCOGB.js";

// src/engine/audioDemux.ts
var MARGIN_US = 1e6;
var GIVE_UP_S = 45;
function newAudioDemuxStats() {
  return { scanned: 0, gaveUp: 0 };
}
async function* audioPacketsFrom(source, file, trackNumber, fromSeconds, stats = newAudioDemuxStats(), cancel = { stopped: false }) {
  const track = file.tracks.find((t) => t.number === trackNumber);
  if (!track) throw new Error(`piste ${trackNumber} introuvable`);
  const fromUs = Math.max(0, fromSeconds) * 1e6;
  const searchUs = Math.max(0, fromUs - MARGIN_US);
  const beforeIndex = file.cues.length === 0 || searchUs <= file.cues[0].timeUs;
  const start = (beforeIndex ? null : clusterOffsetForTime(file, searchUs)) ?? file.firstClusterOffset ?? file.segmentDataStart;
  const reader = createSampleReader(source, file, start);
  const laced = lacedTimeline(track);
  let pending = null;
  let started = false;
  let silentSinceUs = null;
  for (; ; ) {
    if (cancel.stopped) return;
    const sample = await reader.next();
    if (!sample) break;
    if (!started) stats.scanned += 1;
    silentSinceUs ??= sample.timestampUs;
    if (sample.trackNumber !== trackNumber) {
      if (!started && sample.timestampUs - silentSinceUs > GIVE_UP_S * 1e6) {
        stats.gaveUp += 1;
        break;
      }
      continue;
    }
    silentSinceUs = sample.timestampUs;
    for (const packet of laced.push(sample.timestampUs, sample.durationUs, sample.data)) {
      if (!started) {
        if (packet.timestamp * 1e6 <= fromUs) {
          pending = packet;
          continue;
        }
        started = true;
        if (pending) yield pending;
        pending = null;
      }
      yield packet;
    }
  }
  for (const packet of laced.end()) {
    if (!started) {
      if (packet.timestamp * 1e6 <= fromUs) {
        pending = packet;
        continue;
      }
      started = true;
      if (pending) yield pending;
      pending = null;
    }
    yield packet;
  }
  if (!started && pending) yield pending;
}
function lacedTimeline(track) {
  const defaultUs = track.defaultDurationNs ? track.defaultDurationNs / 1e3 : null;
  let group = null;
  const spread = (g, nextTs) => {
    const n = g.frames.length;
    let total = g.durationUs;
    if (total === null && nextTs !== null) total = nextTs - g.ts;
    if (total === null && defaultUs !== null) total = defaultUs * n;
    const each = total !== null && total > 0 ? total / n : 0;
    return g.frames.map((data, i) => ({ data, timestamp: (g.ts + i * each) / 1e6, duration: each / 1e6 }));
  };
  return {
    push(ts, durationUs, data) {
      if (group && group.ts === ts) {
        group.frames.push(data);
        return [];
      }
      const out = group ? spread(group, ts) : [];
      group = { ts, durationUs, frames: [data] };
      return out;
    },
    end() {
      const out = group ? spread(group, null) : [];
      group = null;
      return out;
    }
  };
}
async function* decodedFrom(packets, openDecoder, fromSeconds, configSampleRate, cancel = { stopped: false }) {
  const ready = [];
  let failure = null;
  let current = null;
  let last = null;
  let firstQueued = false;
  const onFrame = (frame) => {
    const frames = frame.planes[0]?.length ?? 0;
    const duration = frames / frame.sampleRate;
    if (current === null || Math.abs(frame.timestamp - current) >= duration) current = frame.timestamp;
    const precise = current;
    current += duration;
    if (frames === 0) return;
    const decoded = {
      planes: frame.planes,
      sampleRate: frame.sampleRate,
      timestampSeconds: Math.round(precise * configSampleRate) / configSampleRate
    };
    if (last && decoded.timestampSeconds > fromSeconds) {
      ready.push(last);
      firstQueued = true;
    }
    if (decoded.timestampSeconds >= fromSeconds) {
      ready.push(decoded);
      firstQueued = true;
    }
    last = firstQueued ? null : decoded;
  };
  const decoder = await openDecoder(onFrame, (error) => {
    failure ??= { error };
  });
  noteLumenDecoderOpened();
  try {
    for await (const packet of packets) {
      await decoder.decode(packet);
      if (failure) throw failure.error;
      while (ready.length > 0) yield ready.shift();
    }
    if (cancel.stopped) return;
    await decoder.flush();
    if (failure) throw failure.error;
    if (!firstQueued && last) ready.push(last);
    while (ready.length > 0) yield ready.shift();
  } finally {
    decoder.close();
    noteLumenDecoderClosed();
  }
}

// src/engine/flacHeader.ts
function streamInfoHeader(header) {
  const magic = header.length >= 4 && header[0] === 102 && header[1] === 76 && header[2] === 97 && header[3] === 67;
  const at = magic ? 4 : 0;
  if (header.length < at + 4 || (header[at] & 127) !== 0) return header.slice();
  const length = header[at + 1] << 16 | header[at + 2] << 8 | header[at + 3];
  if (header.length < at + 4 + length) return header.slice();
  const out = new Uint8Array(4 + 4 + length);
  out.set([102, 76, 97, 67]);
  out.set(header.subarray(at, at + 4 + length), 4);
  out[4] |= 128;
  return out;
}

// src/engine/ownAudio.ts
var BATCH_S = 0.25;
function ownWasmOpener(name) {
  const which = name === "ac3" ? 0 : name === "eac3" ? 1 : 2;
  return async (onFrame, onError) => {
    const decoder = await openAc3DtsDecoder(which);
    noteLumenFacts({ decoder: `ffmpeg-7.1.5-${name}`, thread: decoder.thread, ...decoder.workerRefusal !== void 0 ? { workerRefusal: decoder.workerRefusal } : {} });
    let batch = [];
    let closed = false;
    const send = async () => {
      if (batch.length === 0 || closed) return;
      const packets = batch;
      batch = [];
      try {
        const out = await decoder.decode(packets.map((p) => p.data));
        if (closed) return;
        let at = 0;
        packets.forEach((packet, i) => {
          const frames = out.frames[i];
          if (frames <= 0) return;
          const planes = Array.from({ length: out.channels }, () => new Float32Array(frames));
          for (let f = 0; f < frames; f++) for (let c = 0; c < out.channels; c++) planes[c][f] = out.pcm[(at + f) * out.channels + c];
          at += frames;
          onFrame({ planes, sampleRate: out.sampleRate, timestamp: packet.timestamp });
        });
      } catch (error) {
        onError(error);
      }
    };
    return {
      decode: async (p) => {
        batch.push(p);
        if (p.timestamp - batch[0].timestamp >= BATCH_S) await send();
      },
      flush: send,
      close: () => {
        if (closed) return;
        closed = true;
        decoder.close();
      }
    };
  };
}
function codecNamesFor(codecId, codecPrivate) {
  if (codecId === "A_AC3") return { name: "ac3", webCodecs: "ac-3" };
  if (codecId === "A_EAC3") return { name: "eac3", webCodecs: "ec-3" };
  if (codecId === "A_DTS" || codecId.startsWith("A_DTS/")) return { name: "dts", webCodecs: "dtsc" };
  if (codecId === "A_FLAC") return { name: "flac", webCodecs: "flac" };
  if (codecId === "A_OPUS") return { name: "opus", webCodecs: "opus" };
  if (codecId === "A_MPEG/L3") return { name: "mp3", webCodecs: "mp3" };
  if (codecId.startsWith("A_PCM/")) return { name: "pcm", webCodecs: "pcm" };
  if (codecId === "A_AAC" || codecId.startsWith("A_AAC/")) {
    let aot = 2;
    if (codecPrivate && codecPrivate.length >= 1) {
      aot = codecPrivate[0] >> 3;
      if (aot === 31 && codecPrivate.length >= 2) aot = 32 + ((codecPrivate[0] & 7) << 3 | codecPrivate[1] >> 5);
    }
    return { name: "aac", webCodecs: `mp4a.40.${aot}` };
  }
  return null;
}
function webCodecsOpener(config) {
  return async (onFrame, onError) => {
    let expectedFirst = null;
    let offset = null;
    let waiting = null;
    const decoder = new AudioDecoder({
      output: (data) => {
        waiting?.();
        waiting = null;
        try {
          const ts = data.timestamp / 1e6;
          if (offset === null) offset = expectedFirst !== null ? expectedFirst - ts : 0;
          const planes = [];
          for (let c = 0; c < data.numberOfChannels; c++) {
            const plane = new Float32Array(data.numberOfFrames);
            data.copyTo(plane, { planeIndex: c, format: "f32-planar" });
            planes.push(plane);
          }
          onFrame({ planes, sampleRate: data.sampleRate, timestamp: ts + offset });
        } catch (error) {
          onError(error);
        } finally {
          data.close();
        }
      },
      error: (error) => onError(error)
    });
    decoder.addEventListener("dequeue", () => {
      waiting?.();
      waiting = null;
    });
    decoder.configure(config);
    return {
      decode: async (p) => {
        expectedFirst ??= p.timestamp;
        decoder.decode(new EncodedAudioChunk({ type: "key", timestamp: Math.round(p.timestamp * 1e6), duration: Math.round(p.duration * 1e6), data: p.data }));
        while (decoder.decodeQueueSize > 8) await new Promise((resolve) => waiting = resolve);
      },
      flush: async () => {
        await decoder.flush();
        offset = null;
        expectedFirst = null;
      },
      close: () => {
        if (decoder.state !== "closed") decoder.close();
      }
    };
  };
}
function flacOpener(config) {
  return async (onFrame, onError) => {
    const { FLACDecoder } = await import("./lumen-flac-YGIJ4G6V.js");
    let decoder = new FLACDecoder();
    await decoder.ready;
    const description = config.description;
    if (description) {
      const bytes = ArrayBuffer.isView(description) ? new Uint8Array(description.buffer, description.byteOffset, description.byteLength) : new Uint8Array(description);
      await decoder.decodeFrames([streamInfoHeader(bytes)]);
    }
    return {
      decode: async (p) => {
        try {
          if (!decoder) throw new Error("d\xE9codeur FLAC non initialis\xE9");
          const decoded = await decoder.decodeFrames([p.data]);
          if (decoded.samplesDecoded === 0) {
            if (decoded.errors.length > 0) throw new Error(`FLAC illisible : ${decoded.errors[0].message}`);
            return;
          }
          const frames = decoded.samplesDecoded;
          onFrame({ planes: decoded.channelData.map((plane) => plane.slice(0, frames)), sampleRate: decoded.sampleRate, timestamp: p.timestamp });
        } catch (error) {
          onError(error);
        }
      },
      flush: async () => {
      },
      close: () => {
        decoder?.free();
        decoder = null;
      }
    };
  };
}
function stoppable(inner, cancel) {
  const wrapped = {
    next: (...args) => inner.next(...args),
    return: (value) => {
      cancel.stopped = true;
      return inner.return(value);
    },
    throw: (error) => {
      cancel.stopped = true;
      return inner.throw(error);
    },
    [Symbol.asyncIterator]() {
      return wrapped;
    }
  };
  return wrapped;
}
function pcmOpener(codecId, bitDepth, channels, sampleRate) {
  const big = codecId === "A_PCM/INT/BIG";
  const float = codecId === "A_PCM/FLOAT/IEEE";
  const bytes = bitDepth / 8;
  if (![1, 2, 3, 4, 8].includes(bytes) || float && bytes < 4) throw new Error(`PCM ${bitDepth} bits hors de ce chemin`);
  const read = (view, at) => {
    if (float) return bytes === 4 ? view.getFloat32(at, !big) : view.getFloat64(at, !big);
    switch (bytes) {
      case 1:
        return (view.getUint8(at) - 128) / 128;
      case 2:
        return view.getInt16(at, !big) / 32768;
      case 3: {
        const b0 = view.getUint8(at);
        const b1 = view.getUint8(at + 1);
        const b2 = view.getUint8(at + 2);
        const v = big ? b0 << 16 | b1 << 8 | b2 : b2 << 16 | b1 << 8 | b0;
        return (v << 8 >> 8) / 8388608;
      }
      default:
        return view.getInt32(at, !big) / 2147483648;
    }
  };
  return async (onFrame) => ({
    decode: async (p) => {
      const frames = Math.floor(p.data.byteLength / (bytes * channels));
      if (frames <= 0) return;
      const view = new DataView(p.data.buffer, p.data.byteOffset, p.data.byteLength);
      const planes = Array.from({ length: channels }, () => new Float32Array(frames));
      for (let i = 0; i < frames; i++) for (let c = 0; c < channels; c++) planes[c][i] = read(view, (i * channels + c) * bytes);
      onFrame({ planes, sampleRate, timestamp: p.timestamp });
    },
    flush: async () => {
    },
    close: () => {
    }
  });
}
async function openOwnAudioTrack(source, file, trackNumber) {
  const track = file.tracks.find((t) => t.number === trackNumber && t.type === "audio");
  if (!track) throw new Error(`piste son ${trackNumber} introuvable`);
  const names = codecNamesFor(track.codecId, track.codecPrivate);
  if (!names) throw new Error(`codec ${track.codecId} hors de ce chemin`);
  const sampleRate = track.audio?.sampleRate ?? 48e3;
  const numberOfChannels = track.audio?.channels ?? 2;
  const config = {
    codec: names.webCodecs,
    sampleRate,
    numberOfChannels,
    ...track.codecPrivate ? { description: track.codecPrivate } : {}
  };
  let opener;
  let decoderName;
  if (names.name === "ac3" || names.name === "eac3" || names.name === "dts") {
    opener = ownWasmOpener(names.name);
    decoderName = `ffmpeg-7.1.5-${names.name}`;
  } else if (names.name === "pcm") {
    opener = pcmOpener(track.codecId, track.audio?.bitDepth ?? 16, numberOfChannels, sampleRate);
    decoderName = "pcm";
  } else if (names.name === "flac") {
    opener = flacOpener(config);
    decoderName = "flac";
  } else if (names.name === "opus" || names.name === "aac" || names.name === "mp3") {
    const Decoder = globalThis.AudioDecoder;
    const answer = Decoder ? await Decoder.isConfigSupported(config).catch(() => null) : null;
    if (!answer?.supported) throw new Error(`le d\xE9codeur logiciel refuse ${names.name}`);
    opener = webCodecsOpener(config);
    decoderName = "navigateur";
  } else {
    throw new Error(`aucun d\xE9codeur pour ${names.name}`);
  }
  const stats = newAudioDemuxStats();
  if (!decoderName.startsWith("ffmpeg-")) noteLumenFacts({ decoder: decoderName });
  return {
    format: { sampleRate, numberOfChannels },
    samples: (fromSeconds) => {
      const cancel = { stopped: false };
      return stoppable(decodedFrom(audioPacketsFrom(source, file, trackNumber, fromSeconds, stats, cancel), opener, fromSeconds, sampleRate, cancel), cancel);
    },
    stats,
    decoder: decoderName
  };
}
var __testing = { flacOpener, pcmOpener };
export {
  __testing,
  codecNamesFor,
  openOwnAudioTrack
};
//# sourceMappingURL=lumen-ownAudio-KRJO4W3T.js.map
