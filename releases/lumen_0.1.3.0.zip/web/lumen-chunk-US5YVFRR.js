import {
  noteLumenWorker
} from "./lumen-chunk-TM3DN4G5.js";

// src/engine/truehd/truehdWorker.mjs
function decodeBlocks(m, decoder, scratch, blocks) {
  const frames = new Int32Array(blocks.length);
  const parts = [];
  let channels = 0;
  let sampleRate = 0;
  let errors = 0;
  let total = 0;
  blocks.forEach((block, i) => {
    if (block.length > scratch.inputSize) {
      if (scratch.input) m._free(scratch.input);
      scratch.inputSize = Math.max(block.length, 64 * 1024);
      scratch.input = m._malloc(scratch.inputSize);
    }
    m.HEAPU8.set(block, scratch.input);
    const n = m._thd_decode(decoder, scratch.input, block.length);
    if (n < 0) throw new Error("m\xE9moire \xE9puis\xE9e dans le d\xE9codeur TrueHD");
    errors += m._thd_errors(decoder);
    if (n === 0) return;
    channels = m._thd_channels(decoder);
    sampleRate = m._thd_sample_rate(decoder);
    frames[i] = n;
    const at2 = m._thd_output(decoder) / 4;
    parts.push(m.HEAPF32.slice(at2, at2 + n * channels));
    total += n * channels;
  });
  const pcm = new Float32Array(total);
  let at = 0;
  for (const part of parts) {
    pcm.set(part, at);
    at += part.length;
  }
  return { pcm, frames, channels, sampleRate, errors };
}
function closeDecoder(m, decoder, scratch) {
  if (scratch.input) m._free(scratch.input);
  scratch.input = 0;
  scratch.inputSize = 0;
  m._thd_close(decoder);
}
function serveTrueHd(scope) {
  let wasm = null;
  const decoders2 = /* @__PURE__ */ new Map();
  let chain = Promise.resolve();
  const answer = (message, transfer) => scope.postMessage(message, transfer ?? []);
  const reason = (error) => error instanceof Error ? error.message : String(error);
  async function handle(message) {
    switch (message.op) {
      case "init":
        try {
          const { default: createTrueHd } = await import(
            /* webpackIgnore: true */
            /* turbopackIgnore: true */
            message.wasm
          );
          wasm = await createTrueHd();
          answer({ ready: true });
        } catch (error) {
          answer({ ready: false, error: reason(error) });
        }
        return;
      case "open": {
        try {
          if (!wasm) throw new Error("module TrueHD absent");
          const decoder = wasm._thd_open(typeof message.which === "number" ? message.which : message.mlp ? 1 : 0);
          if (!decoder) throw new Error("le d\xE9codeur TrueHD n'a pas pu s'ouvrir");
          decoders2.set(message.id, { decoder, scratch: { input: 0, inputSize: 0 } });
          answer({ req: message.req, ok: true });
        } catch (error) {
          answer({ req: message.req, error: reason(error) });
        }
        return;
      }
      case "decode": {
        try {
          const entry = decoders2.get(message.id);
          if (!entry) throw new Error("d\xE9codeur TrueHD ferm\xE9");
          const blocks = [];
          let at = 0;
          for (const size of message.sizes) {
            blocks.push(new Uint8Array(message.data, at, size));
            at += size;
          }
          const batch = decodeBlocks(wasm, entry.decoder, entry.scratch, blocks);
          answer({ req: message.req, ok: batch }, [batch.pcm.buffer, batch.frames.buffer]);
        } catch (error) {
          answer({ req: message.req, error: reason(error) });
        }
        return;
      }
      case "reset": {
        const entry = decoders2.get(message.id);
        if (entry) wasm._thd_reset(entry.decoder);
        return;
      }
      case "close": {
        const entry = decoders2.get(message.id);
        if (!entry) return;
        decoders2.delete(message.id);
        closeDecoder(wasm, entry.decoder, entry.scratch);
        return;
      }
    }
  }
  scope.onmessage = (event) => {
    const message = event.data;
    chain = chain.then(() => handle(message)).catch(() => {
    });
  };
  answer({ listening: true });
}
if (typeof WorkerGlobalScope !== "undefined" && typeof self !== "undefined" && self instanceof WorkerGlobalScope) {
  serveTrueHd(self);
}

// src/engine/truehd/truehdCore.ts
var loaded = null;
function instance() {
  if (!loaded) {
    loaded = import("./truehd-wasm.mjs").then(({ default: createTrueHd }) => createTrueHd());
    loaded.catch(() => {
      loaded = null;
    });
  }
  return loaded;
}
var TrueHdCore = class _TrueHdCore {
  constructor(wasm, decoder) {
    this.wasm = wasm;
    this.decoder = decoder;
  }
  wasm;
  decoder;
  scratch = { input: 0, inputSize: 0 };
  /** Libéré : plus rien ne doit toucher à son contexte, sur une instance partagée par la page. */
  closed = false;
  static async create(mlp) {
    const wasm = await instance();
    const decoder = wasm._thd_open(mlp ? 1 : 0);
    if (!decoder) throw new Error("le d\xE9codeur TrueHD n'a pas pu s'ouvrir");
    return new _TrueHdCore(wasm, decoder);
  }
  decode(blocks) {
    if (this.closed) throw new Error("d\xE9codeur TrueHD ferm\xE9");
    return decodeBlocks(this.wasm, this.decoder, this.scratch, blocks);
  }
  /** Après un saut : le décodeur se resynchronise seul sur la synchronisation majeure suivante. */
  reset() {
    if (this.closed) return;
    this.wasm._thd_reset(this.decoder);
  }
  close() {
    if (this.closed) return;
    this.closed = true;
    closeDecoder(this.wasm, this.decoder, this.scratch);
  }
};

// src/engine/ac3dts/ac3dtsCore.ts
var loaded2 = null;
function instance2() {
  if (!loaded2) {
    loaded2 = import("./ac3dts-wasm.mjs").then(({ default: create }) => create());
    loaded2.catch(() => {
      loaded2 = null;
    });
  }
  return loaded2;
}
var Ac3DtsCore = class _Ac3DtsCore {
  constructor(wasm, decoder) {
    this.wasm = wasm;
    this.decoder = decoder;
  }
  wasm;
  decoder;
  scratch = { input: 0, inputSize: 0 };
  closed = false;
  static async create(which) {
    const wasm = await instance2();
    const decoder = wasm._thd_open(which);
    if (!decoder) throw new Error("le d\xE9codeur AC-3/DTS n'a pas pu s'ouvrir");
    return new _Ac3DtsCore(wasm, decoder);
  }
  decode(blocks) {
    if (this.closed) throw new Error("d\xE9codeur AC-3/DTS ferm\xE9");
    return decodeBlocks(this.wasm, this.decoder, this.scratch, blocks);
  }
  reset() {
    if (this.closed) return;
    this.wasm._thd_reset(this.decoder);
  }
  close() {
    if (this.closed) return;
    this.closed = true;
    closeDecoder(this.wasm, this.decoder, this.scratch);
  }
};

// src/engine/truehd/truehdDecoder.ts
function yieldToBrowser() {
  if (typeof MessageChannel === "undefined") return new Promise((resolve) => setTimeout(resolve, 0));
  return new Promise((resolve) => {
    const channel = new MessageChannel();
    channel.port1.onmessage = () => {
      channel.port1.close();
      resolve();
    };
    channel.port2.postMessage(null);
  });
}
async function openOnMainThread(kind, open, workerRefusal) {
  if (kind === "ac3dts") noteLumenWorker("mainThread");
  const core = kind === "truehd" ? await TrueHdCore.create(!!open.mlp) : await Ac3DtsCore.create(open.which);
  return {
    async decode(blocks) {
      const batch = core.decode(blocks);
      await yieldToBrowser();
      return batch;
    },
    reset: () => core.reset(),
    close: () => core.close(),
    thread: "principal",
    workerRefusal
  };
}
var READY_TIMEOUT_MS = 2e4;
var IDLE_MS = 1e4;
var LABEL = { truehd: "TrueHD", ac3dts: "AC-3/DTS" };
var hosts = /* @__PURE__ */ new Map();
var refusedHere = /* @__PURE__ */ new Map();
var requests = 0;
var decoders = 0;
var reasonOf = (error) => (error instanceof Error ? error.message : String(error)).slice(0, 160);
var lost = (h, error) => new Error(`worker ${LABEL[h.kind]} perdu (${error.message})`);
function retire(h, error) {
  if (h.dead) return;
  if (h.kind === "ac3dts" && !/terminé$/.test(error.message)) noteLumenWorker("lost");
  h.dead = error;
  if (h.idle) clearTimeout(h.idle);
  h.idle = null;
  for (const entry of h.pending.values()) entry.reject(lost(h, error));
  h.pending.clear();
  h.worker.terminate();
  if (hosts.get(h.kind) === h) hosts.delete(h.kind);
}
function releaseIfIdle(h) {
  if (h.dead || h.users > 0 || h.pending.size > 0 || h.idle) return;
  h.idle = setTimeout(() => {
    h.idle = null;
    if (h.users === 0 && h.pending.size === 0) retire(h, new Error(`worker ${LABEL[h.kind]} termin\xE9`));
  }, IDLE_MS);
}
function absoluteHref(url) {
  const base = globalThis.location?.href;
  return base ? new URL(url.href, base).href : new URL(url.href).href;
}
function createHost(kind) {
  if (kind === "ac3dts") noteLumenWorker("created");
  const workerUrl = new URL("./truehdWorker.mjs", import.meta.url);
  const wasmUrl = kind === "truehd" ? new URL("./truehd-wasm.mjs", import.meta.url) : new URL("./ac3dts-wasm.mjs", import.meta.url);
  const bootstrap = URL.createObjectURL(new Blob([`import ${JSON.stringify(absoluteHref(workerUrl))};
`], { type: "text/javascript" }));
  let worker;
  try {
    worker = new Worker(bootstrap, { type: "module", name: kind });
  } catch (error) {
    URL.revokeObjectURL(bootstrap);
    throw error;
  }
  let settle;
  const h = {
    kind,
    worker,
    ready: new Promise((resolve, reject) => settle = { resolve, reject }),
    pending: /* @__PURE__ */ new Map(),
    users: 0,
    idle: null,
    dead: null
  };
  const fail = (error) => {
    settle.reject(error);
    retire(h, error);
  };
  h.ready.catch(() => {
  });
  const timer = setTimeout(() => fail(new Error(`pas pr\xEAt en ${READY_TIMEOUT_MS / 1e3} s`)), READY_TIMEOUT_MS);
  const settled = () => {
    clearTimeout(timer);
    URL.revokeObjectURL(bootstrap);
  };
  h.ready.then(settled, settled);
  worker.onmessage = (event) => {
    const data = event.data;
    if (data.listening) {
      worker.postMessage({ op: "init", wasm: absoluteHref(wasmUrl) });
      return;
    }
    if (data.ready !== void 0) {
      if (data.ready) settle.resolve();
      else fail(new Error(data.error ?? "module non charg\xE9"));
      return;
    }
    const entry = h.pending.get(data.req ?? -1);
    if (!entry) return;
    h.pending.delete(data.req);
    if (data.error !== void 0) entry.reject(new Error(data.error));
    else entry.resolve(data.ok);
    releaseIfIdle(h);
  };
  worker.onerror = (event) => {
    event.preventDefault();
    fail(new Error(event.message || "le worker n'a pas d\xE9marr\xE9"));
  };
  worker.onmessageerror = () => fail(new Error("message illisible"));
  return h;
}
function call(h, message, transfer = []) {
  if (h.dead) return Promise.reject(lost(h, h.dead));
  const req = ++requests;
  return new Promise((resolve, reject) => {
    h.pending.set(req, { resolve, reject });
    h.worker.postMessage({ ...message, req }, transfer);
  });
}
async function openInWorker(h, open) {
  const id = ++decoders;
  await call(h, { op: "open", id, ...open });
  let closed = false;
  return {
    decode(blocks) {
      const sizes = new Uint32Array(blocks.length);
      let total = 0;
      blocks.forEach((block, i) => {
        sizes[i] = block.length;
        total += block.length;
      });
      const data = new ArrayBuffer(total);
      const bytes = new Uint8Array(data);
      let at = 0;
      for (const block of blocks) {
        bytes.set(block, at);
        at += block.length;
      }
      return call(h, { op: "decode", id, data, sizes }, [data, sizes.buffer]);
    },
    // Sans réponse : le worker traite ses messages dans l'ordre, donc ce `reset` passe après le lot
    // déjà envoyé et avant ceux du nouvel endroit — comme sur le fil principal. Les lots d'avant le
    // saut qui reviennent encore sont jetés par truehdAudio.ts (`generation`).
    reset() {
      if (!closed && !h.dead) h.worker.postMessage({ op: "reset", id });
    },
    close() {
      if (closed) return;
      closed = true;
      if (!h.dead) h.worker.postMessage({ op: "close", id });
      h.users--;
      releaseIfIdle(h);
    },
    thread: "worker"
  };
}
function openTrueHdDecoder(mlp) {
  return openWasmDecoder("truehd", { mlp });
}
function openAc3DtsDecoder(which) {
  return openWasmDecoder("ac3dts", { which });
}
async function openWasmDecoder(kind, open) {
  const refused = refusedHere.get(kind);
  if (refused !== void 0) return openOnMainThread(kind, open, refused);
  if (typeof Worker === "undefined") return openOnMainThread(kind, open, "pas de Worker");
  let h;
  try {
    h = hosts.get(kind) ?? createHost(kind);
    hosts.set(kind, h);
  } catch (error) {
    const reason = reasonOf(error);
    refusedHere.set(kind, reason);
    return openOnMainThread(kind, open, reason);
  }
  h.users++;
  if (h.idle) clearTimeout(h.idle);
  h.idle = null;
  try {
    await h.ready;
  } catch (error) {
    h.users--;
    const reason = reasonOf(error);
    refusedHere.set(kind, reason);
    return openOnMainThread(kind, open, reason);
  }
  try {
    return await openInWorker(h, open);
  } catch (error) {
    h.users--;
    releaseIfIdle(h);
    throw error;
  }
}
async function warmTrueHd() {
  await Promise.all(
    [new URL("./truehdWorker.mjs", import.meta.url), new URL("./truehd-wasm.mjs", import.meta.url)].map(async (url) => {
      const response = await fetch(url);
      await response.arrayBuffer();
    })
  );
}
async function warmAc3Dts() {
  await Promise.all(
    [new URL("./truehdWorker.mjs", import.meta.url), new URL("./ac3dts-wasm.mjs", import.meta.url)].map(async (url) => {
      const response = await fetch(url);
      await response.arrayBuffer();
    })
  );
}

export {
  yieldToBrowser,
  absoluteHref,
  openTrueHdDecoder,
  openAc3DtsDecoder,
  warmTrueHd,
  warmAc3Dts
};
//# sourceMappingURL=lumen-chunk-US5YVFRR.js.map
