// src/engine/lumenFacts.ts
var last = null;
function noteLumenFacts(facts) {
  last = facts;
}
function takeLumenFacts() {
  const facts = last;
  last = null;
  return facts;
}
var counts = { opened: 0, closed: 0, open: 0, maxOpen: 0, workers: 0, lost: 0, mainThread: 0 };
function noteLumenDecoderOpened() {
  counts.opened += 1;
  counts.open += 1;
  counts.maxOpen = Math.max(counts.maxOpen, counts.open);
}
function noteLumenDecoderClosed() {
  counts.closed += 1;
  counts.open = Math.max(0, counts.open - 1);
}
function noteLumenWorker(event) {
  if (event === "created") counts.workers += 1;
  else if (event === "lost") counts.lost += 1;
  else counts.mainThread += 1;
}

export {
  noteLumenFacts,
  takeLumenFacts,
  noteLumenDecoderOpened,
  noteLumenDecoderClosed,
  noteLumenWorker
};
//# sourceMappingURL=lumen-chunk-TM3DN4G5.js.map
