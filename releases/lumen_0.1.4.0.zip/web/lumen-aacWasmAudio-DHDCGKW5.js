import {
  contiguousAudio
} from "./lumen-chunk-J542HSWT.js";
import {
  clusterOffsetForTime,
  createSampleReader,
  openMediaFile
} from "./lumen-chunk-OO4ZPETN.js";
import {
  yieldToBrowser
} from "./lumen-chunk-US5YVFRR.js";
import "./lumen-chunk-TM3DN4G5.js";
import "./lumen-chunk-XI2GCOGB.js";

// src/engine/aac/aacCore.ts
var loaded = null;
function instance() {
  if (!loaded) {
    loaded = import("./aac-wasm.mjs").then(({ default: createAac }) => createAac());
    loaded.catch(() => {
      loaded = null;
    });
  }
  return loaded;
}
var AacCore = class _AacCore {
  constructor(wasm, decoder) {
    this.wasm = wasm;
    this.decoder = decoder;
  }
  wasm;
  decoder;
  input = 0;
  inputSize = 0;
  closed = false;
  /** `asc` : la configuration AAC de la piste (AudioSpecificConfig, PCE compris). */
  static async create(asc) {
    const wasm = await instance();
    const at = wasm._malloc(asc.length);
    wasm.HEAPU8.set(asc, at);
    const decoder = wasm._aac_open(at, asc.length);
    wasm._free(at);
    if (!decoder) throw new Error("le d\xE9codeur AAC n'a pas pu s'ouvrir");
    return new _AacCore(wasm, decoder);
  }
  decode(blocks) {
    if (this.closed) throw new Error("d\xE9codeur AAC ferm\xE9");
    const m = this.wasm;
    const frames = new Int32Array(blocks.length);
    const parts = [];
    let channels = 0;
    let sampleRate = 0;
    let errors = 0;
    let total = 0;
    blocks.forEach((block, i) => {
      if (block.length > this.inputSize) {
        if (this.input) m._free(this.input);
        this.inputSize = Math.max(block.length, 16 * 1024);
        this.input = m._malloc(this.inputSize);
      }
      m.HEAPU8.set(block, this.input);
      const n = m._aac_decode(this.decoder, this.input, block.length);
      if (n < 0) throw new Error("m\xE9moire \xE9puis\xE9e dans le d\xE9codeur AAC");
      errors += m._aac_errors(this.decoder);
      if (n === 0) return;
      channels = m._aac_channels(this.decoder);
      sampleRate = m._aac_sample_rate(this.decoder);
      frames[i] = n;
      const at2 = m._aac_output(this.decoder) / 4;
      parts.push(m.HEAPF32.slice(at2, at2 + n * channels));
      total += n * channels;
    });
    const pcm = new Float32Array(total);
    let at = 0;
    for (const part of parts) {
      pcm.set(part, at);
      at += part.length;
    }
    return { pcm, frames, channels, sampleRate, errors };
  }
  /** La disposition rendue par libavcodec (masque en ordre natif), 0 si elle n'est pas nommée. */
  layoutMask() {
    if (this.closed) return 0;
    return (this.wasm._aac_layout_hi(this.decoder) >>> 0) * 2 ** 32 + (this.wasm._aac_layout_lo(this.decoder) >>> 0);
  }
  reset() {
    if (this.closed) return;
    this.wasm._aac_reset(this.decoder);
  }
  close() {
    if (this.closed) return;
    this.closed = true;
    if (this.input) this.wasm._free(this.input);
    this.input = 0;
    this.inputSize = 0;
    this.wasm._aac_close(this.decoder);
  }
};

// src/engine/aac/aacWasmAudio.ts
var BATCH_US = 25e4;
var PREROLL_US = 1e5;
async function openWasmAacTrack(source, trackNumber, parsed) {
  const file = parsed ?? await openMediaFile(source);
  const found = file.tracks.find((t) => t.number === trackNumber && t.type === "audio");
  if (!found || found.codecId !== "A_AAC" || !found.codecPrivate) throw new Error("piste AAC introuvable");
  const track = found;
  const core = await AacCore.create(track.codecPrivate);
  const format = {
    sampleRate: track.audio?.sampleRate ?? 48e3,
    numberOfChannels: track.audio?.channels ?? 2
  };
  let generation = 0;
  let closed = false;
  async function* samples(fromSeconds) {
    const mine = ++generation;
    core.reset();
    const fromUs = Math.max(0, fromSeconds) * 1e6;
    const start = clusterOffsetForTime(file, Math.max(0, fromUs - PREROLL_US)) ?? file.firstClusterOffset ?? file.segmentDataStart;
    const reader = createSampleReader(source, file, start);
    let blocks = [];
    let times = [];
    let dropFirst = true;
    const decodeBatch = async () => {
      if (closed || mine !== generation) return null;
      const batch = core.decode(blocks);
      if (dropFirst) {
        dropFirst = false;
        const firstIndex = batch.frames.findIndex((n) => n > 0);
        if (firstIndex >= 0) {
          const skip = batch.frames[firstIndex] * batch.channels;
          batch.frames[firstIndex] = 0;
          batch.pcm = batch.pcm.subarray(skip);
        }
      }
      const pieces = contiguousAudio(times, batch, fromSeconds, format.numberOfChannels);
      blocks = [];
      times = [];
      await yieldToBrowser();
      return pieces;
    };
    for (; ; ) {
      if (closed || mine !== generation) return;
      const sample = await reader.next();
      if (!sample) break;
      if (sample.trackNumber !== track.number) continue;
      if (sample.timestampUs < fromUs - PREROLL_US) continue;
      blocks.push(sample.data);
      times.push(sample.timestampUs);
      if (times[times.length - 1] - times[0] < BATCH_US) continue;
      const pieces = await decodeBatch();
      if (!pieces || closed || mine !== generation) return;
      for (const piece of pieces) yield piece;
    }
    if (blocks.length > 0 && !closed && mine === generation) {
      for (const piece of await decodeBatch() ?? []) yield piece;
    }
  }
  return {
    format,
    samples,
    close() {
      closed = true;
      core.close();
    }
  };
}
export {
  openWasmAacTrack
};
//# sourceMappingURL=lumen-aacWasmAudio-DHDCGKW5.js.map
