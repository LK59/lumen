import {
  clusterOffsetForTime,
  createSampleReader,
  openMediaFile
} from "./lumen-chunk-RIJONPO7.js";
import {
  openTrueHdDecoder
} from "./lumen-chunk-US5YVFRR.js";

// src/engine/truehd/truehdAudio.ts
var TRUEHD_CODECS = /* @__PURE__ */ new Set(["A_TRUEHD", "A_MLP"]);
var BATCH_US = 25e4;
var PREROLL_US = 1e6;
var CONTIGUOUS_S = 2e-3;
function contiguousAudio(timestampsUs, batch, fromSeconds, channels) {
  const out = [];
  const rate = batch.sampleRate;
  const source = batch.channels;
  let offset = 0;
  let group = null;
  const close = () => {
    if (!group) return;
    const planes = Array.from({ length: channels }, () => new Float32Array(group.frames));
    const kept = Math.min(channels, source);
    for (let i = 0; i < group.frames; i++) {
      const base = (group.start + i) * source;
      for (let c = 0; c < kept; c++) planes[c][i] = batch.pcm[base + c];
    }
    out.push({ planes, sampleRate: rate, timestampSeconds: group.first });
    group = null;
  };
  for (let i = 0; i < timestampsUs.length; i++) {
    const frames = batch.frames[i];
    if (frames <= 0) {
      close();
      continue;
    }
    const laced = i > 0 && timestampsUs[i] === timestampsUs[i - 1] && group !== null;
    const start = laced ? group.next : timestampsUs[i] / 1e6;
    const end = start + frames / rate;
    if (end <= fromSeconds) {
      offset += frames;
      continue;
    }
    if (group && Math.abs(start - group.next) > CONTIGUOUS_S) close();
    if (!group) group = { start: offset, frames: 0, first: start, next: start };
    group.frames += frames;
    group.next = end;
    offset += frames;
  }
  close();
  return out;
}
async function openTrueHdTrack(source, trackNumber, parsed) {
  const file = parsed ?? await openMediaFile(source);
  const found = file.tracks.find((t) => t.number === trackNumber && t.type === "audio");
  if (!found || !TRUEHD_CODECS.has(found.codecId)) throw new Error("piste TrueHD introuvable");
  const track = found;
  const decoder = await openTrueHdDecoder(track.codecId === "A_MLP");
  const format = {
    sampleRate: track.audio?.sampleRate ?? 48e3,
    numberOfChannels: track.audio?.channels ?? 8
  };
  let generation = 0;
  let closed = false;
  async function* samples(fromSeconds) {
    const mine = ++generation;
    decoder.reset();
    const fromUs = Math.max(0, fromSeconds) * 1e6;
    const start = clusterOffsetForTime(file, Math.max(0, fromUs - PREROLL_US)) ?? file.firstClusterOffset ?? file.segmentDataStart;
    const reader = createSampleReader(source, file, start);
    let blocks = [];
    let times = [];
    const decodeBatch = async () => {
      if (closed || mine !== generation) return null;
      const batch = await decoder.decode(blocks);
      const pieces = contiguousAudio(times, batch, fromSeconds, format.numberOfChannels);
      blocks = [];
      times = [];
      return pieces;
    };
    for (; ; ) {
      if (closed || mine !== generation) return;
      const sample = await reader.next();
      if (!sample) break;
      if (sample.trackNumber !== track.number) continue;
      if (sample.timestampUs < fromUs - PREROLL_US) continue;
      blocks.push(sample.data);
      times.push(sample.timestampUs);
      if (times[times.length - 1] - times[0] < BATCH_US) continue;
      const pieces = await decodeBatch();
      if (!pieces || closed || mine !== generation) return;
      for (const piece of pieces) yield piece;
    }
    if (blocks.length > 0 && !closed && mine === generation) {
      for (const piece of await decodeBatch() ?? []) yield piece;
    }
  }
  return {
    format,
    samples,
    close() {
      closed = true;
      decoder.close();
    },
    thread: decoder.thread,
    ...decoder.workerRefusal !== void 0 ? { workerRefusal: decoder.workerRefusal } : {}
  };
}

export {
  TRUEHD_CODECS,
  contiguousAudio,
  openTrueHdTrack
};
//# sourceMappingURL=lumen-chunk-N75FLDX4.js.map
