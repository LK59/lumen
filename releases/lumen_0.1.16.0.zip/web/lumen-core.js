import {
  CHUNK_SIZE,
  HttpByteSource,
  NetworkUnavailable,
  SessionEnded,
  audioConfigFor,
  av1CodecString,
  avcCodecString,
  clusterOffsetForTime,
  configureHost,
  createSampleReader,
  cueTimeAfter,
  cueTimeAtOrBefore,
  describeNetwork,
  diagInterval,
  diagMedia,
  diagNow,
  diagStallFacts,
  dolbyVisionCodecString,
  dolbyVisionInfo,
  forgetMediaHeader,
  hevcCodecString,
  holdsHandover,
  holdsPrepared,
  hostBuild,
  isNetworkFailure,
  isRandomAccessPoint,
  isRaslPicture,
  isReadAbandoned,
  isUnreadableZone,
  joinBytes,
  keptRangeAt,
  mediaHeaderKey,
  nalLengthSize,
  networkUnstable,
  openMediaFile,
  readingAs,
  strayUnits,
  subscribeNetworkTrouble,
  trace,
  traceElapsed,
  traceRecent,
  traceReset,
  traceText,
  withCappedLightLevels,
  withHostHeaders
} from "./lumen-chunk-RIJONPO7.js";
import {
  takeLumenFacts
} from "./lumen-chunk-TM3DN4G5.js";
import "./lumen-chunk-XI2GCOGB.js";

// src/engine/decodingInfo.ts
var TRANSFER = { 16: "pq", 18: "hlg" };
var GAMUT = { 9: "rec2020" };
var last = null;
function probeDecodingInfo(videoMimeType, track, sizeBytes, durationSeconds) {
  const capabilities = typeof navigator !== "undefined" ? navigator.mediaCapabilities : void 0;
  if (!capabilities?.decodingInfo || !track.video) return;
  const colour = track.video.colour;
  const transferFunction = colour?.transferCharacteristics !== void 0 ? TRANSFER[colour.transferCharacteristics] : void 0;
  const colorGamut = colour?.primaries !== void 0 ? GAMUT[colour.primaries] : void 0;
  const framerate = track.defaultDurationNs ? 1e9 / track.defaultDurationNs : 24;
  const bitrate = durationSeconds > 0 ? Math.round(sizeBytes * 8 / durationSeconds) : 1e7;
  const started = Date.now();
  last = null;
  try {
    capabilities.decodingInfo({
      type: "media-source",
      video: {
        contentType: videoMimeType,
        width: track.video.width,
        height: track.video.height,
        bitrate,
        framerate,
        ...transferFunction ? { transferFunction } : {},
        ...colorGamut ? { colorGamut } : {}
      }
    }).then(
      (info) => {
        last = { smooth: info.smooth, powerEfficient: info.powerEfficient, supported: info.supported };
        trace(
          `capacit\xE9s : ${info.supported ? "lisible" : "illisible"}, ${info.smooth ? "fluide" : "pas fluide"}, ${info.powerEfficient ? "\xE9conome" : "pas \xE9conome"} (${Date.now() - started} ms)`
        );
      },
      () => {
      }
    );
  } catch {
  }
}

// src/support/webkitEngine.ts
function isWebKitEngine(userAgent) {
  if (/Android/i.test(userAgent)) return false;
  if (/iP(hone|ad|od)/i.test(userAgent)) return true;
  return /Safari/i.test(userAgent) && !/Chrom(e|ium)|Edg\//i.test(userAgent);
}

// src/engine/hdrDisplay.ts
var HDR_CAP_CHOICES = ["auto", "native", 650, 400, 203, 150, 100];
var CHROME_SDR_WHITE_NITS = 203;
var HDR_CAP_KEY = "lumen.hdrLightCap";
var unstoredChoice;
function readHdrCapChoice() {
  if (unstoredChoice !== void 0) return unstoredChoice;
  try {
    const stored = globalThis.localStorage?.getItem(HDR_CAP_KEY);
    if (stored === "native") return "native";
    const nits = Number(stored);
    return stored && HDR_CAP_CHOICES.includes(nits) ? nits : "auto";
  } catch {
    return "auto";
  }
}
function autoHdrCap(userAgent, displayHdr) {
  return (isChromiumOnWindows(userAgent) || isChromiumOnLinux(userAgent)) && displayHdr === false ? CHROME_SDR_WHITE_NITS : null;
}
function isChromiumOnLinux(userAgent) {
  return /Linux/i.test(userAgent) && !/Android|CrOS/i.test(userAgent) && /Chrom(e|ium)|Edg\//i.test(userAgent) && !/Firefox/i.test(userAgent);
}
function hdrCapRelevant(userAgent, displayHdr) {
  return displayHdr === false && !isWebKitEngine(userAgent);
}
function resolveHdrCap(choice, userAgent, displayHdr) {
  if (!hdrCapRelevant(userAgent, displayHdr)) return null;
  if (choice === "native") return null;
  if (choice === "auto") return autoHdrCap(userAgent, displayHdr);
  return choice;
}
function isChromiumOnWindows(userAgent) {
  return /Windows/i.test(userAgent) && /Chrom(e|ium)|Edg\//i.test(userAgent) && !/Firefox/i.test(userAgent);
}
function displayIsHdr() {
  try {
    if (typeof matchMedia !== "function") return null;
    return matchMedia("(dynamic-range: high)").matches;
  } catch {
    return null;
  }
}
function hdrLightCap() {
  const userAgent = typeof navigator !== "undefined" ? navigator.userAgent : "";
  return resolveHdrCap(readHdrCapChoice(), userAgent, displayIsHdr());
}

// src/engine/seekArrival.ts
var SEEK_ARRIVAL_SECONDS = 1.5;
function seekArrived(currentSeconds, targetSeconds) {
  return Math.abs(currentSeconds - targetSeconds) <= SEEK_ARRIVAL_SECONDS;
}
var NO_INDEX_REACH_SECONDS = 1;
function reachable(seekable, seconds2) {
  return seekable || seconds2 <= NO_INDEX_REACH_SECONDS;
}

// src/engine/playerWarning.ts
function playerWarning(code, detail) {
  return detail ? { code, detail } : { code };
}

// src/engine/playerTrack.ts
function fromMatroskaTrack(track) {
  return {
    number: track.number,
    codecId: track.codecId,
    language: track.language,
    name: track.name,
    isDefault: track.isDefault,
    isForced: track.isForced,
    isHearingImpaired: track.isHearingImpaired,
    channels: track.audio?.channels ?? null
  };
}

// src/engine/bufferQueue.ts
var BUFFER_OPERATION_TIMEOUT_MS = 4e3;
var BUFFER_OPERATION_GIVE_UP_MS = 3e4;
var LATE_TIMER_MS = 1e3;
var LATE_RECHECK_MS = 250;
var ABORT_SETTLE_MS = 1e3;
var BufferQueue = class {
  /**
   * @param why Whatever the element and the source can say about a refusal. The `error` event
   * carries no detail of its own, so without this the one failure that stops playback on iOS
   * arrives as a sentence with nothing in it.
   */
  constructor(buffer, why = () => "") {
    this.buffer = buffer;
    this.why = why;
  }
  buffer;
  why;
  chain = Promise.resolve();
  closed = false;
  /**
   * La source est détruite : ce qui attend encore dans la file ne s'exécute plus.
   *
   * Un saut met un retrait en file derrière l'envoi en cours ; détruit entre-temps (un changement
   * de piste, une reconstruction), le lecteur voyait ce retrait partir sur un tampon qui n'était
   * plus le sien. Sans effet dans un navigateur — une source détachée refuse, et le refus est
   * avalé —, mais c'est l'inverse de ce que `destroy` promet, et le fuzz du 24/09/2026 le relevait
   * dans une séquence sur quarante qui reconstruit.
   */
  close() {
    this.closed = true;
  }
  enqueue(operation) {
    const run = this.chain.then(() => this.runOne(operation));
    this.chain = run.then(
      () => {
      },
      () => {
      }
    );
    return run;
  }
  runOne(operation) {
    if (this.closed) return Promise.resolve();
    return new Promise((resolve, reject) => {
      let settled = false;
      let timer = null;
      const startedAt = Date.now();
      const finish = (error) => {
        if (settled) return;
        settled = true;
        if (timer !== null) clearTimeout(timer);
        this.buffer.removeEventListener("updateend", onEnd);
        this.buffer.removeEventListener("error", onFail);
        if (error !== void 0) reject(error);
        else resolve();
      };
      const onEnd = () => finish();
      const onFail = () => finish(new Error(`Le navigateur a refus\xE9 une op\xE9ration sur le tampon. ${this.why()}`));
      const check = (dueAt2) => {
        timer = null;
        if (settled) return;
        if (!this.buffer.updating) {
          finish();
          return;
        }
        const now = Date.now();
        if (now - dueAt2 > LATE_TIMER_MS) {
          trace(`tampon occup\xE9, minuterie partie avec ${now - dueAt2} ms de retard (fil principal bloqu\xE9) : on attend`);
          const recheckAt = now + LATE_RECHECK_MS;
          timer = setTimeout(() => check(recheckAt), LATE_RECHECK_MS);
          return;
        }
        const elapsed = now - startedAt;
        if (elapsed < BUFFER_OPERATION_GIVE_UP_MS) {
          const wait = Math.min(BUFFER_OPERATION_TIMEOUT_MS, BUFFER_OPERATION_GIVE_UP_MS - elapsed);
          trace(`tampon toujours occup\xE9 apr\xE8s ${(elapsed / 1e3).toFixed(1)} s : on attend, la file reste tenue`);
          const nextAt = now + wait;
          timer = setTimeout(() => check(nextAt), wait);
          return;
        }
        giveUp(elapsed);
      };
      const giveUp = (elapsed) => {
        const error = new Error(`Le tampon n'a pas r\xE9pondu en ${Math.round(elapsed / 1e3)} s. ${this.why()}`);
        this.buffer.removeEventListener("updateend", onEnd);
        this.buffer.removeEventListener("error", onFail);
        let released = false;
        let fallback = null;
        const release = () => {
          if (released) return;
          released = true;
          if (fallback !== null) clearTimeout(fallback);
          this.buffer.removeEventListener("updateend", release);
          finish(error);
        };
        this.buffer.addEventListener("updateend", release);
        fallback = setTimeout(release, ABORT_SETTLE_MS);
        try {
          this.buffer.abort();
        } catch {
          release();
        }
      };
      this.buffer.addEventListener("updateend", onEnd);
      this.buffer.addEventListener("error", onFail);
      try {
        operation();
        if (!this.buffer.updating) {
          finish();
          return;
        }
      } catch (error) {
        finish(error);
        return;
      }
      const dueAt = Date.now() + BUFFER_OPERATION_TIMEOUT_MS;
      timer = setTimeout(() => check(dueAt), BUFFER_OPERATION_TIMEOUT_MS);
    });
  }
};

// src/engine/timeRanges.ts
function rangeAround(ranges, x, slack) {
  for (let i = 0; i < ranges.length; i++) {
    if (ranges.start(i) <= x + slack && x < ranges.end(i)) return i;
  }
  return -1;
}
function startJustAfter(ranges, x, slack) {
  for (let i = 0; i < ranges.length; i++) {
    const start = ranges.start(i);
    if (start > x && start - x <= slack && x < ranges.end(i)) return start;
  }
  return null;
}

// src/engine/seekLifecycle.ts
var OWN_MOVE_MS = 2e3;
var SeekLifecycle = class {
  /** Demandé, pas encore servi. Une rafale en demande des dizaines : seul le dernier compte. */
  requested = null;
  /** La dernière cible que la source a servie ou posée. */
  lastTarget = -1;
  /**
   * Le déplacement que la source vient de faire, attendu une seule fois, et brièvement.
   *
   * Reconnu jusqu'au 22/09/2026 par la seule proximité de `lastTarget` — durable, elle : tout saut
   * du spectateur à moins de 0,25 s de la dernière position posée par la source passait pour le
   * sien, des heures après. « Revoir » à la fin d'un film restait ainsi figé à 0:00, la source ayant
   * posé la tête à 0,24 s à l'ouverture. Un jeton, pris au premier `seeking` qui lui correspond, et
   * qui expire : le `seeking` d'une écriture de `currentTime` suit en quelques millisecondes.
   */
  ownMove = null;
  /** En route vers sa cible, depuis l'événement `seeking` jusqu'à l'arrivée. */
  intent = null;
  /** Un saut est demandé ; il remplace celui qui attendait encore. */
  request(seconds2) {
    this.requested = seconds2;
  }
  /**
   * La source commence à le servir : c'est désormais sa cible. Le jeton de déplacement, lui, n'est
   * posé qu'au moment où elle écrit la position (`expectOwnMove`) — voir `MseSource.performSeek`.
   */
  serving(seconds2) {
    this.lastTarget = seconds2;
  }
  /** Servi : la demande est satisfaite, sauf si une autre l'a remplacée entre-temps. */
  served(seconds2) {
    if (this.requested === seconds2) this.requested = null;
  }
  /**
   * Un pas volontaire de la source autour de la cible — atterrissage, poussée, position de pause
   * réaffirmée : la cible le suit, ce n'est pas un départ.
   */
  moved(seconds2) {
    this.lastTarget = seconds2;
    this.expectOwnMove(seconds2);
    if (this.intent) this.intent.target = seconds2;
  }
  /** La source va écrire cette position : le `seeking` qui suivra est le sien. */
  expectOwnMove(seconds2) {
    this.ownMove = { at: seconds2, until: Date.now() + OWN_MOVE_MS };
  }
  /** L'élément commence à sauter vers `seconds`. */
  started(seconds2, now) {
    this.intent = { target: seconds2, since: now };
  }
  /** Ce `seeking` est-il le déplacement que la source vient elle-même de faire ? */
  isOwnMove(seconds2) {
    const own = this.ownMove;
    if (!own || Date.now() > own.until || Math.abs(seconds2 - own.at) >= 0.25) return false;
    this.ownMove = null;
    return true;
  }
  /**
   * L'élément dit le saut fini, la tête à `current`. Arrivé si elle est à sa cible ; sinon le saut
   * reste en route, et c'est la surveillance de la tête hors de sa place qui tranchera.
   */
  arrive(current2) {
    if (this.intent && !seekArrived(current2, this.intent.target)) return false;
    this.intent = null;
    return true;
  }
  /** Le saut en route est abandonné — la source le redemande autrement. */
  drop() {
    this.intent = null;
  }
  /** Demandé et pas encore servi, ou servi et pas encore arrivé. */
  get pending() {
    return this.intent !== null || this.requested !== null;
  }
};
var LANDING_REACH_SECONDS = 15;
var LANDING_INSET = 0.04;
function landingFor(ranges, target, reach) {
  let start = null;
  let end = 0;
  for (let i = 0; i < ranges.length; i++) {
    if (ranges.end(i) <= ranges.start(i)) continue;
    if (ranges.start(i) <= target && target < ranges.end(i)) return target;
    if (ranges.start(i) > target && (start === null || ranges.start(i) < start)) {
      start = ranges.start(i);
      end = ranges.end(i);
    }
  }
  if (start === null || start - target > reach) return null;
  return Math.min(start + LANDING_INSET, Math.max(start, end - 0.05));
}

// src/engine/playbackGuard.ts
var RESUME_GUARD_MS = 1500;
var PAUSE_SETTLE_MS = 1e3;
var RESUME_TOLERANCE_SECONDS = 1.5;
var PAUSE_DRIFT_SECONDS = 0.25;
var MAX_PAUSE_ASSERTIONS = 3;
var MAX_START_RETRIES = 2;
var STILL_AT_THE_START = 1;
var START_WINDOW_MS = 15e3;
var PlaybackGuard = class {
  constructor(video, host, onStarting) {
    this.video = video;
    this.host = host;
    this.onStarting = onStarting;
  }
  video;
  host;
  onStarting;
  /** Whether a set of ranges covers a point. */
  covers(ranges, seconds2) {
    return rangeAround(ranges, seconds2, 0) >= 0;
  }
  /** Where a seek was served, until the playhead is actually standing on media. */
  seekLanding = null;
  /** Set when the element abandoned a start rather than the viewer pausing one. */
  startAborted = false;
  startRetries = 0;
  /** Where the film was opened, so a playhead still standing there has plainly never started. */
  openedFrom = null;
  openedAt = 0;
  /** Where the picture froze when the viewer pressed pause. Resume lands exactly there. */
  pauseAnchor = null;
  resumeDeadline = 0;
  resumeStartedAt = 0;
  pauseStartedAt = 0;
  /**
   * Where the clock was when play was asked for, while it has not moved since.
   *
   * Kept apart from the pause trace on purpose: that trace only exists once something has been
   * paused, and the very first play — the automatic one, before anyone has touched anything —
   * would otherwise raise this and have nothing able to lower it again.
   */
  startingFrom = null;
  frameCallback = null;
  pauseSettleTimer = null;
  /**
   * The last pause and resume, in positions.
   *
   * Written down because the remaining flicker cannot be reasoned about any further from here:
   * nothing in this file moves the playhead when the buffer covers it, and the device says it
   * does. Four numbers settle what a description cannot — where it stopped, where it came back,
   * and where it was one tick later.
   */
  resumeTrace = null;
  /** Re-states the position, which runs the seek algorithm and so discards any queued sound. */
  assertPausePosition() {
    const anchor = this.pauseAnchor;
    if (this.host.destroyed || anchor === null || !this.video.paused) return;
    this.host.noteSeekTarget(anchor);
    this.video.currentTime = anchor;
    if (this.resumeTrace) this.resumeTrace.asserted += 1;
  }
  /**
   * The wait shown to the viewer, armed and cleared in one place.
   *
   * Six call sites used to set this directly, and a spinner that stayed up said nothing about
   * which of them had armed it or which had failed to come. Named here, and written to the
   * record, so the next report answers that instead of posing it.
   */
  setStarting(startedAt, because) {
    if (startedAt !== null && this.startingWait !== null) return;
    this.startingWait = startedAt;
    trace(startedAt === null ? `attente lev\xE9e (${because})` : `attente affich\xE9e (${because})`);
    this.onStarting?.(startedAt);
  }
  startingWait = null;
  /**
   * Puts playback back where it was stopped, if resuming has moved it on.
   *
   * Two things move it. The element's clock follows the sound, and the sound already handed to
   * the hardware plays out past the button press. And the system may reclaim buffered media while
   * nothing is playing — it is allowed to, and on a phone it does — so the element can come back
   * to find nothing where it was and carry on from the nearest media it still holds. Both look
   * identical from here: the film quietly continued while it was stopped.
   */
  holdPausePosition() {
    const anchor = this.pauseAnchor;
    if (anchor === null || this.host.destroyed) return false;
    if (Date.now() > this.resumeDeadline) {
      this.pauseAnchor = null;
      return false;
    }
    const rate = this.video.playbackRate || 1;
    const reachable2 = anchor + (Date.now() - this.resumeStartedAt) / 1e3 * rate;
    if (this.video.currentTime <= reachable2 + RESUME_TOLERANCE_SECONDS) return false;
    this.pauseAnchor = null;
    if (this.covers(this.host.playable, anchor)) {
      this.host.noteSeekTarget(anchor);
      this.video.currentTime = anchor;
      return true;
    }
    void this.host.seek(anchor, "reprise apr\xE8s une pause");
    return true;
  }
  /**
   * Playback has genuinely begun.
   *
   * Waiting instead for the clock to be seen moving means waiting for the next timeupdate, which
   * a browser emits about four times a second — long enough for the picture to be running again
   * before anyone here notices, and for a spinner to appear over media that is already playing
   * and then vanish. This event is the moment itself.
   */
  /**
   * Waits for a picture to actually be presented, and only then stops saying it is starting.
   *
   * The three candidate signals are not interchangeable. The playing event fires as soon as play
   * is called, before the pipeline has begun — clearing on it means never showing anything at
   * all. timeupdate arrives about four times a second, so the picture can be running again a
   * fifth of a second before anyone here notices, which is long enough to show a spinner over
   * media that is already moving and then take it away. This one is the frame itself.
   */
  watchForFirstFrame(from) {
    const request = this.video.requestVideoFrameCallback?.bind(this.video);
    if (!request) return;
    const step = (_now, metadata) => {
      this.frameCallback = null;
      if (this.host.destroyed || this.startingFrom === null) return;
      if (metadata.mediaTime > from + 0.01) {
        this.startingFrom = null;
        this.firstPictureOwed = false;
        this.setStarting(null, "premi\xE8re image affich\xE9e");
        return;
      }
      this.frameCallback = request(step);
    };
    this.frameCallback = request(step);
  }
  stopWatchingForFirstFrame() {
    if (this.frameCallback === null) return;
    this.video.cancelVideoFrameCallback?.(this.frameCallback);
    this.frameCallback = null;
  }
  /**
   * Moves the playhead onto the media, when it has landed just short of it.
   *
   * A seek starts reading at the indexed cluster at or before the requested time, but everything
   * this path produces is shifted later by the presentation delay. Land on an index point exactly
   * and the media therefore begins a fifth of a second *after* the playhead — a gap the element
   * will sit in front of indefinitely, waiting for data that is never coming. The step is far too
   * small to see, and it is the difference between a seek that works and one that hangs.
   */
  nudgeIntoBuffer() {
    const ranges = this.host.playable;
    const landing = this.seekLanding !== null && Math.abs(this.video.currentTime - this.seekLanding) < 0.05;
    if (ranges.length === 0 || this.host.destroyed || this.video.paused && !landing) return;
    const now = this.video.currentTime;
    const tolerance = landing ? LANDING_REACH_SECONDS : this.host.delaySeconds + 0.15;
    const target = landingFor(ranges, now, tolerance);
    if (target === null) return;
    if (target === now) {
      this.seekLanding = null;
      return;
    }
    if (landing) trace(`atterrissage : la t\xEAte passe de ${now.toFixed(1)} s au m\xE9dia, pos\xE9e \xE0 ${target.toFixed(2)} s`);
    this.seekLanding = null;
    this.host.noteSeekTarget(target);
    this.pauseAnchor = null;
    this.headPlaced(target);
    this.video.currentTime = target;
  }
  /**
   * La source vient de poser la tête ailleurs pendant qu'un démarrage est attendu : l'atterrissage
   * de l'ouverture (0 → 0,27 s sur un fichier à images B), la poussée d'une horloge figée.
   *
   * Ce pas-là n'est pas de la lecture, et il passait pour elle : `clockTicked` comme la première
   * image lisaient « la tête a dépassé le départ » et levaient l'attente sur une image figée. Sur
   * iPhone, un tiers des ouvertures depuis le début restaient ainsi arrêtées 1,5 s sans rien dire,
   * puis repartaient après la poussée — le « second petit chargement » vu sur un film
   * (10/10/2026 ; trace d'un film du 06/10 : atterrissage à 0,27 s, « attente levée », puis
   * « horloge figée à 0,27 s » 1,5 s plus tard). Le départ se compte donc depuis là où la tête a été
   * posée.
   */
  headPlaced(at) {
    if (this.startingFrom === null) return;
    this.startingFrom = at;
    this.stopWatchingForFirstFrame();
    this.watchForFirstFrame(at);
  }
  /**
   * Vrai depuis l'ouverture jusqu'à la première image qui avance vraiment — voir
   * `FROZEN_OPENING_MS` dans la source, qui pousse plus tôt une ouverture figée.
   */
  get awaitingFirstPicture() {
    return this.firstPictureOwed && this.openedFrom !== null && Math.abs(this.video.currentTime - this.openedFrom) < 1;
  }
  firstPictureOwed = false;
  clockTicked = () => {
    if (this.startingFrom !== null && this.video.currentTime > this.startingFrom + 0.01) {
      this.startingFrom = null;
      this.firstPictureOwed = false;
      this.stopWatchingForFirstFrame();
      this.setStarting(null, "l'horloge a avanc\xE9");
    }
    const trace2 = this.resumeTrace;
    if (trace2 && !Number.isNaN(trace2.play)) {
      if (trace2.tick === null) trace2.tick = this.video.currentTime;
      if (trace2.latencyMs === null && this.video.currentTime > trace2.play + 0.01) {
        trace2.latencyMs = Date.now() - this.resumeStartedAt;
        trace2.pausedForMs = this.resumeStartedAt - this.pauseStartedAt;
      }
    }
    if (this.pauseAnchor !== null) this.holdPausePosition();
  };
  /**
   * Remembers exactly where the picture stopped.
   *
   * The element's clock does not necessarily stop where the button was pressed: the audio the
   * system has already handed to the hardware plays out over the next fraction of a second, and
   * the clock follows the sound. Resuming then starts from wherever it drifted to, which reads
   * as the film having quietly continued while paused and jumping to catch up.
   */
  paused = () => {
    if (this.host.destroyed) return;
    const abortedStart = this.startingFrom !== null;
    if (abortedStart) this.startAborted = true;
    this.startingFrom = null;
    this.stopWatchingForFirstFrame();
    this.setStarting(null, "mise en pause");
    const seeking = this.video.seeking;
    this.pauseAnchor = abortedStart || seeking ? null : this.video.currentTime;
    this.resumeTrace = {
      paused: this.video.currentTime,
      settled: this.video.currentTime,
      asserted: 0,
      play: NaN,
      tick: null,
      latencyMs: null,
      pausedForMs: null
    };
    this.pauseStartedAt = Date.now();
    this.assertPausePosition();
    if (this.pauseSettleTimer) clearInterval(this.pauseSettleTimer);
    const deadline = Date.now() + PAUSE_SETTLE_MS;
    this.pauseSettleTimer = setInterval(() => {
      const stop = this.host.destroyed || this.pauseAnchor === null || !this.video.paused || Date.now() > deadline;
      if (stop) {
        if (this.pauseSettleTimer) clearInterval(this.pauseSettleTimer);
        this.pauseSettleTimer = null;
        return;
      }
      const settled = this.pauseAnchor;
      if (settled !== null && this.video.currentTime > settled + PAUSE_DRIFT_SECONDS) {
        this.pauseAnchor = this.video.currentTime;
        if (this.resumeTrace) this.resumeTrace.settled = this.video.currentTime;
        this.assertPausePosition();
        if ((this.resumeTrace?.asserted ?? 0) >= MAX_PAUSE_ASSERTIONS) {
          clearInterval(this.pauseSettleTimer);
          this.pauseSettleTimer = null;
        }
      }
    }, 120);
  };
  playing = () => {
    if (this.host.destroyed) return;
    this.resumeStartedAt = Date.now();
    if (this.resumeTrace) this.resumeTrace.play = this.video.currentTime;
    this.startingFrom = this.video.currentTime;
    this.setStarting(this.resumeStartedAt, "lecture demand\xE9e");
    this.watchForFirstFrame(this.startingFrom);
    this.resumeDeadline = this.resumeStartedAt + RESUME_GUARD_MS;
    const moved = this.holdPausePosition();
    if (!moved) this.nudgeIntoBuffer();
  };
  /** A seek has been served: the landing licence lasts only while the playhead has not moved. */
  seekServed(playerSeconds) {
    this.seekLanding = playerSeconds;
  }
  /**
   * The film has just been opened at this position.
   *
   * Treated as a landing, because that is what it is: a request to be somewhere, about to be
   * answered with media that begins a fraction of a second later. Without the licence the
   * opening deadlocks — the element is paused because there is nothing under the playhead, and
   * the playhead is not moved onto the media because the element is paused.
   */
  opened(playerSeconds, startOwed = true) {
    this.seekLanding = playerSeconds;
    this.startAborted = startOwed;
    this.startRetries = 0;
    this.firstPictureOwed = startOwed;
    this.openedFrom = playerSeconds;
    this.openedAt = Date.now();
    this.forgetPause();
  }
  /**
   * The first media has arrived. Starts the film if it was asked for and never began.
   *
   * Measured on an iPhone, opening an episode from the beginning: the media of a file with
   * B-frames starts 210 ms in, `play()` was called before any of it existed, and the element
   * aborted the attempt and went back to paused with the playhead short of everything. The film
   * then sat at 0:00 with thirty seconds buffered, and only a seek or a press of play — both of
   * which the viewer had to think of — got it going.
   *
   * Only for a start the *element* abandoned: a viewer who pressed pause while it was loading
   * has asked for exactly this, and starting the film under them would be the player arguing.
   */
  mediaArrived() {
    if (this.host.destroyed || !this.startAborted) return;
    if (!this.video.paused) {
      this.startAborted = false;
      return;
    }
    if (this.openedFrom === null || Math.abs(this.video.currentTime - this.openedFrom) > STILL_AT_THE_START) {
      this.startAborted = false;
      return;
    }
    if (Date.now() - this.openedAt > START_WINDOW_MS) {
      this.startAborted = false;
      return;
    }
    if (this.startRetries >= MAX_START_RETRIES) return;
    this.startRetries += 1;
    this.startAborted = false;
    this.seekLanding = this.video.currentTime;
    this.nudgeIntoBuffer();
    trace(`d\xE9marrage repris (${this.startRetries}) \u2014 t\xEAte \xE0 ${this.video.currentTime.toFixed(2)} s`);
    void this.video.play().catch(() => {
    });
  }
  /** A deliberate move elsewhere settles the question of where playback belongs. */
  forgetPause() {
    this.pauseAnchor = null;
  }
  /**
   * Whatever the guard was waiting for died with the source.
   *
   * Cleared unconditionally, before anything else can fail on the way out: a wait nobody will
   * answer is a spinner for ever.
   */
  destroy() {
    this.startingFrom = null;
    this.stopWatchingForFirstFrame();
    this.startingWait = Date.now();
    this.setStarting(null, "lecteur d\xE9truit");
    if (this.pauseSettleTimer) clearInterval(this.pauseSettleTimer);
    this.pauseSettleTimer = null;
    this.pauseAnchor = null;
  }
  /** The last pause and resume, in positions, for the technical panel. */
  get debug() {
    const trace2 = this.resumeTrace;
    if (!trace2) return {};
    return {
      "Derni\xE8re pause": `arr\xEAt ${trace2.paused.toFixed(3)} \u2192 repos ${trace2.settled.toFixed(3)}${trace2.asserted > 0 ? ` \u2192 recal\xE9 \xD7${trace2.asserted}` : ""}`,
      "Derni\xE8re reprise": Number.isNaN(trace2.play) ? "\u2014" : `d\xE9part ${trace2.play.toFixed(3)} \u2192 1er tick ${trace2.tick?.toFixed(3) ?? "\u2014"}`,
      "D\xE9lai du bouton lecture": trace2.latencyMs === null ? "\u2014" : `${trace2.latencyMs} ms \xB7 apr\xE8s ${((trace2.pausedForMs ?? 0) / 1e3).toFixed(1)} s de pause`
    };
  }
};

// src/engine/mseSupport.ts
function sourceConstructor() {
  if (typeof window === "undefined") return null;
  return window.ManagedMediaSource ?? (typeof MediaSource !== "undefined" ? MediaSource : null);
}
function containerAccepts(mimeType) {
  const Source = sourceConstructor();
  if (!Source) return false;
  try {
    return Source.isTypeSupported(mimeType);
  } catch {
    return false;
  }
}
function playabilityOf(plan) {
  const Source = sourceConstructor();
  if (!Source) return { ok: false, reason: "Ce navigateur ne propose pas MediaSource." };
  if (!Source.isTypeSupported(plan.videoMimeType)) {
    return { ok: false, reason: `Vid\xE9o non prise en charge par ce navigateur : ${plan.videoMimeType}` };
  }
  if (plan.audioMimeType && !Source.isTypeSupported(plan.audioMimeType)) {
    return { ok: false, reason: `Audio non pris en charge par ce navigateur : ${plan.audioMimeType}` };
  }
  return { ok: true };
}

// src/support/networkOutage.ts
var NETWORK_OUTAGE_GIVE_UP_MS = 48e3;

// src/engine/mseTuning.ts
var TARGET_BUFFER_SECONDS = 30;
var FROZEN_CLOCK_MS = 1500;
var FROZEN_SEEKING_MS = 6e3;
var FROZEN_OPENING_MS = 400;
var OPENING_EDGE_SECONDS = 0.5;
var OPENING_REASSERT_MS = 100;
var OPENING_PLAYING_GRACE_MS = 600;
var SEEKING_PATIENCE_PER_SECOND_MS = 500;
var FROZEN_STEP = 0.08;
var MAX_FROZEN_NUDGES = 3;
var MIN_BUFFER_SECONDS = 8;
var RECOVERY_WINDOW_MS = 5e3;
var MAX_RECOVERY_ATTEMPTS = 3;
var MAX_UNPLAYED_ATTEMPTS = 8;
var PLAYED_TO_CLEAR_SECONDS = 3;
var NEXT_KEYFRAME_MARGIN = 0.1;
var STALL_REPORT_MS = 5e3;
var STALL_REPORT_COOLDOWN_MS = 6e4;
var RUNAWAY_REPORT_SECONDS = 3;
var STALL_TRACE_MS = 2e4;
var SENT_FRAGMENTS_KEPT = 48;
var MAX_APPEND_FAILURES = 3;
var NETWORK_KEEP_LEAD_SECONDS = 5;
var NETWORK_RETRY_DELAYS_MS = [1e3, 2e3, 4e3, 8e3];
var NETWORK_TRIM_MARGIN_SECONDS = 1;
var OUTAGE_STARVED_LEAD_SECONDS = 0.5;
var STALL_TIMEOUT_MS = 700;
var WATCHDOG_MS = 250;
var EVICTION_REFILLS_PER_MINUTE = 3;
var SOURCE_OPEN_TIMEOUT_MS = 15e3;
var MISPLACED_SECONDS = 10;
var FRUITLESS_APPENDS = 8;
var PRE_ROLL_SECONDS = 40;
var TRACED_APPENDS = 4;
var TRACED_APPENDS_PER_SEEK = 6;
var KEEP_BEHIND_SECONDS = 30;
var TRIM_SLACK_SECONDS = 2;
var KEYFRAME_TRIM_MARGIN = 0.05;
var ZONE_MARGIN_SECONDS = 0.5;
var ONE_FRAME_S = 1 / 24;
var PREPEND_SHARE_OF_AHEAD = 0.5;
var PREPEND_STOP_MARGIN_S = 0.5;

// src/engine/mseSpans.ts
function signed(seconds2) {
  return `${seconds2 >= 0 ? "+" : ""}${seconds2.toFixed(2)}`;
}
function spansAll(buffer) {
  if (!buffer) return "aucun";
  try {
    const ranges = buffer.buffered;
    if (ranges.length === 0) return "vide";
    const spans = [];
    for (let i = 0; i < ranges.length && i < 4; i++) spans.push(`${ranges.start(i).toFixed(2)}\u2013${ranges.end(i).toFixed(2)}`);
    if (ranges.length > 4) spans.push(`+${ranges.length - 4}`);
    return spans.join(" \xB7 ");
  } catch {
    return "illisible (source ferm\xE9e)";
  }
}
function spansNear(buffer, at) {
  try {
    const ranges = buffer?.buffered;
    if (!ranges || ranges.length === 0) return "vide";
    const spans = [];
    for (let i = 0; i < ranges.length && spans.length < 4; i++) {
      if (ranges.end(i) < at - 30 || ranges.start(i) > at + 30) continue;
      spans.push(`${ranges.start(i).toFixed(2)}\u2013${ranges.end(i).toFixed(2)}`);
    }
    return spans.join(" \xB7 ") || "rien pr\xE8s de la t\xEAte";
  } catch {
    return "illisible (source ferm\xE9e)";
  }
}
function playableSpans(video) {
  const ranges = video.buffered;
  const spans = [];
  for (let i = 0; i < ranges.length; i++) spans.push(`${ranges.start(i).toFixed(2)}\u2013${ranges.end(i).toFixed(1)}`);
  return spans.join(" \xB7 ") || "vide";
}
function frameQuality(video) {
  const quality = video.getVideoPlaybackQuality?.();
  if (!quality) return "non mesurable ici";
  const { droppedVideoFrames: dropped, totalVideoFrames: total } = quality;
  if (total === 0) return "aucune image rendue";
  return `${dropped} / ${total} (${(dropped / total * 100).toFixed(1)} %)`;
}

// src/engine/fragmentProbe.ts
var REMUX_TIMESCALE = 1e6;
function boxesIn(view, from, to) {
  const out = [];
  let at = from;
  while (at + 8 <= to && out.length < 64) {
    let size = view.getUint32(at);
    const type = String.fromCharCode(view.getUint8(at + 4), view.getUint8(at + 5), view.getUint8(at + 6), view.getUint8(at + 7));
    let body = at + 8;
    if (size === 1) {
      if (at + 16 > to) break;
      size = view.getUint32(at + 8) * 2 ** 32 + view.getUint32(at + 12);
      body = at + 16;
    } else if (size === 0) {
      size = to - at;
    }
    if (size < body - at || at + size > to) break;
    out.push({ type, start: at, end: at + size, body });
    at += size;
  }
  return out;
}
function fragmentTimes(data, timescale = REMUX_TIMESCALE) {
  try {
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    const moof = boxesIn(view, 0, data.byteLength).find((b) => b.type === "moof");
    if (!moof) return null;
    const inner = boxesIn(view, moof.body, moof.end);
    const mfhd = inner.find((b) => b.type === "mfhd");
    const seq = mfhd && mfhd.body + 8 <= mfhd.end ? view.getUint32(mfhd.body + 4) : null;
    const traf = inner.find((b) => b.type === "traf");
    if (!traf) return null;
    const parts = boxesIn(view, traf.body, traf.end);
    const tfdt = parts.find((b) => b.type === "tfdt");
    if (!tfdt) return null;
    const tfdtVersion = view.getUint8(tfdt.body);
    const decode = tfdtVersion === 1 ? view.getUint32(tfdt.body + 4) * 2 ** 32 + view.getUint32(tfdt.body + 8) : view.getUint32(tfdt.body + 4);
    let offset = 0;
    const trun = parts.find((b) => b.type === "trun");
    if (trun) {
      const version = view.getUint8(trun.body);
      const flags = view.getUint32(trun.body) & 16777215;
      const count = view.getUint32(trun.body + 4);
      let p = trun.body + 8;
      if (flags & 1) p += 4;
      if (flags & 4) p += 4;
      if (count > 0) {
        if (flags & 256) p += 4;
        if (flags & 512) p += 4;
        if (flags & 1024) p += 4;
        if (flags & 2048 && p + 4 <= trun.end) offset = version === 1 ? view.getInt32(p) : view.getUint32(p);
      }
    }
    return { seq, dts: decode / timescale, pts: (decode + offset) / timescale };
  } catch {
    return null;
  }
}

// src/engine/mseLossRecord.ts
var LossRecord = class {
  constructor(host) {
    this.host = host;
  }
  host;
  /**
   * Les plages des deux tampons après la dernière opération réussie — envoi ou retrait —, pour la
   * ligne d'une perte (`failureFacts`).
   *
   * Relevées à ce moment-là parce qu'après la fermeture de la source elles ne se lisent plus : le
   * « Media failed to decode » d'un épisode de série sur un iPhone (14/10/2026) n'a laissé que
   * « illisible (source fermée) », la source étant déjà fermée quand l'élément a signalé son
   * erreur. Purement informatif : rien ne lit ce relevé hors du journal.
   */
  lastGoodBuffered = null;
  /**
   * Les derniers fragments vidéo envoyés depuis le dernier vidage : numéro, début (dts/pts, horloge
   * de l'élément) et rang depuis le saut — de quoi dire, à l'échec, dans quel fragment était la
   * tête et lequel venait de partir. Bornés, et vidés avec les tampons qu'ils décrivent.
   */
  sentFragments = [];
  fragmentsSinceSeek = 0;
  /** Les faits propres à l'échec, relevés avec `lossSnapshot` — voir `failureFacts`. */
  lossFailure = null;
  /**
   * L'état au moment où la plateforme a lâché la source, gardé pour la ligne `rebuild`.
   *
   * Pris ici et pas au moment d'écrire la ligne : l'hôte ne l'apprend qu'au prochain envoi refusé,
   * quand les tampons sont déjà détachés et illisibles. Le 23/09/2026, trois « Media failed to
   * decode » sur un iPhone 12 (un film, 4K) n'ont laissé que leur motif — ni les tampons, ni ce
   * qui venait d'être envoyé —, et rien ne permettait de dire si nos données y étaient pour
   * quelque chose. Le premier des deux événements l'emporte : c'est lui qui a vu les tampons.
   */
  lossSnapshot = null;
  noteLoss() {
    this.lossFailure ??= this.failureFacts();
    if (this.lossSnapshot) return;
    try {
      this.lossSnapshot = this.host.stateFacts(this.host.video.currentTime);
    } catch {
    }
  }
  /**
   * Ce qu'un échec de décodage laisse à dire, en plus de l'état (14/10/2026) : les tampons au
   * dernier envoi réussi, les images comptées par l'élément, son message d'erreur, et la place de
   * la tête dans les fragments envoyés — pour dire si c'est l'image ou le son qui a lâché, et où.
   *
   * Chaque fait dans sa propre garde : une lecture qui lève perd ce fait-là, jamais les autres, et
   * jamais la ligne. Ne lève pas.
   */
  failureFacts() {
    const facts = {};
    const now = Date.now();
    let head = NaN;
    try {
      head = this.host.video.currentTime;
    } catch {
    }
    try {
      const seen = this.lastGoodBuffered;
      if (seen) {
        facts.lastBuffered = `vid\xE9o ${seen.video} \xB7 audio ${seen.audio} \u2014 apr\xE8s ${seen.after}, ${now - seen.at} ms avant`;
      }
    } catch {
    }
    try {
      const quality = this.host.video.getVideoPlaybackQuality?.();
      if (quality) {
        const corrupted = quality.corruptedVideoFrames;
        facts.videoQuality = `total ${quality.totalVideoFrames} \xB7 perdues ${quality.droppedVideoFrames}` + (typeof corrupted === "number" ? ` \xB7 corrompues ${corrupted}` : "");
      }
    } catch {
    }
    try {
      const failure = this.host.video.error;
      if (failure) facts.mediaError = `${failure.code}${failure.message ? ` \xAB ${failure.message.slice(0, 300)} \xBB` : ""}`;
    } catch {
    }
    try {
      const last2 = this.sentFragments.at(-1);
      if (last2) {
        const offset = Number.isFinite(head) ? ` \xB7 t\xEAte ${signed(head - last2.pts)} s` : "";
        facts.lastFragment = `n\xB0${last2.seq ?? "?"} (${last2.n}e depuis le saut) dts ${last2.dts.toFixed(3)} pts ${last2.pts.toFixed(3)}${offset} \xB7 envoy\xE9 ${now - last2.at} ms avant`;
      }
      if (Number.isFinite(head)) {
        let under = null;
        for (const fragment of this.sentFragments) {
          if (fragment.pts <= head && (!under || fragment.pts >= under.pts)) under = fragment;
        }
        if (under) {
          facts.headFragment = `n\xB0${under.seq ?? "?"} (${under.n}e) pts ${under.pts.toFixed(3)} \xB7 t\xEAte ${signed(head - under.pts)} s`;
        }
      }
    } catch {
    }
    return facts;
  }
  /** Voir `lastGoodBuffered`. Ne lève jamais. */
  rememberBuffered(after) {
    try {
      this.lastGoodBuffered = {
        at: Date.now(),
        after,
        video: spansAll(this.host.videoBuffer),
        audio: spansAll(this.host.audioBuffer)
      };
    } catch {
    }
  }
  /** Un fragment vidéo accepté par le tampon — voir `sentFragments`. Ne lève jamais. */
  rememberFragment(data) {
    try {
      const times = fragmentTimes(data);
      if (!times) return;
      this.fragmentsSinceSeek += 1;
      this.sentFragments.push({ n: this.fragmentsSinceSeek, ...times, at: Date.now() });
      if (this.sentFragments.length > SENT_FRAGMENTS_KEPT) this.sentFragments.shift();
    } catch {
    }
  }
  /**
   * Ce qu'une ligne `rebuild` porte en plus de son motif : l'état relevé à la perte, et les vingt
   * dernières secondes de la trace — les envois, les sauts, l'erreur de l'élément, dans l'ordre.
   */
  lossReport() {
    let state = {};
    try {
      state = this.lossSnapshot ?? this.host.stateFacts(this.host.video.currentTime);
    } catch {
    }
    let failure = {};
    try {
      failure = this.lossFailure ?? this.failureFacts();
    } catch {
    }
    try {
      return { ...state, ...failure, steps: traceRecent(STALL_TRACE_MS).join(" | ") };
    } catch {
      return { ...state, ...failure };
    }
  }
};

// src/engine/mseZoneHold.ts
var UnreadableZoneHold = class {
  constructor(host) {
    this.host = host;
  }
  host;
  /**
   * La zone illisible qui tient la lecture (§93) : plus rien n'est lu, la tête finit ce qui est là,
   * et le relais part à `switchAt`. Levée par un saut qui la quitte.
   */
  zone = null;
  /** Le relais pour une zone est parti : cette source n'a plus rien à faire. */
  zoneHanded = false;
  /**
   * La lecture en avance vient d'atteindre une zone illisible (§93). Plus rien n'est lu ; ce qui est
   * dans les tampons se joue jusqu'à la fin de ce qui est sûr (`switchAt`), où la main passe. Rien à
   * jouer avant — une ouverture, un saut tombé dedans — : tout de suite.
   */
  holdAtZone(error) {
    if (this.zoneHanded || this.host.destroyed) return;
    const delay = this.host.delaySeconds;
    const head = this.host.anchor;
    const lead = this.host.lead;
    const safe = error.safeSeconds + delay - ZONE_MARGIN_SECONDS;
    const switchAt = lead > ZONE_MARGIN_SECONDS ? Math.max(head, Math.min(safe, this.host.bufferedEnd() - ZONE_MARGIN_SECONDS)) : head;
    let resumeAfter = null;
    try {
      const after = this.host.remuxer.resumeAfterByte(error.byteOffset);
      resumeAfter = after === null ? null : after + delay;
    } catch {
      resumeAfter = null;
    }
    this.zone = { message: error.message, byteOffset: error.byteOffset, zoneSeconds: error.seconds + delay, switchAt, resumeAfter };
    trace(
      `${error.message} \u2014 t\xEAte \xE0 ${head.toFixed(1)} s, ${lead.toFixed(1)} s d'avance, relais \xE0 ${switchAt.toFixed(1)} s` + (resumeAfter !== null ? `, film lisible de nouveau \xE0 ${resumeAfter.toFixed(1)} s` : ", aucun point d'index apr\xE8s")
    );
    this.notifyZone({ kind: "held", zone: this.zone });
    this.checkZoneArrival();
  }
  notifyZone(event) {
    try {
      this.host.callbacks.onUnreadableZone?.(event);
    } catch {
    }
  }
  /** La tête est-elle au relais — ou n'y a-t-il plus rien à jouer avant ? Passe la main si oui. */
  checkZoneArrival() {
    const zone = this.zone;
    if (!zone || this.zoneHanded || this.host.destroyed) return false;
    if (this.host.anchor < zone.switchAt && this.host.lead > 0) return false;
    this.arriveAtZone(zone.switchAt, "t\xEAte arriv\xE9e au relais");
    return true;
  }
  /** Une fois : la main passe à l'hôte (`onError`, `facts.unreadableZone`), qui relaie au lecteur serveur. */
  arriveAtZone(resumeAt, why) {
    const zone = this.zone;
    if (!zone || this.zoneHanded || this.host.destroyed) return;
    this.zoneHanded = true;
    const head = this.host.video.currentTime;
    trace(`zone illisible : ${why} \xE0 ${head.toFixed(1)} s \u2014 relais \xE0 ${resumeAt.toFixed(1)} s ${this.host.elementState()}`);
    this.host.callbacks.onError(zone.message, "playback", {
      unreadableZone: true,
      zoneByte: zone.byteOffset,
      zoneSeconds: Math.round(zone.zoneSeconds * 10) / 10,
      resumeAt: Math.round(resumeAt * 1e3) / 1e3,
      at: Math.round(head * 10) / 10,
      ...zone.resumeAfter !== null ? { resumeAfter: Math.round(zone.resumeAfter * 10) / 10 } : {}
    });
  }
};

// src/engine/browserEngine.ts
function geckoVersion(userAgent) {
  if (isWebKitEngine(userAgent) || !/Gecko\/\d/.test(userAgent)) return null;
  const match = /Firefox\/(\d+)/.exec(userAgent);
  return match ? Number(match[1]) : null;
}
function isChromiumEngine(userAgent) {
  return !isWebKitEngine(userAgent) && /Chrom(e|ium)\/\d/.test(userAgent);
}
function geckoEngine() {
  const agent = typeof navigator === "undefined" ? "" : navigator.userAgent ?? "";
  return /Firefox\/\d/.test(agent) && !isWebKitEngine(agent) && !/Chrom(e|ium)\/\d/.test(agent);
}
function opusCopyConsidered() {
  const agent = typeof navigator === "undefined" ? "" : navigator.userAgent ?? "";
  return agent !== "" && !isWebKitEngine(agent);
}
function appleAudioToolbox() {
  if (typeof navigator === "undefined") return false;
  const agent = navigator.userAgent ?? "";
  return /iPhone|iPad|iPod|Macintosh|Mac OS X/.test(agent) && !/Android/.test(agent);
}
function appleWebKit() {
  if (typeof navigator === "undefined") return false;
  const agent = navigator.userAgent ?? "";
  const apple = /iPhone|iPad|iPod|Macintosh|Mac OS X/.test(agent) && !/Android/.test(agent);
  return apple && isWebKitEngine(agent);
}

// src/engine/bufferBudget.ts
var WEBKIT_MOBILE_SOURCE_BUFFER_BYTES = 110376422;
var WEBKIT_MAC_SOURCE_BUFFER_BYTES = 318767104;
var AUDIO_ONLY_SHARE = 0.05;
var AUDIO_LANE_SHARE = 0.75;
var AHEAD_SHARE = 0.6;
var USABLE_SHARE = 0.85;
var MIN_BEHIND_SECONDS = 6;
var CHROMIUM_DESKTOP = { video: 150 * 1024 * 1024, audio: 12 * 1024 * 1024 };
var CHROMIUM_ANDROID = {
  default: { video: 150 * 1024 * 1024, audio: 12 * 1024 * 1024 },
  medium: { video: 80 * 1024 * 1024, audio: 5 * 1024 * 1024 },
  low: { video: 30 * 1024 * 1024, audio: 2 * 1024 * 1024 },
  veryLow: { video: 15 * 1024 * 1024, audio: 1 * 1024 * 1024 }
};
var GECKO = { video: 150 * 1024 * 1024, audio: 20 * 1024 * 1024 };
var GECKO_BEFORE_130 = { video: 100 * 1024 * 1024, audio: 20 * 1024 * 1024 };
function chromiumAndroidTier(deviceMemory) {
  if (deviceMemory === void 0) return CHROMIUM_ANDROID.medium;
  if (deviceMemory <= 0.5) return CHROMIUM_ANDROID.veryLow;
  if (deviceMemory <= 1) return CHROMIUM_ANDROID.low;
  if (deviceMemory <= 4) return CHROMIUM_ANDROID.medium;
  return CHROMIUM_ANDROID.default;
}
function sourceBufferQuota(userAgent, hints = {}) {
  if (isWebKitEngine(userAgent)) {
    const mobile = /iP(hone|ad|od)/i.test(userAgent) || /Macintosh/i.test(userAgent) && (hints.maxTouchPoints ?? 0) > 1;
    const total = mobile ? WEBKIT_MOBILE_SOURCE_BUFFER_BYTES : WEBKIT_MAC_SOURCE_BUFFER_BYTES;
    return { engine: mobile ? "WebKit mobile" : "WebKit macOS", video: total, audio: Math.floor(total * AUDIO_ONLY_SHARE) };
  }
  if (isChromiumEngine(userAgent)) {
    if (/Android/i.test(userAgent)) return { engine: "Chromium Android", ...chromiumAndroidTier(hints.deviceMemory) };
    return { engine: "Chromium", ...CHROMIUM_DESKTOP };
  }
  const gecko = geckoVersion(userAgent);
  if (gecko !== null) return { engine: "Gecko", ...gecko >= 130 ? GECKO : GECKO_BEFORE_130 };
  return null;
}
function currentSourceBufferQuota() {
  if (typeof navigator === "undefined") return null;
  const memory = navigator.deviceMemory;
  return sourceBufferQuota(navigator.userAgent, {
    maxTouchPoints: navigator.maxTouchPoints ?? 0,
    ...typeof memory === "number" ? { deviceMemory: memory } : {}
  });
}
var RATE_WINDOW = 12;
var ByteRate = class {
  samples = [];
  record(bytes, seconds2) {
    if (!(seconds2 >= 0.2) || !(bytes > 0)) return;
    this.samples.push({ bytes, seconds: seconds2 });
    if (this.samples.length > RATE_WINDOW) this.samples.shift();
  }
  /** Octets par seconde, ou null tant que rien n'a été mesuré. Le plus lourd de la fenêtre l'emporte à moitié. */
  get bytesPerSecond() {
    if (this.samples.length === 0) return null;
    const bytes = this.samples.reduce((n, s) => n + s.bytes, 0);
    const seconds2 = this.samples.reduce((n, s) => n + s.seconds, 0);
    const mean = bytes / seconds2;
    const peak = Math.max(...this.samples.map((s) => s.bytes / s.seconds));
    return (mean + peak) / 2;
  }
};
function laneBudget(quotaBytes, bytesPerSecond, maxAhead, maxBehind, minAhead) {
  if (!bytesPerSecond || bytesPerSecond <= 0 || quotaBytes <= 0) return null;
  const secondsInQuota = quotaBytes / bytesPerSecond;
  const usable = secondsInQuota * USABLE_SHARE;
  const ahead = Math.max(minAhead, Math.min(maxAhead, secondsInQuota * AHEAD_SHARE, usable - MIN_BEHIND_SECONDS));
  return { aheadSeconds: ahead, behindSeconds: Math.max(1, Math.min(maxBehind, usable - ahead)), totalSeconds: usable };
}
function tightest(...budgets) {
  const known = budgets.filter((b) => b !== null);
  if (known.length === 0) return null;
  return {
    aheadSeconds: Math.min(...known.map((b) => b.aheadSeconds)),
    behindSeconds: Math.min(...known.map((b) => b.behindSeconds)),
    totalSeconds: Math.min(...known.map((b) => b.totalSeconds))
  };
}

// src/engine/mseBufferPlanner.ts
var BufferPlanner = class {
  constructor(host) {
    this.host = host;
  }
  host;
  /** How far ahead to fill. Lowered, for this file only, if the browser says it cannot hold it. */
  targetBuffer = TARGET_BUFFER_SECONDS;
  /**
   * Le plafond de ce navigateur en octets, et le débit réellement envoyé à chaque tampon — voir
   * `bufferBudget.ts`. Null pour un moteur qu'on ne connaît pas : rien n'y change.
   */
  quota = currentSourceBufferQuota();
  videoRate = new ByteRate();
  audioRate = new ByteRate();
  /** Le dernier budget écrit dans la trace, pour ne l'écrire que lorsqu'il change vraiment. */
  tracedBudget = null;
  /**
   * Le budget en octets de ce navigateur pour ce fichier, en secondes — le plus serré des deux
   * tampons. Null tant que le débit n'est pas mesuré, et partout ailleurs que sur WebKit.
   */
  get budget() {
    if (!this.quota) return null;
    const budget = tightest(
      this.host.videoOps() ? laneBudget(this.quota.video, this.videoRate.bytesPerSecond, TARGET_BUFFER_SECONDS, KEEP_BEHIND_SECONDS, MIN_BUFFER_SECONDS) : null,
      this.audioBudget
    );
    const before = this.tracedBudget;
    if (budget && (!before || Math.abs(before.aheadSeconds - budget.aheadSeconds) >= 3 || Math.abs(before.behindSeconds - budget.behindSeconds) >= 3)) {
      this.tracedBudget = budget;
      const mo = (n) => n === null ? "?" : (n / 1e6).toFixed(1);
      trace(
        `budget ${this.quota.engine} : ${Math.round(this.quota.video / 1e6)} Mo d'image, ${Math.round(this.quota.audio / 1e6)} Mo de son, image ${mo(this.videoRate.bytesPerSecond)} Mo/s, son ${mo(this.audioRate.bytesPerSecond)} Mo/s \u2014 ${budget.aheadSeconds.toFixed(1)} s devant, ${budget.behindSeconds.toFixed(1)} s derri\xE8re`
      );
    }
    return budget;
  }
  /** Le budget du son seul, sur la part de son plafond qu'on se donne (`AUDIO_LANE_SHARE`). */
  get audioBudget() {
    if (!this.quota || !this.host.audioOps()) return null;
    return laneBudget(this.quota.audio * AUDIO_LANE_SHARE, this.audioRate.bytesPerSecond, TARGET_BUFFER_SECONDS, KEEP_BEHIND_SECONDS, MIN_BUFFER_SECONDS);
  }
  /**
   * L'avance que le tampon du son peut encore prendre sans passer son plafond, compte tenu de ce
   * qu'il tient *réellement* derrière la tête (et ailleurs) — null sans budget.
   *
   * Le budget suppose l'arrière déjà ramené au sien. Ce n'est pas le cas juste après un saut en
   * avant : ce qui était devant passe derrière d'un coup, le retrait attend que le saut soit fini
   * (`trimBehind`), et l'avance, elle, se refaisait aussitôt en entier. iPad, un film,
   * 30/09/2026 : +10 s, 60 s de son tenus pour un plafond qui en tenait à peine autant, et WebKit
   * a retiré lui-même le son de 1559,87 à 1590,37 s, tête à 1563,7 s — l'élément est resté
   * `seeking` cinq secondes sur une image présente. Deux fois dans le film. L'image n'a pas cette
   * borne : son arrière ne peut pas descendre sous l'image clé de la tête (`behindLimit`), et un
   * long groupe la tiendrait au plancher de huit secondes pendant tout le groupe.
   */
  audioRoom() {
    const budget = this.audioBudget;
    const ranges = this.host.audioOps()?.buffer.buffered;
    if (!budget || !ranges) return null;
    const now = this.host.anchor();
    let held = 0;
    let ahead = 0;
    for (let i = 0; i < ranges.length; i++) {
      held += ranges.end(i) - ranges.start(i);
      if (ranges.start(i) <= now + 0.1 && now < ranges.end(i)) ahead = ranges.end(i) - now;
    }
    return budget.totalSeconds - (held - ahead);
  }
  /**
   * L'avance visée : la plus petite de la cible de ce fichier, du budget en octets, et de la place
   * que le son a réellement (`audioRoom`) — jamais sous le plancher de huit secondes, sans quoi un
   * arrière pas encore retiré arrêterait la lecture elle-même.
   */
  get aheadTarget() {
    const room = this.audioRoom();
    return Math.min(this.targetBuffer, this.budget?.aheadSeconds ?? Infinity, room === null ? Infinity : Math.max(MIN_BUFFER_SECONDS, room));
  }
};

// src/engine/mseRecoveryLadder.ts
var RecoveryLadder = class {
  constructor(host) {
    this.host = host;
  }
  host;
  recoveries = 0;
  recoveryTarget = -1;
  recoveryStreak = 0;
  lastRecoveryAt = 0;
  /**
   * Which rung of the recovery ladder has been climbed since the clock last really played: 0 none,
   * 1 the keyframe step, 2 handed to the host for a rebuild. See `escalate`.
   */
  escalation = 0;
  escalations = 0;
  /** Recoveries since the clock last really played — see `MAX_UNPLAYED_ATTEMPTS`. */
  unplayedAttempts = 0;
  /** Seconds the clock has genuinely run since the last recovery. */
  playedSinceTrouble = 0;
  /**
   * Seeks to where the viewer is, unless that has already been tried and did not help.
   *
   * Both recovery routes converge here so they share one limit. Without it, a target the file
   * genuinely cannot serve — an index pointing somewhere the media is not — turns a recovery
   * into a loop that seeks, fails to arrive, and seeks again as fast as it can.
   */
  recover(target) {
    if (Date.now() - this.lastRecoveryAt > RECOVERY_WINDOW_MS) this.recoveryStreak = 0;
    const sameSpot = Math.abs(target - this.recoveryTarget) < 1;
    if (sameSpot && this.recoveryStreak >= MAX_RECOVERY_ATTEMPTS || this.unplayedAttempts >= MAX_UNPLAYED_ATTEMPTS) {
      return this.escalate(target);
    }
    if (sameSpot) this.recoveryStreak += 1;
    else {
      this.recoveryTarget = target;
      this.recoveryStreak = 1;
    }
    this.attempt(target, `reprise ${this.recoveryStreak}`);
    return true;
  }
  /** One recovery seek, counted everywhere it has to be. */
  attempt(target, because) {
    this.lastRecoveryAt = Date.now();
    this.recoveries += 1;
    this.unplayedAttempts += 1;
    this.playedSinceTrouble = 0;
    void this.host.seek(target, because);
  }
  /**
   * Asking for the same spot again has not helped: the next rung, or false when none is left.
   *
   * Giving up used to be the last word — traced, and then nothing, for as long as the viewer
   * waited. The rungs, each tried once until the clock has really played again:
   *
   * 1. **The next keyframe past the head.** The same position re-read is the same group of
   *    pictures decoded the same way; an open-GOP keyframe ten seconds on is a group nothing has
   *    touched. A viewer loses a few seconds rather than the film.
   * 2. **Nothing more here** — false, and the caller hands over (`handOver`) so the host rebuilds
   *    the whole pipeline at the head, within its own budget.
   *
   * Still traced rather than shown, as the abandon always was: the remuxer's own index back-up
   * regularly lands a position a moment after the source has given up on it, and a banner
   * announced a failure to a viewer whose film was about to carry on.
   */
  escalate(target) {
    if (this.escalation >= 1) return false;
    this.escalation = 1;
    this.escalations += 1;
    trace(`reprise abandonn\xE9e apr\xE8s ${this.recoveryStreak} tentatives vers ${target.toFixed(1)} s`);
    const next = this.nextKeyframeAfter(target);
    if (next === null) return false;
    trace(`reprise : image cl\xE9 suivante, ${next.toFixed(1)} s`);
    this.recoveryTarget = next;
    this.recoveryStreak = 1;
    this.attempt(next, "reprise : image cl\xE9 suivante");
    return true;
  }
  /**
   * The next indexed keyframe on the player's clock, far enough past `target` to be a different
   * group, or null. Never throws: this runs on the path that is already failing.
   */
  nextKeyframeAfter(target) {
    try {
      if (!this.host.remuxer.seekable) return null;
      const fileSeconds = this.host.remuxer.keyframeAfter(this.host.toFileClock(target) + 0.5);
      if (fileSeconds === null) return null;
      const end = this.host.playerEnd;
      const next = fileSeconds + this.host.delaySeconds + NEXT_KEYFRAME_MARGIN;
      return next < end - 1 ? next : null;
    } catch {
      return null;
    }
  }
};

// src/engine/mseFrozenClock.ts
var FrozenClockWatch = class {
  constructor(host) {
    this.host = host;
  }
  host;
  /** For the frozen-clock check: where the clock was, since when, and how often it was pushed. */
  lastClockAt = -1;
  frozenSince = null;
  frozenNudges = 0;
  /** Every push over the session, for the `stop` line — the one above resets when the clock moves. */
  frozenNudgesTotal = 0;
  /** La position redemandée une fois après l'atterrissage de l'ouverture — voir `OPENING_REASSERT_MS`. */
  openingReassertTimer = null;
  openingReassertDone = false;
  /** Le dernier `playing` de l'élément — voir `OPENING_PLAYING_GRACE_MS`. */
  lastPlayingAt = 0;
  /** La poussée de l'ouverture au bout du délai de grâce — voir `armOpeningGracePush`. */
  openingGraceTimer = null;
  /** Le placement de l'ouverture a abouti de lui-même (`playing`, `seeked`) : plus rien à redemander. */
  settleOpeningReassert() {
    if (this.openingReassertTimer === null) return;
    clearTimeout(this.openingReassertTimer);
    this.openingReassertTimer = null;
    this.openingReassertDone = true;
  }
  /** Ce que le décodeur traverse depuis le début de la plage sous la tête ; inconnu, le plafond. */
  decodeDistance(now) {
    const ranges = this.host.playable;
    const i = rangeAround(ranges, now, 0);
    if (i >= 0) return now - ranges.start(i);
    return (FROZEN_SEEKING_MS - FROZEN_CLOCK_MS) / SEEKING_PATIENCE_PER_SECOND_MS;
  }
  /**
   * Arme, une seule fois par source, la position redemandée 100 ms après l'atterrissage de
   * l'ouverture — voir `OPENING_REASSERT_MS`.
   *
   * Seulement pour l'ouverture (la garde attend encore sa première image, près de là où elle s'est
   * ouverte) et seulement au bord du média : une reprise posée loin derrière son image clé décode
   * vraiment, et la relancer recommencerait ce décodage. Le pas est celui de la poussée (+0,08 s),
   * le seul qui ait été vu libérer ce gel ; il est compté comme un placement (`headPlaced`), pas
   * comme de la lecture, et ne consomme pas la poussée de 400 ms, qui reste le filet.
   */
  armOpeningReassert(at) {
    if (this.openingReassertDone || this.openingReassertTimer !== null || this.host.destroyed) return;
    if (!this.host.guard.awaitingFirstPicture || this.decodeDistance(at) >= OPENING_EDGE_SECONDS) return;
    this.openingReassertTimer = setTimeout(() => {
      this.openingReassertTimer = null;
      this.openingReassertDone = true;
      if (this.host.destroyed || this.host.video.paused || !this.host.guard.awaitingFirstPicture) return;
      const now = this.host.video.currentTime;
      if (!this.host.video.seeking && Math.abs(now - at) > 0.05) return;
      if (!this.host.video.seeking && this.host.video.readyState >= 3) return;
      if (this.decodeDistance(now) >= OPENING_EDGE_SECONDS || this.host.lead < 1) return;
      const target = now + FROZEN_STEP;
      trace(`ouverture : rien n'a boug\xE9 100 ms apr\xE8s l'atterrissage \xE0 ${now.toFixed(2)} s \u2014 position redemand\xE9e`);
      this.host.guard.forgetPause();
      this.host.seekState.moved(target);
      this.host.guard.headPlaced(target);
      this.host.video.currentTime = target;
      this.lastClockAt = target;
      this.frozenSince = Date.now();
    }, OPENING_REASSERT_MS);
  }
  /**
   * La poussée de l'ouverture, pile au bout du délai de grâce qui suit `playing` (26/10/2026).
   *
   * Elle attendait le passage suivant du chien de garde, toutes les 250 ms : sur iPhone, les départs
   * du début figés (69 % en Dolby Vision) étaient poussés 750 ms en médiane après `playing`, au lieu
   * des 600 voulus, puis la première image venait encore ~500 ms plus tard (journal relu le
   * 26/10/2026 : 43 départs figés). Le seuil ne change pas — un départ sain montre son image 250 ms
   * après `playing` (450 ms pour neuf sur dix), et une poussée sur un élément qui démarre le refige,
   * d'où `OPENING_PLAYING_GRACE_MS` —, seul le retard du chien de garde disparaît. Une seule fois, à
   * l'ouverture, au bord du média, avant toute autre poussée ; le chien de garde reste le filet.
   */
  armOpeningGracePush() {
    if (this.openingGraceTimer !== null) clearTimeout(this.openingGraceTimer);
    this.openingGraceTimer = null;
    if (this.host.destroyed || !this.host.guard.awaitingFirstPicture || this.frozenNudges > 0) return;
    const at = this.host.video.currentTime;
    if (this.decodeDistance(at) >= OPENING_EDGE_SECONDS) return;
    this.openingGraceTimer = setTimeout(() => {
      this.openingGraceTimer = null;
      if (this.host.destroyed || this.host.video.paused || !this.host.guard.awaitingFirstPicture || this.frozenNudges > 0) return;
      const now = this.host.video.currentTime;
      if (Math.abs(now - at) > 0.05) return;
      if (this.host.lead < 1) return;
      this.frozenSince = Date.now();
      this.nudge(now);
    }, OPENING_PLAYING_GRACE_MS);
  }
  /**
   * Combien de temps laisser un saut en cours finir de décoder : ce qu'il a réellement à décoder.
   *
   * Le média sous la tête commence à l'image clé d'où le décodage repart ; la distance jusqu'à la
   * tête est ce que le décodeur doit traverser avant de montrer quoi que ce soit. `FROZEN_SEEKING_MS`
   * a été fixé pour le pire cas (neuf secondes de 4K dans un film) et s'appliquait à tous : un saut
   * dans une zone relue depuis une image clé à 2,8 s restait figé six secondes sous Safari avant
   * d'être poussé — deux fois dans la même séance sur un Mac, une fois sur un iPhone (journal du
   * 24/09/2026), là où la poussée le débloquait aussitôt. Une demi-seconde par seconde à décoder,
   * au-dessus du délai ordinaire, plafonnée à l'ancien délai : ce film retrouve exactement ses six
   * secondes. Une plage qui commence loin derrière (un saut dans un long tampon continu) garde le
   * plafond — la vraie image clé est inconnue, et on reste alors sur la prudence d'avant.
   */
  seekingPatienceMs(now) {
    const ranges = this.host.playable;
    const i = rangeAround(ranges, now, 0);
    if (i >= 0) {
      const toDecode = now - ranges.start(i);
      return Math.min(FROZEN_SEEKING_MS, FROZEN_CLOCK_MS + SEEKING_PATIENCE_PER_SECOND_MS * toDecode);
    }
    return FROZEN_SEEKING_MS;
  }
  /**
   * The other kind of stall: playing, media under the playhead, and a clock that does not move.
   *
   * Everything above watches for a playhead standing on nothing, because that was every stall
   * there had been. This one is the opposite shape and nothing could see it: an episode opened
   * from the beginning reported itself as playing, with the playhead on the media and twenty
   * seconds buffered ahead of it, and stayed at 0:00. The element was waiting on a seek to the
   * exact first instant of the buffered range that never completed — so from here it looked
   * perfectly healthy, which is why it went unnoticed until it was reported from a phone.
   *
   * Answered the same way as the other, and just as bluntly: ask for the position again, a
   * fraction of a second further in, which is what completes a seek that never resolved.
   */
  watchForFrozenClock(now) {
    const moved = Math.abs(now - this.lastClockAt) > 0.05;
    if (moved || this.frozenSince === null) {
      this.lastClockAt = now;
      this.frozenSince = moved || this.frozenSince === null ? Date.now() : this.frozenSince;
      if (moved) this.frozenNudges = 0;
      return;
    }
    const ordinary = this.host.video.seeking ? this.seekingPatienceMs(now) : FROZEN_CLOCK_MS;
    const patience = this.host.guard.awaitingFirstPicture && this.frozenNudges === 0 && this.decodeDistance(now) < OPENING_EDGE_SECONDS ? FROZEN_OPENING_MS : ordinary;
    if (Date.now() - this.frozenSince < patience) return;
    if (patience === FROZEN_OPENING_MS && Date.now() - this.lastPlayingAt < OPENING_PLAYING_GRACE_MS) return;
    if (this.host.lead < 1) return;
    this.frozenSince = Date.now();
    if (this.frozenNudges >= MAX_FROZEN_NUDGES) {
      trace(`horloge fig\xE9e \xE0 ${now.toFixed(2)} s malgr\xE9 ${this.frozenNudges} pouss\xE9es \u2014 reprise`);
      if (!this.host.recover(now + FROZEN_STEP)) this.host.handOver(now);
      this.lastClockAt = now + FROZEN_STEP;
      return;
    }
    this.nudge(now);
  }
  /** Redemander la position un pas plus loin — la poussée, du chien de garde ou de l'ouverture. */
  nudge(now) {
    this.frozenNudges += 1;
    this.frozenNudgesTotal += 1;
    trace(`horloge fig\xE9e \xE0 ${now.toFixed(2)} s avec ${this.host.lead.toFixed(1)} s en avance \u2014 on redemande la position`);
    this.host.guard.forgetPause();
    this.host.seekState.moved(now + FROZEN_STEP);
    this.host.guard.headPlaced(now + FROZEN_STEP);
    this.host.video.currentTime = now + FROZEN_STEP;
    this.lastClockAt = now + FROZEN_STEP;
  }
};

// src/engine/mseStartHold.ts
var START_HOLD_LANDED_MS = 1e3;
var START_HOLD_MAX_MS = 15e3;
var EVENTS = ["seeked", "loadeddata", "canplay", "play"];
var HAVE_CURRENT_DATA = 2;
var OpeningStartHold = class {
  constructor(host) {
    this.host = host;
    this.released = new Promise((resolve) => {
      this.release = resolve;
    });
    for (const type of EVENTS) host.video.addEventListener(type, this.check);
    this.maxTimer = setTimeout(() => this.open(`aucune image en ${START_HOLD_MAX_MS / 1e3} s`, true), START_HOLD_MAX_MS);
  }
  host;
  /** Résolue quand le départ est permis — ou quand la source est détruite. */
  released;
  release = null;
  armedAt = Date.now();
  landedTimer = null;
  maxTimer;
  frameCallback = null;
  /** Vrai tant que le départ attend : `play()` n'a pas à être appelé, ni par l'hôte ni par la garde. */
  get holding() {
    return this.release !== null;
  }
  /**
   * Relu après chaque envoi (la tête vient peut-être d'être posée) et à chaque événement de
   * l'élément qui peut annoncer l'image.
   */
  check = () => {
    if (!this.holding) return;
    const video = this.host.video;
    if (!video.paused) return this.open("\xE9l\xE9ment d\xE9j\xE0 lanc\xE9", false);
    if (!this.host.headOnMedia()) return;
    if (!video.seeking && video.readyState >= HAVE_CURRENT_DATA) return this.open("image pr\xEAte", false);
    if (this.landedTimer !== null) return;
    this.landedTimer = setTimeout(() => this.open(`pas d'image ${START_HOLD_LANDED_MS} ms apr\xE8s l'atterrissage`, true), START_HOLD_LANDED_MS);
    this.watchFrame();
  };
  /**
   * L'image présentée elle-même, là où le navigateur sait la signaler : un élément à l'arrêt en
   * présente une à la fin d'un saut. Un appoint aux événements, jamais une condition.
   */
  watchFrame() {
    const video = this.host.video;
    const request = video.requestVideoFrameCallback?.bind(video);
    if (!request) return;
    const step = () => {
      this.frameCallback = null;
      if (!this.holding) return;
      if (video.seeking) {
        this.frameCallback = request(step);
        return;
      }
      this.open("image pr\xE9sent\xE9e", false);
    };
    this.frameCallback = request(step);
  }
  open(why, timedOut) {
    const release = this.release;
    if (release === null) return;
    const video = this.host.video;
    trace(
      `ouverture : d\xE9part permis (${why}) \u2014 t\xEAte \xE0 ${video.currentTime.toFixed(2)} s, readyState ${video.readyState}${video.seeking ? ", saut en cours" : ""}, apr\xE8s ${Date.now() - this.armedAt} ms`
    );
    this.stop();
    release();
    this.host.released(timedOut);
  }
  stop() {
    this.release = null;
    for (const type of EVENTS) this.host.video.removeEventListener(type, this.check);
    clearTimeout(this.maxTimer);
    if (this.landedTimer !== null) clearTimeout(this.landedTimer);
    this.landedTimer = null;
    if (this.frameCallback !== null) this.host.video.cancelVideoFrameCallback?.(this.frameCallback);
    this.frameCallback = null;
  }
  /**
   * La source meurt : la promesse se résout quand même — une attente que personne ne lève est un
   * chargement sans fin —, et l'hôte, qui revérifie après elle, ne lance rien.
   */
  destroy() {
    const release = this.release;
    if (release === null) return;
    this.stop();
    release();
  }
};

// src/engine/mseSource.ts
var MseSource = class _MseSource {
  constructor(video, remuxer, plan, callbacks, Source) {
    this.video = video;
    this.remuxer = remuxer;
    this.plan = plan;
    this.callbacks = callbacks;
    this.source = new Source();
    const self = this;
    this.guard = new PlaybackGuard(
      video,
      {
        get destroyed() {
          return self.destroyed;
        },
        get delaySeconds() {
          return self.delaySeconds;
        },
        get playable() {
          return self.playable;
        },
        seek: (seconds2, because) => this.seek(seconds2, because),
        noteSeekTarget: (seconds2) => {
          this.seekState.moved(seconds2);
          if (!this.startHold?.holding) this.armOpeningReassert(seconds2);
        }
      },
      callbacks.onStarting
    );
    this.loss = new LossRecord({
      video,
      get videoBuffer() {
        return self.videoBuffer;
      },
      get audioBuffer() {
        return self.audioBuffer;
      },
      stateFacts: (now) => this.stateFacts(now)
    });
    this.zones = new UnreadableZoneHold({
      get destroyed() {
        return self.destroyed;
      },
      get delaySeconds() {
        return self.delaySeconds;
      },
      get anchor() {
        return self.anchor;
      },
      get lead() {
        return self.lead;
      },
      bufferedEnd: () => this.bufferedEnd(),
      video,
      remuxer,
      callbacks,
      elementState: () => this.elementState()
    });
    this.ladder = new RecoveryLadder({
      seek: (playerSeconds, because) => this.seek(playerSeconds, because),
      remuxer,
      toFileClock: (playerSeconds) => this.toFileClock(playerSeconds),
      get playerEnd() {
        return self.playerEnd;
      },
      get delaySeconds() {
        return self.delaySeconds;
      }
    });
    this.clock = new FrozenClockWatch({
      get destroyed() {
        return self.destroyed;
      },
      video,
      guard: this.guard,
      seekState: this.seekState,
      get lead() {
        return self.lead;
      },
      get playable() {
        return self.playable;
      },
      recover: (target) => this.recover(target),
      handOver: (at) => this.handOver(at)
    });
  }
  video;
  remuxer;
  plan;
  callbacks;
  source;
  videoBuffer = null;
  audioBuffer = null;
  videoOps = null;
  audioOps = null;
  /** Consecutive refused appends. A single one is worth retrying; a run of them is not. */
  appendFailures = 0;
  /** Nouveaux essais réseau faits sans vider le tampon depuis le dernier envoi réussi. */
  networkRetries = 0;
  networkRetryTimer = null;
  networkRetryGeneration = 0;
  /**
   * La lecture a repris après une coupure sans vider le tampon : le premier segment relu remplace
   * ce que le tampon tient déjà à partir de son propre début, qui est retiré juste avant l'envoi.
   */
  trimBeforeNextAppend = false;
  /**
   * Plus aucune lecture jusqu'au nouvel essai : le lecteur de fichier est resté là où l'erreur l'a
   * laissé, peut-être au milieu d'une grappe, et seul le nouvel essai le repositionne. Sans ce
   * verrou, le premier `timeupdate` relançait le remplissage sur ce lecteur-là. Un saut le lève :
   * il repositionne tout lui-même.
   */
  networkHold = false;
  /**
   * Une coupure en pleine lecture tenue (§97) : le tampon gardé quelle que soit l'avance, de nouveaux
   * essais sans fin (`NETWORK_RETRY_DELAYS_MS`, puis le dernier), jusqu'à la borne de
   * `watchForOutage`. Retombe au premier envoi accepté.
   */
  outageHold = false;
  /** La main est passée à l'hôte pour une coupure (§97) : plus rien ne part d'ici. */
  networkGaveUp = false;
  /**
   * Everything about the element's own clock — pausing, resuming, landing after a seek, starting
   * a film the element gave up on. A different subject from moving bytes, with a
   * different kind of evidence behind it, so it lives in its own file.
   */
  guard;
  /** Pas de démarrage dû à l'ouverture : la garde ne relance pas un élément laissé à l'arrêt. */
  startPaused = false;
  objectUrl = null;
  /** The read loop in flight, if any. A seek has to let it finish before moving the reader. */
  fillTask = null;
  destroyed = false;
  ended = false;
  /** Bumped by every seek, so appends already in flight are recognised as stale and dropped. */
  generation = 0;
  pending = Promise.resolve();
  /** Le saut : demandé, servi, en route, arrivé — voir `SeekLifecycle`. */
  seekState = new SeekLifecycle();
  /** Le dernier saut servi et comment — voir `seekPathFor`. */
  lastServed = null;
  /** La dernière position où l'élément jouait sans sauter — où revenir d'un saut refusé. */
  lastPlayedAt = 0;
  delaySeconds = 0;
  /**
   * Où le film doit s'ouvrir, tant que le média n'est pas encore là pour l'y recevoir.
   *
   * Voir `placePendingStart`. `null` dès que la tête y a été posée, et dès le départ pour une
   * ouverture au début, qui n'a personne à attendre.
   */
  pendingStart = null;
  /**
   * Le départ d'une ouverture depuis le début, retenu jusqu'à la première image — voir
   * `OpeningStartHold` (26/10/2026). `null` pour une reprise, une ouverture laissée à l'arrêt, et
   * dès que le départ est permis.
   */
  startHold = null;
  lastAppendAt = 0;
  /**
   * Jusqu'où le lecteur de fichier a lu, **sur l'horloge du fichier** — celle de
   * `segment.endSeconds` et de `Remuxer.seekTo`, sans le décalage de présentation. Qui la compare
   * au tampon ou à la tête lui ajoute `delaySeconds` ; qui y range une position du lecteur le lui
   * retire (`toFileClock`). Le commentaire la disait sur l'horloge du lecteur, et trois écrivains sur quatre l'ont
   * cru : le nouvel essai d'une coupure réseau retirait le décalage une seconde fois, repartait du
   * groupe d'avant quand la lecture s'était arrêtée pile sur une image clé, et ce groupe, commencé
   * sous la tête, faisait vider les deux tampons (audit du 29/09/2026).
   */
  readUpTo = 0;
  seeksServed = 0;
  /**
   * Les retraits en cours de ce lecteur, par tampon — ce qui distingue, dans `bufferedchange`, nos
   * propres purges de celles que le système décide seul. Voir `removeRange`.
   */
  ownRemovals = /* @__PURE__ */ new Map();
  /** Les écouteurs `bufferedchange`, pour les retirer à la destruction. */
  evictionListeners = [];
  /** Plages retirées par le navigateur sur la séance, et parmi elles celles devant la tête. */
  evictions = 0;
  evictionsAhead = 0;
  /** Les relectures d'éviction de la dernière minute, et celle qui attend la lecture en cours. */
  evictionRefills = [];
  evictionRefillQueued = false;
  /** L'échelle des reprises — voir `RecoveryLadder`. */
  ladder;
  watchdogTimer = null;
  /**
   * La profondeur visée et le budget — voir `BufferPlanner`. Construit à la place des champs qu'il
   * reprend, pour lire le plafond du navigateur au même moment. `targetBuffer`, `videoRate` et
   * `audioRate` restent lisibles ici sous leur nom : `quotaHit` abaisse la cible, `runFill` mesure le
   * débit, et webcodecs-mseSource.test.ts les lit sur l'instance.
   */
  planner = new BufferPlanner({
    anchor: () => this.anchor,
    videoOps: () => this.videoOps,
    audioOps: () => this.audioOps
  });
  get targetBuffer() {
    return this.planner.targetBuffer;
  }
  set targetBuffer(seconds2) {
    this.planner.targetBuffer = seconds2;
  }
  get videoRate() {
    return this.planner.videoRate;
  }
  get audioRate() {
    return this.planner.audioRate;
  }
  /**
   * L'horloge figée et la position redemandée à l'ouverture — voir `FrozenClockWatch`.
   * `frozenSince`, `frozenNudges` et `lastPlayingAt` restent lisibles et écrivables ici sous leur
   * nom : webcodecs-mseSource.test.ts les lit, et recule les deux instants pour simuler le temps.
   */
  clock;
  get frozenSince() {
    return this.clock.frozenSince;
  }
  set frozenSince(at) {
    this.clock.frozenSince = at;
  }
  get frozenNudges() {
    return this.clock.frozenNudges;
  }
  set frozenNudges(n) {
    this.clock.frozenNudges = n;
  }
  get lastPlayingAt() {
    return this.clock.lastPlayingAt;
  }
  set lastPlayingAt(at) {
    this.clock.lastPlayingAt = at;
  }
  /**
   * Handed to the host: nothing more this source can try. Reads as `lost`, so the host's own
   * rebuild — its budget, its skip past a place that failed twice — takes over from here.
   */
  stuck = false;
  /** La zone illisible (§93) — voir `UnreadableZoneHold`. */
  zones;
  /** Où reprendre après `handOver` — voir `position`. */
  handedOverAt = null;
  /** For the stall line: where the clock was, since when, and whether this stall was written. */
  stallClockAt = -1;
  stallSince = null;
  stallReported = false;
  lastStallReportAt = -Infinity;
  /** The clock as last seen by the watchdog, to tell playback from a jump. */
  tickClockAt = -1;
  /**
   * Secondes d'horloge écoulées sans média sous la tête, depuis la dernière fois qu'il y en avait.
   * Voir `RUNAWAY_REPORT_SECONDS`.
   */
  runawaySeconds = 0;
  /** Le tour où la tête hors de sa place a été traitée — pour que le chien de garde n'agisse pas deux fois. */
  headAwayHandledAt = -1;
  static async attach(video, remuxer, plan, callbacks, startSeconds = 0, startPaused = false) {
    const Source = sourceConstructor();
    if (!Source) throw new Error("Ce navigateur ne propose pas MediaSource.");
    const instance = new _MseSource(video, remuxer, plan, callbacks, Source);
    instance.startPaused = startPaused;
    await instance.open(startSeconds);
    return instance;
  }
  /** L'avance sous la tête, en secondes — ce que la réserve d'avance en mémoire (`MemoryReserve`) regarde avant de prendre le lien. */
  get bufferedLead() {
    return this.lead;
  }
  /**
   * Le départ retenu d'une ouverture depuis le début — voir `OpeningStartHold` : la promesse que
   * l'hôte attend avant d'appeler `play()`, ou `null` quand rien n'est retenu (une reprise, une
   * ouverture laissée à l'arrêt, un départ déjà permis), et alors rien ne change pour lui.
   */
  openingHold() {
    return this.startHold?.holding ? this.startHold.released : null;
  }
  /** Where the player's clock sits relative to the file's. Already applied to every seek here. */
  get presentationDelay() {
    return this.delaySeconds;
  }
  appendsTraced = 0;
  /**
   * Envois depuis le dernier saut (ou l'ouverture) : seuls les premiers sont tracés. Écrite à
   * chaque segment jusqu'au 22/09/2026, la ligne « après envoi » occupait à elle seule les quarante
   * étapes des lignes `seek` et `stall`, et masquait ce qui s'y était passé.
   */
  appendsSinceSeek = 0;
  /** Le premier envoi après un saut écrit ce que le réseau a coûté — voir `NetworkWindow`. */
  seekNetworkPending = false;
  /** Le premier envoi de cette source a-t-il eu lieu ? Voir la boucle de remplissage. */
  openingSettled = false;
  /**
   * Le relevé d'une perte — voir `LossRecord`. Les fragments envoyés restent lisibles ici sous leur
   * nom : `performSeek` les vide, et webcodecs-mseSource.test.ts les lit sur l'instance.
   */
  loss;
  get sentFragments() {
    return this.loss.sentFragments;
  }
  set sentFragments(fragments) {
    this.loss.sentFragments = fragments;
  }
  get fragmentsSinceSeek() {
    return this.loss.fragmentsSinceSeek;
  }
  set fragmentsSinceSeek(n) {
    this.loss.fragmentsSinceSeek = n;
  }
  async open(startSeconds) {
    this.video.disableRemotePlayback = true;
    trace("attente de sourceopen");
    let openTimer;
    const opened = new Promise((resolve, reject) => {
      this.source.addEventListener("sourceopen", () => resolve(), { once: true });
      openTimer = setTimeout(
        () => reject(new Error(`MediaSource jamais ouverte en ${SOURCE_OPEN_TIMEOUT_MS / 1e3} s. ${this.elementState()}`)),
        SOURCE_OPEN_TIMEOUT_MS
      );
    });
    try {
      this.video.srcObject = this.source;
    } catch {
      this.objectUrl = URL.createObjectURL(this.source);
      this.video.src = this.objectUrl;
    }
    if (!this.objectUrl && !this.video.srcObject) {
      this.objectUrl = URL.createObjectURL(this.source);
      this.video.src = this.objectUrl;
    }
    try {
      await opened;
    } catch (error) {
      this.destroy();
      throw error;
    } finally {
      clearTimeout(openTimer);
    }
    if (this.destroyed) return;
    try {
      trace("MediaSource ouverte, cr\xE9ation des tampons");
      this.videoBuffer = this.source.addSourceBuffer(this.plan.videoMimeType);
      this.videoBuffer.mode = "segments";
      this.videoOps = new BufferQueue(this.videoBuffer, () => this.elementState());
      if (this.plan.audioMimeType) {
        this.audioBuffer = this.source.addSourceBuffer(this.plan.audioMimeType);
        this.audioBuffer.mode = "segments";
        this.audioOps = new BufferQueue(this.audioBuffer, () => this.elementState());
      }
      this.watchEvictions(this.videoBuffer, "vid\xE9o");
      if (this.audioBuffer) this.watchEvictions(this.audioBuffer, "audio");
      await this.appendTo(this.videoOps, this.plan.videoInit, this.generation);
      trace("segment d'initialisation vid\xE9o accept\xE9");
      if (this.audioOps && this.plan.audioInit) {
        await this.appendTo(this.audioOps, this.plan.audioInit, this.generation);
        trace("segment d'initialisation audio accept\xE9");
      }
      if (this.plan.durationSeconds > 0) startSeconds = Math.min(startSeconds, Math.max(0, this.plan.durationSeconds - 2));
      if (startSeconds > NO_INDEX_REACH_SECONDS && reachable(this.remuxer.seekable, startSeconds)) {
        this.remuxer.seekTo(startSeconds);
        this.seekState.serving(startSeconds);
        this.pendingStart = startSeconds;
      }
      if (this.pendingStart === null) this.guard.opened(this.video.currentTime, !this.startPaused);
      if (this.pendingStart === null && !this.startPaused) {
        this.startHold = new OpeningStartHold({
          video: this.video,
          headOnMedia: () => this.isBufferedAt(this.video.currentTime),
          released: (timedOut) => {
            this.startHold = null;
            if (timedOut) this.armOpeningReassert(this.video.currentTime);
          }
        });
      }
      this.video.addEventListener("error", this.onElementError);
      this.source.addEventListener("sourceclose", this.onSourceClosed);
      this.source.addEventListener("startstreaming", this.request);
      this.video.addEventListener("timeupdate", this.request);
      this.video.addEventListener("waiting", this.request);
      this.video.addEventListener("seeking", this.onSeeking);
      this.video.addEventListener("seeked", this.onSeeked);
      this.video.addEventListener("pause", this.guard.paused);
      this.video.addEventListener("play", this.onPlay);
      this.video.addEventListener("playing", this.request);
      this.video.addEventListener("playing", this.onPlaying);
      if (typeof window !== "undefined" && typeof window.addEventListener === "function") window.addEventListener("online", this.onOnline);
      this.lastAppendAt = Date.now();
      this.watchdogTimer = setInterval(this.watchdog, WATCHDOG_MS);
      void this.fill();
    } catch (error) {
      this.destroy();
      throw error;
    }
  }
  /** The clock moved: the guard decides what that means, the source reads on. */
  request = () => {
    this.guard.clockTicked();
    void this.fill();
  };
  /**
   * A clock is only frozen relative to the last time the element said it was running.
   *
   * Both events reset it, and both matter: `play` is fired the moment playback is *asked* for,
   * `playing` when it actually gets going, and between the two sits the whole of the resume
   * machinery putting the position back where the viewer left it. Counting through that window
   * meant the frozen-clock check could push the playhead of an element that had just been handed
   * back — which is precisely what that machinery spends its time getting right.
   */
  onResumed = () => {
    this.clock.frozenSince = null;
    this.clock.lastClockAt = -1;
  };
  /** `playing` : l'élément repart vraiment — `play` n'est que la demande. */
  onPlaying = () => {
    this.onResumed();
    this.clock.lastPlayingAt = Date.now();
    this.clock.settleOpeningReassert();
    this.clock.armOpeningGracePush();
  };
  onPlay = () => {
    this.onResumed();
    this.guard.playing();
    void this.fill();
  };
  onElementError = () => {
    trace(`l'\xE9l\xE9ment a \xE9chou\xE9 : ${this.elementState()}`);
    this.noteLoss();
  };
  onSourceClosed = () => {
    trace(`la MediaSource s'est ferm\xE9e \u2014 ${this.elementState()}`);
    this.noteLoss();
  };
  noteLoss() {
    this.loss.noteLoss();
  }
  /**
   * L'image clé indexée qui suit cet instant (au moins une demi-seconde après), sur l'horloge du lecteur, juste dans
   * son groupe (`NEXT_KEYFRAME_MARGIN`), ou null — sans index, ou trop près de la fin. Où rouvrir après une perte
   * répétée au même endroit (`PlayerLifecycle.sourceLost`) : une image abîmée dans le fichier (enquête du 17/11/2026,
   * Une série et S01E01) se décode mal à chaque passage, et le groupe suivant n'en dépend pas. Le même
   * calcul que l'échelle de reprise (`RecoveryLadder.nextKeyframeAfter`). Ne lève jamais : sur le chemin d'une panne.
   */
  nextKeyframeAfter(playerSeconds) {
    try {
      if (!this.remuxer.seekable) return null;
      const fileSeconds = this.remuxer.keyframeAfter(this.toFileClock(playerSeconds) + 0.5);
      if (fileSeconds === null) return null;
      const next = fileSeconds + this.delaySeconds + NEXT_KEYFRAME_MARGIN;
      return next < this.playerEnd - 1 ? next : null;
    } catch {
      return null;
    }
  }
  /**
   * Comment le saut vers `target` a été servi — `mémoire`, `devant` ou `complet` —, ou null : servi
   * pour une autre cible (un geste plus récent, ou celui-ci pas encore servi), ou refusé. Pour la
   * ligne `seek` ; ne lève jamais.
   */
  seekPathFor(target) {
    const served = this.lastServed;
    return served && Math.abs(served.target - target) < 0.05 ? served : null;
  }
  /** Voir `LossRecord.lossReport`. */
  lossReport() {
    return this.loss.lossReport();
  }
  onSeeking = () => {
    if (this.destroyed) return;
    const target = this.video.currentTime;
    this.seekState.started(target, Date.now());
    if (this.seekState.isOwnMove(target)) return void this.fill();
    trace(`saut de l'\xE9l\xE9ment vers ${target.toFixed(1)} s \u2014 vid\xE9o ${spansNear(this.videoBuffer, target)} \xB7 audio ${this.audioBuffer ? spansNear(this.audioBuffer, target) : "aucun"}`);
    this.guard.forgetPause();
    if (this.isBufferedAt(target) && this.seekState.requested === null) {
      this.lastServed = { target, path: "m\xE9moire", keptS: null };
      return void this.fill();
    }
    if (this.seekState.requested === null) {
      const edge = startJustAfter(this.playable, target, ONE_FRAME_S);
      if (edge !== null) {
        trace(`saut \xE0 ${Math.round((edge - target) * 1e3)} ms du charg\xE9 \u2014 pos\xE9 sur son d\xE9but (${edge.toFixed(2)} s)`);
        this.lastServed = { target, path: "m\xE9moire", keptS: null };
        this.video.currentTime = edge;
        return;
      }
    }
    void this.seek(target);
  };
  /**
   * What the element can actually play.
   *
   * Not the video buffer's own ranges: an element plays only where *every* track it is using has
   * media, and the media element reports precisely that intersection. Audio after a seek starts
   * consistently a fraction of a second later than video, so measuring the video buffer alone is
   * optimistic by exactly that much — it reports the playhead as covered while the element is
   * still waiting for sound.
   */
  get playable() {
    return this.video.buffered;
  }
  /**
   * Une position du lecteur sur l'horloge du fichier — celle de `Remuxer.seekTo`, de
   * `keyframeAtOrBefore` et de `readUpTo`. Écrite à la main sept fois avant le 22/10/2026 ; c'est
   * précisément la conversion que « trois écrivains sur quatre » s'étaient trompés de sens (voir
   * `readUpTo`).
   */
  toFileClock(playerSeconds) {
    return Math.max(0, playerSeconds - this.delaySeconds);
  }
  /** La fin du film sur l'horloge du lecteur ; sans durée connue, aucune. */
  get playerEnd() {
    return this.plan.durationSeconds > 0 ? this.plan.durationSeconds + this.delaySeconds : Infinity;
  }
  /** How far the playhead is from the nearest media, or 0 when it is standing on some. */
  distanceToMedia(seconds2) {
    const ranges = this.playable;
    if (ranges.length === 0) return Infinity;
    if (rangeAround(ranges, seconds2, 0) >= 0) return 0;
    let best = Infinity;
    for (let i = 0; i < ranges.length; i++) {
      best = Math.min(best, Math.abs(ranges.start(i) - seconds2), Math.abs(ranges.end(i) - seconds2));
    }
    return best;
  }
  isBufferedAt(seconds2) {
    return this.distanceToMedia(seconds2) === 0;
  }
  /** True while the system wants data. Plain MediaSource has no such signal, so it always does. */
  get streamingWanted() {
    const managed = this.source;
    return typeof managed.streaming === "boolean" ? managed.streaming : true;
  }
  /**
   * Où le lecteur travaille — la tête, ou la position qu'elle n'a pas encore rejointe.
   *
   * Tout ce qui mesure « ce qu'on a d'avance » partait de `currentTime`, ce qui était juste tant
   * que la tête était toujours là où le film s'ouvre. Une ouverture en cours de film envoie
   * maintenant son média *avant* de déplacer la tête — c'est ce qui évite à WebKit un `seeking`
   * qu'il ne résout jamais (voir `pendingStart`). Pendant ces quelques centaines de
   * millisecondes, la tête est à zéro et le média arrive à 1200 s : mesurée depuis la tête,
   * l'avance vaut donc zéro segment après segment.
   *
   * Deux conclusions fausses en découlaient, et les deux ramenaient le film à son début : le
   * détecteur de segments sans effet concluait que le navigateur ne retenait rien, et le contrôle
   * d'égarement, que le lecteur remplissait un endroit où personne n'était. « Reprendre »
   * repartait de zéro — deux fois sur trois, selon la vitesse à laquelle l'élément publie ses
   * plages.
   */
  get anchor() {
    return this.pendingStart ?? this.video.currentTime;
  }
  /** How much media sits between the playhead and the end of its own run. */
  get lead() {
    return this.bufferedEnd() - this.anchor;
  }
  /**
   * Jusqu'où chaque tampon, pris seul, couvre la tête — additionné.
   *
   * La profondeur jouable est l'*intersection* des deux tampons. Quand la piste audio s'arrête
   * avant l'image — un générique muet, une piste plus courte que le film —, cette intersection ne
   * grandit plus alors que l'image, elle, continue d'arriver sous la tête : huit segments plus
   * tard, la boucle concluait que le navigateur ne retenait rien, et le film était reconstruit au
   * lieu de finir (relu le 23/09/2026). Seule la plage *sous la tête* compte, tampon par tampon :
   * du média posé ailleurs n'est pas un progrès, et reste ce que la garde doit attraper.
   */
  laneProgress() {
    const now = this.anchor;
    let total = 0;
    for (const ops of [this.videoOps, this.audioOps]) {
      try {
        const ranges = ops?.buffer.buffered;
        if (!ranges) continue;
        for (let i = 0; i < ranges.length; i++) {
          if (ranges.start(i) <= now + 0.1 && now < ranges.end(i)) total += ranges.end(i);
        }
      } catch {
      }
    }
    return total;
  }
  /**
   * How far the media runs on from the playhead without a gap.
   *
   * The range containing the playhead, not simply the last one. After a seek backwards there can
   * be a later range left over, and measuring against that would report a deep buffer while the
   * playhead sits in front of nothing at all — the player would then quietly stop fetching.
   */
  bufferedEnd() {
    const ranges = this.playable;
    const now = this.anchor;
    const i = rangeAround(ranges, now, 0.1);
    return i >= 0 ? ranges.end(i) : now;
  }
  fill() {
    if (this.fillTask) return this.fillTask;
    this.fillTask = this.runFill().finally(() => {
      this.fillTask = null;
    });
    return this.fillTask;
  }
  async runFill() {
    if (this.destroyed || this.ended || this.networkHold || this.networkGaveUp || this.zones.zone || this.zones.zoneHanded) return;
    this.trimBehind();
    const generation = this.generation;
    let deepestSoFar = this.bufferedEnd();
    let furthestLanes = this.laneProgress();
    let fruitless = 0;
    try {
      while (!this.destroyed && this.generation === generation) {
        const lead = this.lead;
        if (lead >= this.aheadTarget && !this.remuxer.stopAhead) break;
        if (lead >= MIN_BUFFER_SECONDS && !this.streamingWanted) break;
        if (this.seekState.requested !== null) break;
        const builtFrom = diagNow();
        const segment = await this.remuxer.nextSegment();
        diagInterval("segment", builtFrom);
        if (this.generation !== generation || this.destroyed || this.networkGaveUp) break;
        if (!segment && this.remuxer.stoppedShort) {
          this.joinKept();
          continue;
        }
        if (this.appendsTraced < TRACED_APPENDS) {
          this.appendsTraced++;
          trace(
            segment ? `segment ${this.appendsTraced} construit \u2014 jusqu'\xE0 ${segment.endSeconds.toFixed(1)} s, ${segment.video.reduce((n, f) => n + f.byteLength, 0)} o vid\xE9o en ${segment.video.length} fragment(s), ${segment.audio?.byteLength ?? 0} o audio` : "le remultiplexeur ne produit plus de segment (fin du fichier)"
          );
        }
        if (!segment) {
          this.ended = true;
          if (this.audioOps) await this.audioOps.enqueue(() => {
          }).catch(() => {
          });
          if (this.generation !== generation || this.destroyed) break;
          if (this.videoOps) await this.videoOps.enqueue(() => this.endStream()).catch(() => this.endStream());
          else this.endStream();
          this.reseekAfterEnd();
          break;
        }
        if (this.delaySeconds === 0) {
          this.delaySeconds = this.remuxer.diagnostics().presentationDelaySeconds;
          const duration = this.plan.durationSeconds + this.delaySeconds;
          if (this.source.readyState === "open" && duration > 0 && Number.isFinite(duration)) {
            try {
              this.source.duration = duration;
            } catch {
            }
          }
        }
        if (segment.subtitles.length > 0) this.callbacks.onSubtitles?.(segment.subtitles);
        const reread = this.trimBeforeNextAppend;
        if (this.trimBeforeNextAppend) {
          this.trimBeforeNextAppend = false;
          const from = this.remuxer.diagnostics().segmentStartSeconds + this.delaySeconds;
          if (from < this.video.currentTime + NETWORK_TRIM_MARGIN_SECONDS) {
            trace(`coupure r\xE9seau : le groupe relu commence \xE0 ${from.toFixed(2)} s, sous la t\xEAte \u2014 reprise habituelle`);
            this.recover(this.anchor);
            break;
          }
          trace(`coupure r\xE9seau : relecture depuis ${from.toFixed(2)} s, le tampon d'avant est gard\xE9`);
          for (const queue of [this.videoOps, this.audioOps]) {
            if (queue) await this.clearFrom(queue, from);
          }
          if (this.generation !== generation || this.destroyed) break;
          deepestSoFar = this.bufferedEnd();
          furthestLanes = this.laneProgress();
          fruitless = 0;
        }
        if (this.videoOps) {
          for (const fragment of segment.video) {
            await this.appendTo(this.videoOps, fragment, generation);
            if (this.generation !== generation || this.destroyed) break;
          }
        }
        if (segment.audio && this.audioOps) await this.appendTo(this.audioOps, segment.audio, generation);
        if (this.generation !== generation || this.destroyed) break;
        if (this.appendsSinceSeek > 0 && !reread) {
          const covered = segment.endSeconds - this.readUpTo;
          this.videoRate.record(segment.video.reduce((n, f) => n + f.byteLength, 0), covered);
          if (segment.audio) this.audioRate.record(segment.audio.byteLength, covered);
        }
        this.readUpTo = segment.endSeconds;
        if (this.remuxer.stoppedShort) this.joinKept();
        this.trimBehind();
        this.placePendingStart();
        this.guard.nudgeIntoBuffer();
        this.startHold?.check();
        this.lastAppendAt = Date.now();
        if (!this.openingSettled) {
          this.openingSettled = true;
          this.remuxer.openingSettled?.();
        }
        if (this.seekNetworkPending) {
          this.seekNetworkPending = false;
          this.remuxer.seekSettled?.();
          try {
            const network = this.remuxer.networkSinceSeek?.();
            if (network) trace(`r\xE9seau depuis le saut : ${describeNetwork(network)}`);
          } catch {
          }
        }
        const depth = this.bufferedEnd();
        if (++this.appendsSinceSeek <= TRACED_APPENDS_PER_SEEK) {
          trace(`apr\xE8s envoi : tampon jusqu'\xE0 ${depth.toFixed(1)} s, t\xEAte \xE0 ${this.video.currentTime.toFixed(1)} s`);
        }
        if (!this.startHold?.holding) this.guard.mediaArrived();
        const lanes = this.laneProgress();
        if (depth > deepestSoFar + 0.01 || lanes > furthestLanes + 0.01) {
          deepestSoFar = Math.max(deepestSoFar, depth);
          furthestLanes = Math.max(furthestLanes, lanes);
          fruitless = 0;
        } else if (segment.endSeconds + this.delaySeconds <= this.anchor && this.anchor - (segment.endSeconds + this.delaySeconds) <= PRE_ROLL_SECONDS) {
        } else if (++fruitless >= FRUITLESS_APPENDS) {
          throw new Error(
            `Le navigateur n'a rien retenu des ${FRUITLESS_APPENDS} segments qui lui ont \xE9t\xE9 envoy\xE9s. ${this.elementState()}`
          );
        }
        const approaching = this.video.seeking && segment.endSeconds + this.delaySeconds <= this.anchor && this.anchor - (segment.endSeconds + this.delaySeconds) <= PRE_ROLL_SECONDS;
        const distance = this.pendingStart !== null || approaching ? 0 : this.distanceToMedia(this.anchor);
        if (Number.isFinite(distance) && distance > MISPLACED_SECONDS) {
          trace(
            `reprise : m\xE9dia \xE0 ${distance.toFixed(1)} s de la t\xEAte (${this.anchor.toFixed(1)} s), lecteur \xE0 ${this.readUpTo.toFixed(1)} s \u2014 vid\xE9o ${spansNear(this.videoBuffer, this.anchor)} \xB7 audio ${this.audioBuffer ? spansNear(this.audioBuffer, this.anchor) : "aucun"}`
          );
          if (this.recover(this.seekState.intent?.target ?? this.anchor)) break;
        }
      }
    } catch (error) {
      if (this.destroyed) return;
      if (isUnreadableZone(error)) {
        if (this.generation === generation) this.zones.holdAtZone(error);
        return;
      }
      if (isReadAbandoned(error)) return;
      if (this.networkGaveUp) return;
      if (isNetworkFailure(error) && this.clock.lastPlayingAt > 0) {
        this.holdThroughOutage(generation, error);
        return;
      }
      if (isNetworkFailure(error) && this.keepThroughNetworkFailure(generation)) return;
      this.appendFailures += 1;
      if (this.appendFailures <= MAX_APPEND_FAILURES && this.recover(this.anchor)) {
        trace(`segment refus\xE9, repris \u2014 ${this.elementState()}`);
        return;
      }
      if (this.stuck) return;
      const detail = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
      this.callbacks.onError(`${detail} ${this.elementState()}`, isNetworkFailure(error) ? "network" : "playback");
    }
  }
  async appendTo(queue, data, generation) {
    if (this.destroyed || this.generation !== generation) return;
    try {
      const sentFrom = diagNow();
      await queue.enqueue(() => queue.buffer.appendBuffer(data));
      diagInterval("append", sentFrom, data.byteLength);
      const video = queue === this.videoOps;
      if (video) this.loss.rememberFragment(data);
      this.loss.rememberBuffered(video ? "envoi vid\xE9o" : "envoi audio");
      this.appendFailures = 0;
      this.networkRetries = 0;
      if (this.outageHold) {
        this.outageHold = false;
        trace("coupure r\xE9seau : le m\xE9dia arrive de nouveau");
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "QuotaExceededError") this.quotaHit();
      throw error;
    }
  }
  /**
   * Un retrait de ce lecteur, compté le temps qu'il dure — voir `onBufferedChange`.
   *
   * Compté dans l'opération elle-même, pas à la mise en file : un retrait qui attend derrière un
   * envoi ne doit pas couvrir une éviction faite *pendant* cet envoi, qui est justement le moment
   * où le navigateur fait de la place.
   */
  removeRange(queue, from, to) {
    const buffer = queue.buffer;
    let started = false;
    const removal = queue.enqueue(() => {
      started = true;
      this.ownRemovals.set(buffer, (this.ownRemovals.get(buffer) ?? 0) + 1);
      buffer.remove(from, to);
    });
    removal.then(
      () => this.loss.rememberBuffered("retrait"),
      () => {
      }
    );
    return removal.finally(() => {
      if (started) this.ownRemovals.set(buffer, Math.max(0, (this.ownRemovals.get(buffer) ?? 1) - 1));
    });
  }
  /**
   * Écoute ce que le navigateur retire de lui-même (24/09/2026).
   *
   * ManagedMediaSource — Safari, sur iPhone comme sur Mac — a le droit de retirer du média d'un
   * tampon quand la mémoire manque, et le dit par `bufferedchange` avec les plages retirées. Rien
   * ne l'écoutait : trois sauts ont trouvé leur cible vidée sans qu'on puisse dire si c'était le
   * système ou ce lecteur. Les MediaSource ordinaires n'ont pas cet événement, ni ce droit.
   */
  watchEvictions(buffer, lane) {
    if (!("onbufferedchange" in buffer)) return;
    const listener = (event) => this.onBufferedChange(buffer, lane, event);
    buffer.addEventListener("bufferedchange", listener);
    this.evictionListeners.push([buffer, listener]);
  }
  onBufferedChange(buffer, lane, event) {
    try {
      if (this.destroyed) return;
      const removed = event.removedRanges;
      if (!removed || removed.length === 0) return;
      if ((this.ownRemovals.get(buffer) ?? 0) > 0) return;
      const head = this.anchor;
      const spans = [];
      let aheadFrom = Infinity;
      for (let i = 0; i < removed.length; i++) {
        const start = removed.start(i);
        const end = removed.end(i);
        if (spans.length < 4) spans.push(`${start.toFixed(2)}\u2013${end.toFixed(2)}`);
        if (end > head + 0.1) aheadFrom = Math.min(aheadFrom, Math.max(start, head));
      }
      const ahead = Number.isFinite(aheadFrom);
      this.evictions += 1;
      if (ahead) this.evictionsAhead += 1;
      trace(
        `le navigateur a retir\xE9 ${lane} ${spans.join(" \xB7 ")} \u2014 t\xEAte \xE0 ${head.toFixed(1)} s` + (ahead ? `, devant elle d\xE8s ${aheadFrom.toFixed(1)} s` : "")
      );
      if (ahead) this.refillEvicted();
    } catch {
    }
  }
  /**
   * Relit tout de suite ce que le navigateur a retiré devant la tête.
   *
   * Sans cela, on le découvrait au pire moment : la tête arrivait sur le trou et s'arrêtait, ou un
   * saut « dans le chargé » tombait sur du vide — et le chien de garde reprenait après coup. Le
   * trou commence là où le média s'interrompt devant la tête ; le lecteur y est renvoyé, et la
   * suite est celle d'une coupure réseau gardée (`trimBeforeNextAppend`) : ce qui suit le trou est
   * retiré puis relu d'un seul tenant, et un groupe relu qui commencerait sous la tête devient une
   * reprise ordinaire.
   */
  refillEvicted() {
    if (this.evictionRefillQueued) return;
    const now = Date.now();
    this.evictionRefills = this.evictionRefills.filter((at) => now - at < 6e4);
    if (this.evictionRefills.length >= EVICTION_REFILLS_PER_MINUTE) {
      trace("retraits r\xE9p\xE9t\xE9s : la relecture est laiss\xE9e au remplissage ordinaire");
      return;
    }
    this.evictionRefills.push(now);
    this.evictionRefillQueued = true;
    const generation = this.generation;
    void (async () => {
      try {
        await this.fillTask?.catch(() => {
        });
      } finally {
        this.evictionRefillQueued = false;
      }
      if (this.destroyed || this.stuck || this.generation !== generation || this.networkHold) return;
      if (this.seekState.requested !== null || this.pendingStart !== null) return;
      const hole = this.bufferedEnd();
      if (hole >= this.readUpTo + this.delaySeconds - 0.5) return;
      if (hole <= this.video.currentTime + 0.1) {
        trace(`relecture de ce que le navigateur a retir\xE9 : sous la t\xEAte, \xE0 ${this.anchor.toFixed(1)} s`);
        if (!this.recover(this.anchor)) this.handOver(this.anchor);
        return;
      }
      trace(`relecture de ce que le navigateur a retir\xE9, depuis ${hole.toFixed(1)} s`);
      this.remuxer.seekTo(this.toFileClock(hole));
      this.readUpTo = this.toFileClock(hole);
      this.ended = false;
      this.trimBeforeNextAppend = true;
      void this.fill();
    })();
  }
  get budget() {
    return this.planner.budget;
  }
  get aheadTarget() {
    return this.planner.aheadTarget;
  }
  /**
   * Retire nous-mêmes ce qui est derrière la tête au-delà du budget, au lieu de laisser WebKit
   * choisir quoi jeter au milieu d'un envoi — souvent juste après un saut, pendant que la tête
   * se déplace. Pas pendant un saut : la tête n'y est pas encore à sa place.
   */
  //
  // Le son jusqu'à la limite exacte, lui : chacune de ses trames est une image clé, et rien de ce
  // qui précède la tête n'emporte celle qu'on entend. Borné comme l'image à l'image clé de la tête,
  // il gardait derrière lui tout un groupe — 28 s sur un film — dans un plafond de 5,5 Mo.
  trimBehind() {
    const budget = this.budget;
    if (!budget || this.seekState.pending || this.video.seeking) return;
    if (this.source.readyState === "closed") return;
    try {
      const wanted = this.video.currentTime - budget.behindSeconds;
      for (const queue of [this.videoOps, this.audioOps]) {
        const buffer = queue?.buffer;
        if (!queue || !buffer || buffer.buffered.length === 0) continue;
        const until = this.behindCut(queue, wanted, 0);
        if (until <= 0) continue;
        if (buffer.buffered.start(0) >= until - TRIM_SLACK_SECONDS) continue;
        void this.removeRange(queue, 0, until).catch(() => {
        });
      }
    } catch {
    }
  }
  /**
   * Un saut encore en cours quand la fin du flux est déclarée est relancé, au même endroit.
   *
   * Les films de Pixar de la bibliothèque finissent par ~30 s de son sans image (un film : image
   * jusqu'à 5904,8 s, son jusqu'à 5934,5 s ; un film : 5767,8 / 5798,5). Là, seule la fin du flux
   * rend la tête lisible : une MediaSource `ended` prolonge la dernière plage de chaque piste
   * jusqu'à la plus tardive, et la queue sans image entre dans les plages de l'élément. Un saut
   * demandé *après* la fin arrive en un instant ; un saut demandé *avant* — la dernière seconde,
   * depuis le début du film — restait `seeking` pour toujours sur Safari, `readyState` à 4, média
   * présent : WebKit ne réexamine pas un saut en cours quand les plages changent ainsi (28/09/2026,
   * iPhone). Le réaffecter relance l'algorithme ; la cible est alors dans les plages, et
   * `onSeeking` n'a rien à relire (`isBufferedAt`).
   */
  //
  // Seulement si la cible est dans les plages — le seul cas où relancer sert —, et comme un geste
  // de cette source (`expectOwnMove`) : `onSeeking` n'a alors rien à relire. Sans ces deux gardes,
  // une cible hors des plages relançait un saut, qui relisait jusqu'à la fin, qui relançait… en
  // boucle (relecture du 28/09/2026, prouvée par un test).
  reseekAfterEnd() {
    try {
      if (this.destroyed || !this.video.seeking) return;
      const target = this.video.currentTime;
      if (!this.isBufferedAt(target)) return;
      trace(`fin du flux d\xE9clar\xE9e pendant un saut vers ${target.toFixed(1)} s \u2014 saut relanc\xE9 sur place`);
      this.seekState.expectOwnMove(target);
      this.video.currentTime = target;
    } catch {
    }
  }
  /** Declares the stream over, if it still can be. Never throws. */
  endStream() {
    try {
      if (this.source.readyState === "open") this.source.endOfStream();
    } catch {
    }
  }
  /**
   * The browser has taken all it will hold.
   *
   * Two things follow, and only the first of them was being done. Media behind the playhead is
   * dropped, which frees room — *unless* the playhead has not travelled far enough for there to
   * be any, which in the first half-minute of a film is always. In that case every segment sent
   * is refused and silently dropped, and after eight of them the fill loop concludes the browser
   * is keeping nothing at all and hands the film away. The cause and the diagnosis would have
   * had nothing to do with each other.
   *
   * So the target comes down instead, to a little less than what is actually being held. That is
   * measured rather than guessed, it costs nothing on a browser that never refuses anything —
   * which is every browser tested here — and it lasts only as long as this MediaSource.
   */
  quotaHit() {
    const held = this.lead;
    this.evict();
    if (held < 1) {
      trace(`tampon plein \xE0 ${held.toFixed(1)} s devant la t\xEAte : cible gard\xE9e \xE0 ${this.targetBuffer} s`);
      return;
    }
    const room = Math.max(MIN_BUFFER_SECONDS, Math.floor(held * 0.75));
    if (room < this.targetBuffer) {
      trace(`tampon plein \xE0 ${held.toFixed(1)} s : on vise ${room} s pour ce fichier`);
      this.targetBuffer = room;
    }
  }
  /**
   * Jusqu'où retirer derrière la tête sans lui retirer son image.
   *
   * La norme MSE prolonge un `remove(0, until)` jusqu'à l'image clé qui suit `until` : si la tête
   * est dans le même groupe d'images, tout ce groupe part avec, l'image sous la tête comprise —
   * `buffered` passait de 0–30 à 20–30 pour un retrait jusqu'à 11,5 s, tête à 16 s, dans Chromium,
   * Firefox et WebKit (banc du 25/09/2026). Avec des groupes de 28 s (un film) ou 52 s
   * (un film) et un budget de quelques secondes derrière, chaque envoi recoupait le groupe en cours :
   * arrêts, relectures, puis saut à l'image clé suivante. Le retrait s'arrête donc un peu avant
   * l'image clé qui ouvre le groupe de la tête ; l'image clé suivante de `until` est alors celle-là.
   * Sans index, on ne sait pas où elle est : `unknown`.
   */
  behindLimit(until, unknown) {
    if (until <= 0) return until;
    try {
      if (!this.remuxer.seekable) return unknown;
      const file = this.remuxer.keyframeAtOrBefore(this.toFileClock(this.video.currentTime));
      if (file === null) return 0;
      return Math.min(until, file + this.delaySeconds - KEYFRAME_TRIM_MARGIN);
    } catch {
      return unknown;
    }
  }
  /**
   * Jusqu'où retirer derrière la tête dans ce tampon — la règle commune à `trimBehind` et `evict`.
   *
   * Le son jusqu'à `wanted` exactement, chacune de ses trames étant une image clé ; l'image jusqu'à
   * l'image clé de la tête (`behindLimit`), ou `unknown` sans index. `evict` bornait les deux
   * tampons à celle de l'image, que `trimBehind` avait quittée pour le son le 01/10/2026 : sur un
   * refus de quota, le son gardait derrière lui tout le groupe de la tête, et rien n'en partait
   * quand l'image n'avait rien à céder (borne ≤ 0) — `quotaHit` mesurait ensuite sa nouvelle cible
   * sur un tampon encombré de son inutile (audit du 22/10/2026).
   */
  behindCut(queue, wanted, unknown) {
    return queue === this.audioOps ? wanted : this.behindLimit(wanted, unknown);
  }
  evict() {
    const wanted = this.video.currentTime - (this.budget?.behindSeconds ?? KEEP_BEHIND_SECONDS);
    const cuts = [this.videoOps, this.audioOps].flatMap((queue) => queue ? [{ queue, until: this.behindCut(queue, wanted, wanted) }] : []);
    const said = cuts.filter(({ until }) => until > 0).map(({ queue, until }) => `${queue === this.audioOps ? "son" : "image"} jusqu'\xE0 ${until.toFixed(1)} s`);
    trace(`\xE9viction demand\xE9e \xE0 ${this.video.currentTime.toFixed(1)} s \u2014 ${said.length === 0 ? "rien derri\xE8re la t\xEAte" : said.join(", ")}`);
    for (const { queue, until } of cuts) {
      const buffer = queue.buffer;
      if (until <= 0 || !buffer || buffer.buffered.length === 0 || buffer.buffered.start(0) >= until) continue;
      void this.removeRange(queue, 0, until).catch(() => {
      });
    }
  }
  /**
   * Moves playback to a point on the *player's* clock. The remuxer works on the file's clock, so
   * the presentation delay is taken off here and nowhere else.
   */
  seek(playerSeconds, because = "le viseur") {
    trace(`saut demand\xE9 vers ${playerSeconds.toFixed(1)} s (${because}) \u2014 t\xEAte \xE0 ${this.video.currentTime.toFixed(1)} s`);
    this.seekState.request(playerSeconds);
    if (this.remuxer.seekable) {
      try {
        this.remuxer.prepareSeek?.(this.toFileClock(playerSeconds));
      } catch {
      }
    }
    this.pending = this.pending.then(() => {
      const target = this.seekState.requested;
      if (target === null || this.destroyed) return;
      return this.performSeek(target);
    }).catch((error) => {
      if (this.destroyed) return;
      this.appendFailures += 1;
      const detail = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
      if (this.appendFailures <= MAX_APPEND_FAILURES && this.recover(this.anchor)) {
        trace(`saut refus\xE9, repris \u2014 ${detail}`);
        return;
      }
      if (this.stuck) return;
      this.callbacks.onError(`${detail} ${this.elementState()}`, isNetworkFailure(error) ? "network" : "playback");
    });
    return this.pending;
  }
  async performSeek(requested) {
    if (this.destroyed) return;
    this.pendingStart = null;
    const end = this.playerEnd;
    const playerSeconds = Math.min(Math.max(0, requested), Math.max(0, end - 0.25));
    if (!reachable(this.remuxer.seekable, playerSeconds)) {
      this.callbacks.onWarning?.(playerWarning("noIndexSeek"));
      this.seekState.served(requested);
      this.seekState.drop();
      this.seekState.moved(this.lastPlayedAt);
      this.video.currentTime = this.lastPlayedAt;
      return;
    }
    if (this.zones.zone) {
      const zone = this.zones.zone;
      if (playerSeconds >= zone.switchAt && (zone.resumeAfter === null || playerSeconds < zone.resumeAfter)) {
        this.seekState.served(requested);
        this.seekState.drop();
        this.zones.arriveAtZone(playerSeconds, "saut dans la zone");
        return;
      }
      this.zones.zone = null;
      trace(`zone illisible quitt\xE9e par un saut vers ${playerSeconds.toFixed(1)} s`);
      this.zones.notifyZone({ kind: "left", zone, target: playerSeconds });
    }
    if (this.zones.zoneHanded) return;
    this.generation += 1;
    this.ended = false;
    this.seekState.serving(playerSeconds);
    this.readUpTo = this.toFileClock(playerSeconds);
    this.seeksServed += 1;
    this.lastAppendAt = Date.now();
    await this.fillTask?.catch(() => {
    });
    if (this.destroyed) return;
    const latest = this.seekState.requested;
    if (latest !== null && latest !== requested) return this.performSeek(latest);
    const kept = this.keptAfter(playerSeconds);
    this.lastServed = {
      target: requested,
      path: kept ? "devant" : "complet",
      keptS: kept ? Math.round((Math.min(kept.end, kept.keepUntil) - kept.start) * 10) / 10 : null
    };
    if (kept) {
      if (kept.end > kept.keepUntil) {
        await Promise.all([this.videoOps, this.audioOps].map((queue) => queue ? this.clearFrom(queue, kept.keepUntil) : null));
        if (this.destroyed) return;
      }
      try {
        trace(
          `ajout devant : la cible est \xE0 ${(kept.start - playerSeconds).toFixed(2)} s du charg\xE9, gard\xE9 \u2014 reste vid\xE9o ${spansAll(this.videoBuffer)} \xB7 audio ${spansAll(this.audioBuffer)} ; lecture de l'image cl\xE9 d'avant la cible jusqu'\xE0 ce d\xE9but`
        );
      } catch {
      }
      this.fragmentsSinceSeek = 0;
    } else {
      const clearFrom = Date.now();
      const clearMs = (await Promise.all(
        [this.videoOps, this.audioOps].map(async (queue) => {
          if (!queue) return null;
          await this.clear(queue);
          return `${queue === this.videoOps ? "vid\xE9o" : "audio"} ${Date.now() - clearFrom} ms`;
        })
      )).filter((entry) => entry !== null);
      if (this.destroyed) return;
      try {
        trace(
          `vidage fait (${clearMs.join(", ")}) \u2014 reste vid\xE9o ${spansAll(this.videoBuffer)} \xB7 audio ${spansAll(this.audioBuffer)}`
        );
      } catch {
      }
      this.sentFragments = [];
      this.fragmentsSinceSeek = 0;
    }
    const newer = this.seekState.requested;
    if (newer !== null && newer !== requested) return this.performSeek(newer);
    if (!kept) this.guard.seekServed(playerSeconds);
    this.trimBeforeNextAppend = false;
    this.networkHold = false;
    if (kept) this.remuxer.seekTo(this.toFileClock(playerSeconds), this.toFileClock(kept.start) + PREPEND_STOP_MARGIN_S);
    else this.remuxer.seekTo(this.toFileClock(playerSeconds));
    this.seekNetworkPending = true;
    this.appendsSinceSeek = 0;
    if (Math.abs(this.video.currentTime - playerSeconds) > 0.05) {
      this.seekState.expectOwnMove(playerSeconds);
      this.video.currentTime = playerSeconds;
    }
    this.seekState.served(requested);
    void this.fill();
  }
  /**
   * Le chargé qu'un saut vers `target` peut garder : la plage jouable qui commence après la cible, à
   * au plus `PREPEND_SHARE_OF_AHEAD` de l'avance visée — ou null, et le saut vide tout comme avant.
   * `keepUntil` : jusqu'où la garder, l'avance d'un saut ordinaire depuis la cible.
   */
  keptAfter(target) {
    const ranges = this.playable;
    if (rangeAround(ranges, target, 0) >= 0) return null;
    let start = Infinity;
    let end = 0;
    for (let i = 0; i < ranges.length; i++) {
      if (ranges.start(i) > target && ranges.start(i) < start) {
        start = ranges.start(i);
        end = ranges.end(i);
      }
    }
    if (!Number.isFinite(start)) return null;
    const ahead = this.aheadTarget;
    if (start - target > ahead * PREPEND_SHARE_OF_AHEAD) return null;
    return { start, end, keepUntil: target + ahead };
  }
  /**
   * L'ajout devant est arrivé à sa borne : ce qu'il a lu rejoint le chargé gardé, et la lecture
   * reprend au bout de celui-ci — comme après une éviction (`refillEvicted`) : le groupe qui contient
   * ce bout est retiré puis relu d'un seul tenant (`trimBeforeNextAppend`).
   *
   * Si le raccord n'a pas pris (un trou subsiste), le bout est celui de l'ajout, et cette même
   * relecture retire le chargé gardé pour le relire : le saut ordinaire, en un peu plus long. Et si
   * la tête n'est encore sur rien, le groupe relu commence sous elle : la reprise habituelle.
   */
  joinKept() {
    const join = this.bufferedEnd();
    trace(
      `ajout devant fait : vid\xE9o ${spansNear(this.videoBuffer, this.anchor)} \xB7 audio ${this.audioBuffer ? spansNear(this.audioBuffer, this.anchor) : "aucun"} \u2014 lecture reprise \xE0 ${join.toFixed(1)} s`
    );
    this.guard.seekServed(this.video.currentTime);
    this.remuxer.seekTo(this.toFileClock(join));
    this.readUpTo = this.toFileClock(join);
    this.trimBeforeNextAppend = true;
  }
  /**
   * Pose la tête de lecture à l'ouverture — une fois le média arrivé, jamais avant.
   *
   * C'est la moitié différée de l'ouverture à une position non nulle. Le remultiplexeur a été
   * envoyé au bon endroit dès le départ ; il ne restait qu'à attendre que ce qu'il rapporte soit
   * réellement sous la tête avant de l'y déplacer. Un `currentTime` posé sur un tampon vide est
   * une demande que WebKit accepte et n'honore jamais.
   *
   * Deux façons d'être arrivé, et la seconde compte autant que la première : la plage peut
   * contenir la cible, ou commencer juste après elle — un fichier à images B présente sa première
   * image 210 ms plus tard, et une ouverture qui tomberait dans cet intervalle attendrait un
   * instant que le fichier ne contient pas. On se pose alors au début de la plage, comme le fait
   * déjà l'atterrissage après un saut.
   */
  placePendingStart() {
    const target = this.pendingStart;
    if (target === null) return;
    const landing = landingFor(this.video.buffered, target, LANDING_REACH_SECONDS);
    if (landing === null) return;
    this.pendingStart = null;
    trace(
      landing === target ? `ouverture : le m\xE9dia couvre ${landing.toFixed(1)} s, la t\xEAte y est pos\xE9e` : `ouverture : le m\xE9dia commence apr\xE8s ${target.toFixed(1)} s, la t\xEAte est pos\xE9e \xE0 ${landing.toFixed(2)} s`
    );
    this.seekState.moved(landing);
    this.guard.headPlaced(landing);
    this.video.currentTime = landing;
    this.guard.opened(landing, !this.startPaused);
    this.armOpeningReassert(landing);
  }
  /** Retire d'un tampon tout ce qui suit cet instant — voir `trimBeforeNextAppend`. */
  async clearFrom(queue, from) {
    if (queue.buffer.buffered.length === 0 || this.source.readyState === "closed") return;
    const end = Number.isFinite(this.source.duration) ? this.source.duration + 1 : 1e9;
    if (from >= end) return;
    await this.removeRange(queue, Math.max(0, from), end).catch(() => {
    });
  }
  /**
   * Une lecture réseau a échoué, nouvelles tentatives comprises : garder le tampon et réessayer.
   *
   * La reprise habituelle passe par un saut, qui vide les deux tampons. Pendant un redéploiement
   * du serveur — plusieurs par jour, deux ou trois secondes de réponses refusées — c'était jusqu'à
   * trente secondes d'image jetées et un chargement à l'écran, alors que le film avait de quoi
   * tenir (relu le 24/09/2026). Tant qu'il reste une avance confortable, la lecture reprend donc
   * plus tard, là où elle s'était arrêtée, sans rien toucher à ce qui est déjà là.
   *
   * Prudente à dessein : au-dessous de `NETWORK_KEEP_LEAD_SECONDS`, après quatre essais, ou si un
   * saut est passé entre-temps, rien de tout cela — la reprise habituelle, comme avant. Et le
   * chien de garde reste là : si l'avance s'épuise pendant l'attente, il reprend à sa façon.
   */
  keepThroughNetworkFailure(generation) {
    if (this.destroyed || this.stuck) return false;
    if (this.lead < NETWORK_KEEP_LEAD_SECONDS) return false;
    if (this.networkRetries >= NETWORK_RETRY_DELAYS_MS.length) return false;
    const delay = NETWORK_RETRY_DELAYS_MS[this.networkRetries];
    this.networkRetries += 1;
    trace(`coupure r\xE9seau avec ${this.lead.toFixed(1)} s d'avance : tampon gard\xE9, nouvel essai dans ${delay / 1e3} s`);
    this.retryReadLater(generation, delay);
    return true;
  }
  /**
   * Une coupure en pleine lecture (DECISIONS.md §97), une fois que ce pipeline a joué : le tampon est
   * gardé quelle que soit l'avance, et la lecture retentée sans compter (1, 2, 4, 8 s, puis toutes les
   * 8 s ; tout de suite à `online`). Ce n'est plus l'échelle des envois refusés : la reprise y vidait
   * les tampons pour relire la même plage, sur le même réseau absent, et chaque essai relançait la
   * patience d'une minute de la lecture. La borne est le temps, pas le nombre d'essais :
   * `watchForOutage`, à la tête à court de média. Le réseau revenu avant elle, la lecture reprend là
   * où elle s'était arrêtée, sans reconstruction.
   */
  holdThroughOutage(generation, error) {
    if (this.destroyed || this.stuck || this.networkGaveUp) return;
    const delay = NETWORK_RETRY_DELAYS_MS[Math.min(this.networkRetries, NETWORK_RETRY_DELAYS_MS.length - 1)];
    this.networkRetries += 1;
    this.outageHold = true;
    const detail = error instanceof Error ? error.message : String(error);
    trace(`coupure r\xE9seau (${detail.slice(0, 80)}), ${this.lead.toFixed(1)} s d'avance : tampon gard\xE9, essai n\xB0${this.networkRetries} dans ${delay / 1e3} s`);
    this.retryReadLater(generation, delay);
  }
  /** Relit plus tard là où la lecture s'était arrêtée, le tampon gardé — voir `trimBeforeNextAppend`. */
  retryReadLater(generation, delay) {
    this.networkHold = true;
    if (this.networkRetryTimer) clearTimeout(this.networkRetryTimer);
    this.networkRetryGeneration = generation;
    this.networkRetryTimer = setTimeout(() => this.retryReadNow(generation), delay);
  }
  retryReadNow(generation) {
    if (this.networkRetryTimer) clearTimeout(this.networkRetryTimer);
    this.networkRetryTimer = null;
    if (this.destroyed || this.generation !== generation || this.networkGaveUp) return;
    this.networkHold = false;
    this.remuxer.seekTo(this.readUpTo);
    this.trimBeforeNextAppend = true;
    void this.fill();
  }
  /** Le réseau revient pendant qu'une coupure attend son prochain essai : il part tout de suite. */
  onOnline = () => {
    if (!this.outageHold || !this.networkHold || this.networkRetryTimer === null) return;
    trace("coupure r\xE9seau : le navigateur est de nouveau en ligne, nouvel essai tout de suite");
    this.retryReadNow(this.networkRetryGeneration);
  };
  /**
   * La borne d'une coupure en pleine lecture (DECISIONS.md §97), au chien de garde : ce pipeline a
   * joué, le spectateur veut jouer (ni pause ni fin, page visible), la tête est à court de média, et
   * le réseau n'a rien livré depuis `NETWORK_OUTAGE_GIVE_UP_MS` sous une demande. Alors la main passe
   * à l'hôte (`onError(…, "network")`) : l'écran « connexion perdue », la ligne `network`, et le
   * nouvel essai de l'hôte au retour du réseau. Un lien lent livre ses morceaux : jamais ici.
   */
  watchForOutage() {
    if (this.networkGaveUp || this.stuck || this.destroyed || this.ended || this.clock.lastPlayingAt === 0) return;
    if (this.video.paused) return;
    if (typeof document !== "undefined" && document.visibilityState === "hidden") return;
    const starved = this.lead < OUTAGE_STARVED_LEAD_SECONDS || typeof this.video.readyState === "number" && this.video.readyState < 3;
    if (!starved) return;
    const silent = this.networkSilentMs();
    if (silent < NETWORK_OUTAGE_GIVE_UP_MS) return;
    this.networkGaveUp = true;
    this.networkHold = false;
    this.outageHold = false;
    if (this.networkRetryTimer) clearTimeout(this.networkRetryTimer);
    this.networkRetryTimer = null;
    const why = `coupure r\xE9seau : aucun octet re\xE7u depuis ${Math.round(silent / 1e3)} s`;
    trace(`${why} \u2014 la main passe \xE0 l'h\xF4te`);
    this.callbacks.onError(`${why} ${this.elementState()}`, "network");
  }
  networkSilentMs() {
    try {
      return this.remuxer.networkSilentMs?.() ?? 0;
    } catch {
      return 0;
    }
  }
  async clear(queue) {
    if (queue.buffer.buffered.length === 0 || this.source.readyState === "closed") return;
    const end = Number.isFinite(this.source.duration) ? this.source.duration + 1 : 1e9;
    await this.removeRange(queue, 0, end).catch(() => {
    });
  }
  /**
   * Arrivé : la tête est où le saut voulait qu'elle soit, et le saut n'est plus surveillé. Un
   * `seeked` loin de la cible, lui, ne vaut pas arrivée — voir `watchForHeadAway`.
   *
   * Il y avait ici, du 22/09/2026 au soir, une horloge arrêtée pendant les sauts sous WebKit
   * (vitesse 0, rendue à l'arrivée). Retirée après deux bancs iPhone : Safari a replacé une tête à
   * son ancienne position l'horloge arrêtée comme sans elle — c'est le filet qui l'a rattrapée les
   * deux fois —, elle rendait muettes l'horloge figée et les blocages, et Safari ne signale aucune
   * image à vitesse 0, si bien qu'on ne pouvait pas non plus l'attendre.
   */
  onSeeked = () => {
    if (this.destroyed) return;
    this.clock.settleOpeningReassert();
    this.seekState.arrive(this.video.currentTime);
  };
  /**
   * The safety net, and the only part of this that does not depend on being told anything.
   *
   * Everything else here reacts to an event: the element announcing a seek, the system asking
   * for data, a buffer reporting an append. Each of those can fail to arrive — a browser that
   * does not fire seeking in some state, a system that stops asking and never starts again, an
   * append quietly rejected — and the symptom is always identical and always the same fault:
   * the playhead is somewhere no media is, and the reader is filling somewhere else.
   *
   * So rather than trying to enumerate the causes, this watches the one fact that matters and
   * seeks to wherever the viewer actually is. It is checked on a timer precisely because the
   * failure mode is that no event comes.
   */
  watchdog = () => {
    if (this.destroyed) return;
    if (this.zones.zoneHanded || this.zones.zone && this.zones.checkZoneArrival()) return;
    if (!this.video.seeking && this.seekState.intent === null) this.lastPlayedAt = this.video.currentTime;
    this.watchForStall();
    this.watchForOutage();
    if (this.networkGaveUp) return;
    if (this.stuck) return;
    if (this.ended || !this.videoBuffer || this.video.paused) return;
    const now = this.video.currentTime;
    if (this.headAwayHandledAt === now) return;
    if (this.seekState.requested !== null) return;
    if (this.pendingStart !== null) return;
    if (this.isBufferedAt(now)) return this.watchForFrozenClock(now);
    if (this.fillTask) return;
    if (this.outageHold) return;
    if (Date.now() - this.lastAppendAt < STALL_TIMEOUT_MS) return;
    trace(
      `reprise : rien sous la t\xEAte \xE0 ${now.toFixed(1)} s, dernier envoi il y a ${Date.now() - this.lastAppendAt} ms, ${this.elementState()}`
    );
    if (!this.recover(now)) this.handOver(now);
  };
  /**
   * Notes whether the clock is really running, and writes a stall to the log when it is not.
   *
   * 22/09/2026 : a −10 s skip on an iPhone landed just before a keyframe, `seeked` fired, and the
   * clock then sat between 166 and 167 s for nineteen seconds under a spinner, until the viewer
   * seeked elsewhere. The log held the `seek` line and nothing after it: which recovery ran, what
   * the buffers held, whether anything was being read — all of it stayed on the phone.
   *
   * "Stood still" is measured as covering less than a second in `STALL_REPORT_MS`, not as an
   * unchanged value: the pushes and recoveries move the clock by fractions of a second, and a
   * stall they fail to cure must not read as playback.
   */
  watchForStall() {
    const now = this.video.currentTime;
    const running = !this.video.paused && !this.video.ended;
    const delta = now - this.tickClockAt;
    this.tickClockAt = now;
    if (running && !this.video.seeking && delta > 0 && delta < 0.6 && this.isBufferedAt(now)) {
      this.ladder.playedSinceTrouble += delta;
      if (this.ladder.playedSinceTrouble >= PLAYED_TO_CLEAR_SECONDS) {
        this.ladder.escalation = 0;
        this.ladder.unplayedAttempts = 0;
      }
    }
    if (!running) {
      this.stallSince = null;
      return;
    }
    if (!this.stuck && this.watchForHeadAway(now, delta)) {
      this.stallSince = null;
      this.headAwayHandledAt = now;
      return;
    }
    if (this.video.seeking && !this.isBufferedAt(now)) {
      this.stallSince = null;
      return;
    }
    if (this.pendingStart !== null && !this.isBufferedAt(this.pendingStart)) {
      this.stallSince = null;
      return;
    }
    if (this.stallSince === null || Math.abs(now - this.stallClockAt) >= 1) {
      this.stallClockAt = now;
      this.stallSince = Date.now();
      this.stallReported = false;
      return;
    }
    const stalledMs = Date.now() - this.stallSince;
    if (stalledMs < STALL_REPORT_MS || this.stallReported) return;
    this.stallReported = true;
    if (Date.now() - this.lastStallReportAt < STALL_REPORT_COOLDOWN_MS) return;
    this.lastStallReportAt = Date.now();
    trace(`lecture bloqu\xE9e depuis ${(stalledMs / 1e3).toFixed(1)} s \xE0 ${now.toFixed(2)} s \u2014 ${this.elementState()}`);
    try {
      this.callbacks.onStall?.(this.stallReport(now, stalledMs));
    } catch {
    }
  }
  /**
   * La tête hors de sa place — un seul détecteur pour les deux formes qu'on lui a connues.
   *
   * - **Pendant un saut** : elle s'éloigne de sa cible sans y être arrivée. Banc iPhone du
   *   22/09/2026 : trois sauts sur huit films partis de 20 à 650 s au-delà de leur cible, et un
   *   Un film ramené par Safari à son ancienne position. L'élément se disait en train de sauter, ce
   *   qui rendait aveugles toutes les autres surveillances. Renvoyée vers sa **cible**.
   * - **Après** : l'horloge avance trois secondes sans rien sous la tête (2012 sur iPhone : 658
   *   images pour 55 s regardées, la tête posée à chaque envoi sur la fin de la vidéo reçue). Aucune
   *   cible à retrouver : reprise là où elle est, ce qui relit depuis l'image clé.
   *
   * Deux détecteurs jusqu'au 22/09/2026, qui écrivaient chacun leur ligne et appelaient chacun les
   * reprises ; un seul désormais, pour un seul fait. Par l'échelle habituelle des reprises, écrit
   * comme un blocage (`runaway`), une ligne par minute au plus.
   */
  watchForHeadAway(now, delta) {
    const intent = this.seekState.intent;
    if (intent) {
      if (this.seekState.requested !== null || seekArrived(now, intent.target)) return false;
      if (this.video.seeking && Date.now() - intent.since < FROZEN_SEEKING_MS) return false;
      this.seekState.drop();
      this.headAway(`saut parti ailleurs : vis\xE9 ${intent.target.toFixed(1)} s, t\xEAte \xE0 ${now.toFixed(1)} s \u2014 on y retourne`, now, intent.target, {
        seekTarget: intent.target,
        stalledMs: Date.now() - intent.since
      });
      return true;
    }
    if (this.pendingStart !== null || this.video.seeking || this.isBufferedAt(now)) {
      this.runawaySeconds = 0;
      return false;
    }
    if (delta <= 0 || delta > 5) return false;
    const before = this.runawaySeconds;
    this.runawaySeconds += delta;
    if (before >= RUNAWAY_REPORT_SECONDS || this.runawaySeconds < RUNAWAY_REPORT_SECONDS) return false;
    this.headAway(`horloge qui avance sans m\xE9dia : ${this.runawaySeconds.toFixed(1)} s courues jusqu'\xE0 ${now.toFixed(2)} s`, now, now, { stalledMs: 0 });
    return true;
  }
  /** Écrit, puis renvoie la tête par l'échelle des reprises. */
  headAway(what, now, target, facts) {
    trace(`${what} \u2014 ${this.elementState()}`);
    if (Date.now() - this.lastStallReportAt >= STALL_REPORT_COOLDOWN_MS) {
      this.lastStallReportAt = Date.now();
      try {
        const { stalledMs, ...rest } = facts;
        this.callbacks.onStall?.({ runaway: true, ...rest, ...this.stallReport(now, stalledMs) });
      } catch {
      }
    }
    if (!this.recover(target)) this.handOver(target);
  }
  /**
   * What a stall line carries: one level deep and short, for `clean()` in playerLog.ts, which keeps
   * 40 fields — and 40 more for `diag.*`, the supply diagnosis (playbackDiagnosis.ts).
   */
  stallReport(now, stalledMs) {
    const managed = this.source.streaming;
    const { position, ...state } = this.stateFacts(now);
    return {
      position,
      stalledMs,
      ...state,
      filling: this.fillTask !== null,
      recoveryStreak: this.ladder.recoveryStreak,
      frozenNudges: this.clock.frozenNudges,
      recoveries: this.ladder.recoveries,
      evictions: this.evictions,
      // Only ManagedMediaSource has the signal; plain MediaSource says so rather than `true`.
      streaming: typeof managed === "boolean" ? managed : "sans objet",
      // Le réseau à cet instant, et où en est la relance (15/10/2026, LECTEUR-4) : trois coupures
      // en pleine lecture n'avaient laissé ni ligne `network` ni rien qui dise si l'appareil se
      // savait hors ligne, si des tentatives échouaient, ni ce que la source faisait en attendant.
      ...this.networkFacts(),
      // Ce qui a retenu la chaîne dans les 30 s d'avant : réseau, calcul ou décodeur — voir
      // playbackDiagnosis.ts. Aplati en `diag.*`, sous son propre plafond de champs.
      diag: diagStallFacts(this.lead),
      steps: traceRecent(STALL_TRACE_MS).join(" | ")
    };
  }
  /**
   * Le réseau vu d'ici, pour la ligne `stall` : ce que dit le navigateur (`onLine`, absent s'il ne
   * dit rien), des tentatives en échec ou l'appareil hors ligne (`netTrouble`, `networkTrouble.ts`),
   * et la relance en une chaîne courte (`relaunch`) — la réserve réseau (`keepThroughNetworkFailure` :
   * essais faits sur le maximum, « en attente » si un nouvel essai est programmé) et les échecs de
   * suite comptés avant l'écran. Ne lève jamais : c'est le chemin d'un blocage.
   */
  networkFacts() {
    try {
      const onLine = typeof navigator !== "undefined" && typeof navigator.onLine === "boolean" ? navigator.onLine : void 0;
      return {
        ...onLine === void 0 ? {} : { onLine },
        netTrouble: networkUnstable(),
        relaunch: `garde ${this.networkRetries}/${NETWORK_RETRY_DELAYS_MS.length}${this.networkHold ? " en attente" : ""} \xB7 \xE9checs ${this.appendFailures}/${MAX_APPEND_FAILURES}` + (this.outageHold ? ` \xB7 coupure, silence ${Math.round(this.networkSilentMs() / 1e3)} s` : "")
      };
    } catch {
      return {};
    }
  }
  /** L'élément et ses tampons, en peu de champs — commun au blocage et à la perte. */
  stateFacts(now) {
    return {
      position: now,
      readyState: this.video.readyState,
      networkState: this.video.networkState,
      seeking: this.video.seeking,
      source: this.source.readyState,
      videoBuffered: spansNear(this.videoBuffer, now),
      audioBuffered: this.audioBuffer ? spansNear(this.audioBuffer, now) : "aucun",
      lead: Math.round(this.lead * 100) / 100,
      sinceAppendMs: Date.now() - this.lastAppendAt
    };
  }
  /** Voir `FrozenClockWatch.armOpeningReassert`. */
  armOpeningReassert(at) {
    this.clock.armOpeningReassert(at);
  }
  /** Voir `FrozenClockWatch.watchForFrozenClock`. */
  watchForFrozenClock(now) {
    this.clock.watchForFrozenClock(now);
  }
  /**
   * Voir `RecoveryLadder.recover`. Tout passe par ici, par `this.` : webcodecs-mseSource.test.ts
   * remplace cette méthode sur l'instance.
   */
  recover(target) {
    return this.ladder.recover(target);
  }
  /**
   * The last rung: this source has nothing left to try, and says so the way a lost source does.
   *
   * Through `onError` and `lost`, the host's existing answer to a source it must build again — not
   * a parallel mechanism: its budget (three in three minutes) and its step past a place that has
   * already failed twice apply unchanged, and past that budget it hands the film to the stable
   * player. Once only; the watchdog stands down behind `stuck`.
   */
  handOver(at) {
    if (this.stuck || this.destroyed) return;
    this.stuck = true;
    this.handedOverAt = at;
    this.ladder.escalation = 2;
    this.ladder.escalations += 1;
    trace(`reprise impossible ici \xE0 ${at.toFixed(1)} s \u2014 reconstruction demand\xE9e ${this.elementState()}`);
    this.callbacks.onError(
      `lecture bloqu\xE9e \xE0 ${at.toFixed(1)} s apr\xE8s ${this.ladder.recoveries} reprises ${this.elementState()}`,
      "playback"
    );
  }
  /**
   * Un saut en cours, selon la source : demandé et pas encore servi, ou servi et pas encore arrivé.
   * L'hôte le lit pour savoir quand oublier la cible qu'il a demandée — la source peut l'avoir
   * posée ailleurs (premier média, image clé suivante), et c'est elle qui sait si c'est fini.
   */
  get seekPending() {
    return this.seekState.pending;
  }
  /** What the `stop` line wants to know of the recoveries over the whole session. */
  get recoveryFacts() {
    return {
      recoveries: this.ladder.recoveries,
      frozenNudges: this.clock.frozenNudgesTotal,
      escalations: this.ladder.escalations,
      evictions: this.evictions,
      evictionsAhead: this.evictionsAhead
    };
  }
  /**
   * What the element and the source have to say — the two things that know why an append was
   * refused, when the event itself carries nothing.
   */
  elementState() {
    const parts = [`MediaSource ${this.source.readyState}`];
    const failure = this.video.error;
    if (failure) parts.push(`\xE9l\xE9ment code ${failure.code}${failure.message ? ` \xAB ${failure.message} \xBB` : ""}`);
    parts.push(`readyState ${this.video.readyState}`, `r\xE9seau ${this.video.networkState}`);
    return `(${parts.join(", ")})`;
  }
  /**
   * Whether the platform has taken the source away.
   *
   * iOS reclaims media resources when a page goes to the background, and a MediaSource it has
   * closed cannot be reopened — every buffer on it is gone with it. There is nothing to repair
   * here; the caller has to build the whole thing again.
   */
  get lost() {
    return !this.destroyed && (this.stuck || this.source.readyState === "closed");
  }
  /**
   * Where the viewer was, for a caller that has to rebuild and wants to come back to it.
   *
   * Où le film en est — et, une fois la main passée à l'hôte, où il doit reprendre : la position
   * donnée à `handOver`, qui peut être la cible d'un saut parti ailleurs plutôt que la tête.
   */
  get position() {
    return this.stuck && this.handedOverAt !== null ? this.handedOverAt : this.video.currentTime;
  }
  /**
   * L'espace colorimétrique d'une image telle que l'élément la rend, demandé une seule fois.
   *
   * Purement informatif : rien ici n'agit dessus. La réponse dit si les vraies valeurs HDR ont
   * survécu au décodage matériel — `bt2020 · pq` — ou si le navigateur a déjà converti l'image
   * avant qu'on puisse la voir, auquel cas elle revient en RGB 8 bits. C'est la seule mesure qui
   * distingue les deux, et un relevé qui la porte évite d'avoir à refaire la démonstration.
   *
   * Une seule fois, et le résultat gardé : construire une image 4K à chaque rafraîchissement du
   * panneau pour lire trois champs coûterait bien plus que ce qu'elle apprend.
   */
  colorProbe = null;
  frameColorSpace() {
    if (this.colorProbe) return this.colorProbe;
    const Frame = globalThis.VideoFrame;
    if (!Frame || this.video.readyState < 2) return "pas encore lisible";
    let frame = null;
    try {
      frame = new Frame(this.video);
      const space = frame.colorSpace;
      this.colorProbe = `${space.primaries ?? "?"} \xB7 ${space.transfer ?? "?"} \xB7 ${space.matrix ?? "?"} \xB7 ${frame.format ?? "format non d\xE9clar\xE9"}`;
      return this.colorProbe;
    } catch (error) {
      this.colorProbe = `refus\xE9 (${error instanceof Error ? error.message : String(error)})`;
      return this.colorProbe;
    } finally {
      frame?.close();
    }
  }
  /** What the technical panel shows. Enough to tell a stall apart from a refusal to fetch. */
  get debug() {
    const spans = [];
    try {
      const ranges = this.videoBuffer?.buffered;
      for (let i = 0; ranges && i < ranges.length; i++) {
        spans.push(`${ranges.start(i).toFixed(0)}\u2013${ranges.end(i).toFixed(0)}`);
      }
    } catch {
      spans.push("illisible (source ferm\xE9e)");
    }
    return {
      "Tampon vid\xE9o": spans.join(" \xB7 ") || "vide",
      "Avance sur la t\xEAte": `${this.lead.toFixed(1)} s`,
      // The two facts that would have named the frozen-clock stall in one glance instead of
      // three reports: what the *element* can play — the intersection of the buffers, not the
      // video buffer alone — and whether it is waiting on a seek that never resolved.
      "Lisible par l'\xE9l\xE9ment": playableSpans(this.video),
      "En cours de saut": this.video.seeking ? "oui" : "non",
      // La seule mesure qui sépare « le décodeur n'y arrive pas » de « la cadence du film ne
      // tombe pas juste sur celle de l'écran ». Sans elle, une lecture qui n'attend jamais et
      // dont le tampon a trente secondes d'avance ne dit toujours rien sur ce qu'on voit.
      "Images perdues": frameQuality(this.video),
      "Couleurs de l'image": this.frameColorSpace(),
      "MediaSource": `${this.source.readyState}${this.streamingWanted ? "" : " \xB7 en pause"}`,
      "Lecture en cours": this.fillTask ? "oui" : "non",
      "Sauts servis": `${this.seeksServed}${this.ladder.recoveries > 0 ? ` \xB7 ${this.ladder.recoveries} reprises` : ""}`,
      ...this.guard.debug
    };
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.guard.destroy();
    this.startHold?.destroy();
    this.startHold = null;
    this.generation += 1;
    this.source.removeEventListener("startstreaming", this.request);
    this.video.removeEventListener("timeupdate", this.request);
    this.video.removeEventListener("waiting", this.request);
    this.video.removeEventListener("seeking", this.onSeeking);
    this.video.removeEventListener("seeked", this.onSeeked);
    this.video.removeEventListener("pause", this.guard.paused);
    this.video.removeEventListener("play", this.onPlay);
    this.video.removeEventListener("playing", this.request);
    this.video.removeEventListener("playing", this.onPlaying);
    if (typeof window !== "undefined" && typeof window.removeEventListener === "function") window.removeEventListener("online", this.onOnline);
    if (this.watchdogTimer) clearInterval(this.watchdogTimer);
    this.watchdogTimer = null;
    if (this.clock.openingReassertTimer) clearTimeout(this.clock.openingReassertTimer);
    this.clock.openingReassertTimer = null;
    if (this.clock.openingGraceTimer) clearTimeout(this.clock.openingGraceTimer);
    this.clock.openingGraceTimer = null;
    if (this.networkRetryTimer) clearTimeout(this.networkRetryTimer);
    this.networkRetryTimer = null;
    this.video.removeEventListener("error", this.onElementError);
    this.source.removeEventListener("sourceclose", this.onSourceClosed);
    for (const [buffer, listener] of this.evictionListeners) buffer.removeEventListener("bufferedchange", listener);
    this.evictionListeners.length = 0;
    this.videoOps?.close();
    this.audioOps?.close();
    try {
      if (this.source.readyState === "open") this.source.endOfStream();
    } catch {
    }
    this.video.removeAttribute("src");
    if (this.objectUrl) {
      URL.revokeObjectURL(this.objectUrl);
      this.objectUrl = null;
    }
    try {
      this.video.srcObject = null;
    } catch {
    }
  }
};

// src/engine/aacConfig.ts
var Bits = class {
  constructor(bytes) {
    this.bytes = bytes;
  }
  bytes;
  pos = 0;
  read(n) {
    let v = 0;
    for (let i = 0; i < n; i++) {
      const byte = this.bytes[this.pos >> 3];
      if (byte === void 0) throw new RangeError("configuration AAC tronqu\xE9e");
      v = v << 1 | byte >> 7 - (this.pos & 7) & 1;
      this.pos++;
    }
    return v;
  }
};
var BitWriter = class {
  bits = [];
  put(value, n) {
    for (let i = n - 1; i >= 0; i--) this.bits.push(value >> i & 1);
  }
  bytes() {
    const bits = [...this.bits];
    while (bits.length % 8) bits.push(0);
    return Uint8Array.from({ length: bits.length / 8 }, (_, i) => bits.slice(i * 8, i * 8 + 8).reduce((v, b) => v << 1 | b, 0));
  }
};
var GA_OBJECT_TYPES = /* @__PURE__ */ new Set([1, 2, 3, 4, 6, 7]);
function parse(asc) {
  const b = new Bits(asc);
  let objectType = b.read(5);
  if (objectType === 31) objectType = 32 + b.read(6);
  const frequencyIndex = b.read(4);
  if (frequencyIndex === 15) b.read(24);
  const channelConfiguration = b.read(4);
  if (channelConfiguration !== 0 || !GA_OBJECT_TYPES.has(objectType)) {
    return { config: { objectType, frequencyIndex, channelConfiguration, pce: null }, layout: null };
  }
  const frameLengthFlag = b.read(1);
  const dependsOnCoreCoder = b.read(1);
  const coreCoderDelay = dependsOnCoreCoder ? b.read(14) : 0;
  const extensionFlag = b.read(1);
  const pceStart = b.pos;
  b.read(4);
  b.read(2);
  b.read(4);
  const nFront = b.read(4);
  const nSide = b.read(4);
  const nBack = b.read(4);
  const nLfe = b.read(2);
  const nAssoc = b.read(3);
  const nCc = b.read(4);
  if (b.read(1)) b.read(4);
  if (b.read(1)) b.read(4);
  if (b.read(1)) b.read(3);
  const elements = [];
  const group = (n, name) => {
    const list = [];
    for (let i = 0; i < n; i++) {
      const cpe = b.read(1) === 1;
      elements.push({ group: name, kind: cpe ? "CPE" : "SCE", tag: b.read(4) });
      list.push(cpe);
    }
    return list;
  };
  const front = group(nFront, "front");
  const side = group(nSide, "side");
  const back = group(nBack, "back");
  for (let i = 0; i < nLfe; i++) elements.push({ group: "lfe", kind: "LFE", tag: b.read(4) });
  for (let i = 0; i < nAssoc; i++) b.read(4);
  for (let i = 0; i < nCc; i++) b.read(5);
  b.read((8 - b.pos % 8) % 8);
  const commentBytes = b.read(8);
  for (let i = 0; i < commentBytes; i++) b.read(8);
  const count = (list) => list.reduce((n, cpe) => n + (cpe ? 2 : 1), 0);
  const channels = count(front) + count(side) + count(back) + nLfe;
  return {
    config: { objectType, frequencyIndex, channelConfiguration, pce: { front, side, back, lfe: nLfe, channels, elements } },
    layout: { pceStart, pceEnd: b.pos, frameLengthFlag, dependsOnCoreCoder, coreCoderDelay, extensionFlag }
  };
}
function parseAacConfig(asc) {
  if (!asc || asc.length < 2) return null;
  try {
    return parse(asc).config;
  } catch {
    return null;
  }
}
var STANDARD_ELEMENTS = {
  1: [{ kind: "SCE", groups: ["front"] }],
  2: [{ kind: "CPE", groups: ["front"] }],
  3: [
    { kind: "SCE", groups: ["front"] },
    { kind: "CPE", groups: ["front"] }
  ],
  4: [
    { kind: "SCE", groups: ["front"] },
    { kind: "CPE", groups: ["front"] },
    { kind: "SCE", groups: ["side", "back"] }
  ],
  5: [
    { kind: "SCE", groups: ["front"] },
    { kind: "CPE", groups: ["front"] },
    { kind: "CPE", groups: ["side", "back"] }
  ],
  6: [
    { kind: "SCE", groups: ["front"] },
    { kind: "CPE", groups: ["front"] },
    { kind: "CPE", groups: ["side", "back"] },
    { kind: "LFE", groups: ["lfe"] }
  ],
  7: [
    { kind: "SCE", groups: ["front"] },
    { kind: "CPE", groups: ["front"] },
    { kind: "CPE", groups: ["front"] },
    { kind: "CPE", groups: ["side", "back"] },
    { kind: "LFE", groups: ["lfe"] }
  ]
};
function standardConfigOf(pce) {
  for (const [config, expected] of Object.entries(STANDARD_ELEMENTS)) {
    if (expected.length !== pce.elements.length) continue;
    const next = { SCE: 0, CPE: 0, LFE: 0 };
    const matches = expected.every((slot, i) => {
      const element = pce.elements[i];
      const ok = element.kind === slot.kind && slot.groups.includes(element.group) && element.tag === next[element.kind];
      next[element.kind]++;
      return ok;
    });
    if (matches) return Number(config);
  }
  return null;
}
function rewriteToStandard(asc) {
  let parsed;
  try {
    parsed = parse(asc);
  } catch {
    return null;
  }
  const { config, layout } = parsed;
  if (!config.pce || !layout) return null;
  const standard = standardConfigOf(config.pce);
  if (standard === null) return null;
  const w = new BitWriter();
  if (config.objectType >= 32) {
    w.put(31, 5);
    w.put(config.objectType - 32, 6);
  } else {
    w.put(config.objectType, 5);
  }
  w.put(config.frequencyIndex, 4);
  if (config.frequencyIndex === 15) {
    const b = new Bits(asc);
    b.read(config.objectType >= 32 ? 11 : 5);
    b.read(4);
    w.put(b.read(24), 24);
  }
  w.put(standard, 4);
  w.put(layout.frameLengthFlag, 1);
  w.put(layout.dependsOnCoreCoder, 1);
  if (layout.dependsOnCoreCoder) w.put(layout.coreCoderDelay, 14);
  w.put(layout.extensionFlag, 1);
  const tail = new Bits(asc);
  tail.pos = layout.pceEnd;
  const remaining = asc.length * 8 - layout.pceEnd;
  for (let i = 0; i < remaining; i++) w.put(tail.read(1), 1);
  return w.bytes();
}
var STANDARD_ORDER = ["L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs"];
function pceShape(pce) {
  const shape = (list) => list.map((cpe) => cpe ? "P" : "M").join("") || "-";
  return `${shape(pce.front)}/${shape(pce.side)}/${shape(pce.back)}/${pce.lfe}`;
}
var MEASURED_DECODED_ORDERS = {
  "PM/M/P/0": ["L", "R", "C", "LFE", "Ls", "Rs"],
  "MP/-/PP/1": ["L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs"]
};
var HALF = Math.SQRT1_2;
function standardMatrix(speakers) {
  const has = (s) => speakers.includes(s);
  const surround = has("Ls") || has("Rs") || has("Lrs") || has("Rrs") || has("Cs") || has("LFE");
  for (const count of [8, 6, 3, 2]) {
    if (speakers.length === count && speakers.every((s, i) => s === STANDARD_ORDER[i])) {
      return { channels: count, rows: [], identity: true };
    }
  }
  if (speakers.length === 1) return { channels: 1, rows: [], identity: true };
  const target = surround ? ["L", "R", "C", "LFE", "Ls", "Rs"] : has("C") ? ["L", "R", "C"] : ["L", "R"];
  const rows = target.map(() => speakers.map(() => 0));
  const add = (out, input, gain) => {
    const row = target.indexOf(out);
    if (row >= 0) rows[row][input] += gain;
  };
  speakers.forEach((speaker, i) => {
    switch (speaker) {
      case "L":
      case "R":
      case "C":
      case "LFE":
        if (target.includes(speaker)) add(speaker, i, 1);
        else if (speaker === "C") {
          add("L", i, HALF);
          add("R", i, HALF);
        }
        break;
      case "Ls":
      case "Rs":
        add(speaker, i, has("Lrs") || has("Rrs") || has("Cs") ? HALF : 1);
        break;
      case "Lrs":
        add("Ls", i, has("Ls") ? HALF : 1);
        break;
      case "Rrs":
        add("Rs", i, has("Rs") ? HALF : 1);
        break;
      case "Cs":
        add("Ls", i, HALF);
        add("Rs", i, HALF);
        break;
      case "Lw":
        add("L", i, HALF);
        break;
      case "Rw":
        add("R", i, HALF);
        break;
    }
  });
  return { channels: target.length, rows, identity: false };
}
function remapPlanes(planes, rows) {
  const frames = planes[0]?.length ?? 0;
  return rows.map((row) => {
    const out = new Float32Array(frames);
    for (let f = 0; f < frames; f++) {
      let sum = 0;
      for (let c = 0; c < row.length; c++) if (row[c] && planes[c]) sum += planes[c][f] * row[c];
      out[f] = sum;
    }
    return out;
  });
}
function decodedOrderMeasuredHere() {
  return aacDecoderRouteHere() === "wasm" || !appleWebKit();
}
function aacDecoderRouteHere() {
  if (typeof navigator === "undefined") return "wasm";
  return isChromiumEngine(navigator.userAgent ?? "") ? "browser" : "wasm";
}
function aacPlan(asc, options = {}) {
  const config = parseAacConfig(asc);
  if (!config?.pce || !asc) return { action: "copy" };
  const pce = config.pce;
  if (options.pceAccepted === true) return { action: "copy" };
  const rewritten = rewriteToStandard(asc);
  if (rewritten) return { action: "rewrite", asc: rewritten, channels: pce.channels };
  const order = MEASURED_DECODED_ORDERS[pceShape(pce)];
  if (order && order.length === pce.channels && (options.orderMeasured ?? decodedOrderMeasuredHere())) {
    const matrix = standardMatrix(order);
    return { action: "decode", channels: matrix.channels, rows: matrix.identity ? null : matrix.rows, keep: null, measured: true };
  }
  const keep = Math.min(3, pce.channels);
  return { action: "decode", channels: keep, rows: null, keep, measured: false };
}

// src/engine/mp4Boxes.ts
function u8(value) {
  return new Uint8Array([value & 255]);
}
function u16(value) {
  return new Uint8Array([value >> 8 & 255, value & 255]);
}
function u24(value) {
  return new Uint8Array([value >> 16 & 255, value >> 8 & 255, value & 255]);
}
function u32(value) {
  return new Uint8Array([
    Math.floor(value / 16777216) & 255,
    value >> 16 & 255,
    value >> 8 & 255,
    value & 255
  ]);
}
function i32(value) {
  const out = new Uint8Array(4);
  new DataView(out.buffer).setInt32(0, value);
  return out;
}
function u64(value) {
  const high = Math.floor(value / 4294967296);
  const low = value >>> 0 === value ? value : value - high * 4294967296;
  return concat(u32(high), u32(low >>> 0));
}
function fourcc(type) {
  if (type.length !== 4) throw new Error(`Type de bo\xEEte invalide : "${type}"`);
  const out = new Uint8Array(4);
  for (let i = 0; i < 4; i++) out[i] = type.charCodeAt(i) & 255;
  return out;
}
function concat(...parts) {
  let length = 0;
  for (const part of parts) length += part.length;
  const out = new Uint8Array(length);
  let at = 0;
  for (const part of parts) {
    out.set(part, at);
    at += part.length;
  }
  return out;
}
function zeros(count) {
  return new Uint8Array(count);
}
function box(type, ...contents) {
  const body = concat(...contents);
  return concat(u32(body.length + 8), fourcc(type), body);
}
function fullBox(type, version, flags, ...contents) {
  return box(type, u8(version), u24(flags), ...contents);
}
function fixed16(value) {
  return u32(Math.round(value * 65536));
}
var UNITY_MATRIX = concat(
  fixed16(1),
  u32(0),
  u32(0),
  u32(0),
  fixed16(1),
  u32(0),
  u32(0),
  u32(0),
  u32(1073741824)
);

// src/engine/mp4SampleEntries.ts
var BitReader = class {
  constructor(bytes) {
    this.bytes = bytes;
  }
  bytes;
  bitPosition = 0;
  read(count) {
    let value = 0;
    for (let i = 0; i < count; i++) {
      const byte = this.bytes[this.bitPosition >> 3] ?? 0;
      const bit = byte >> 7 - (this.bitPosition & 7) & 1;
      value = value << 1 | bit;
      this.bitPosition += 1;
    }
    return value;
  }
  skip(count) {
    this.bitPosition += count;
  }
};
var BitWriter2 = class {
  bits = [];
  write(value, count) {
    for (let i = count - 1; i >= 0; i--) this.bits.push(value >> i & 1);
    return this;
  }
  bytes() {
    while (this.bits.length % 8 !== 0) this.bits.push(0);
    const out = new Uint8Array(this.bits.length / 8);
    for (let i = 0; i < this.bits.length; i++) {
      if (this.bits[i]) out[i >> 3] |= 128 >> (i & 7);
    }
    return out;
  }
};
function visualSampleEntry(type, width, height, configuration) {
  return box(
    type,
    zeros(6),
    // reserved
    u16(1),
    // data reference index
    u16(0),
    u16(0),
    // pre-defined, reserved
    zeros(12),
    // pre-defined
    u16(width),
    u16(height),
    u32(4718592),
    // 72 dpi horizontal
    u32(4718592),
    // 72 dpi vertical
    u32(0),
    // reserved
    u16(1),
    // frame count
    zeros(32),
    // compressor name, a fixed 32-byte field left empty
    u16(24),
    // depth: colour with no alpha
    u16(65535),
    // pre-defined
    configuration
  );
}
function dolbyVisionSampleEntry(codecPrivate, width, height, dolbyVision, colour) {
  return visualSampleEntry(
    "dvh1",
    width,
    height,
    concat(box("hvcC", codecPrivate), box(dolbyVision.type, dolbyVision.record), colour)
  );
}
function colourBoxes(colour) {
  if (!colour) return new Uint8Array(0);
  const parts = [];
  const { primaries, transferCharacteristics: transfer, matrixCoefficients: matrix } = colour;
  if (primaries && transfer && matrix && primaries !== 2 && transfer !== 2 && matrix !== 2) {
    parts.push(box("colr", fourcc("nclx"), u16(primaries), u16(transfer), u16(matrix), u8(colour.range === 2 ? 128 : 0)));
  }
  const m = colour.masteringPrimaries;
  if (m && colour.masteringMaxNits && colour.masteringMinNits !== void 0) {
    const xy = ([x, y]) => concat(u16(Math.round(x * 5e4)), u16(Math.round(y * 5e4)));
    parts.push(
      box(
        "mdcv",
        xy(m.g),
        xy(m.b),
        xy(m.r),
        xy(m.white),
        u32(Math.round(colour.masteringMaxNits * 1e4)),
        u32(Math.round(colour.masteringMinNits * 1e4))
      )
    );
  }
  if (colour.maxContentLightNits) {
    parts.push(box("clli", u16(Math.min(65535, colour.maxContentLightNits)), u16(Math.min(65535, colour.maxFrameAverageNits ?? 0))));
  }
  return parts.length ? concat(...parts) : new Uint8Array(0);
}
function videoSampleEntry(codecId, codecPrivate, width, height, dolbyVision, colour) {
  const described = colourBoxes(colour);
  switch (codecId) {
    case "V_MPEGH/ISO/HEVC":
      if (dolbyVision) return dolbyVisionSampleEntry(codecPrivate, width, height, dolbyVision, described);
      return visualSampleEntry("hvc1", width, height, concat(box("hvcC", codecPrivate), described));
    case "V_MPEG4/ISO/AVC":
      return visualSampleEntry("avc1", width, height, concat(box("avcC", codecPrivate), described));
    case "V_AV1":
      return visualSampleEntry("av01", width, height, concat(box("av1C", codecPrivate), described));
    default:
      throw new Error(`Codec vid\xE9o non remultiplexable : ${codecId}`);
  }
}
function audioSampleEntry(type, channels, sampleRate, configuration, sampleSize = 16) {
  return box(
    type,
    zeros(6),
    // reserved
    u16(1),
    // data reference index
    u32(0),
    u32(0),
    // reserved
    u16(channels),
    u16(sampleSize),
    u16(0),
    u16(0),
    // pre-defined, reserved
    // 16.16 fixed point, and it cannot express rates above 65535 — those are carried by the
    // codec's own configuration instead, which is where a player reads them from anyway.
    u32(Math.min(sampleRate, 65535) << 16),
    configuration
  );
}
function descriptor(tag, payload) {
  const length = [];
  let remaining = payload.length;
  do {
    length.unshift(remaining & 127);
    remaining >>= 7;
  } while (remaining > 0);
  for (let i = 0; i < length.length - 1; i++) length[i] |= 128;
  return concat(u8(tag), new Uint8Array(length), payload);
}
function esds(audioSpecificConfig) {
  const decoderSpecific = descriptor(5, audioSpecificConfig);
  const decoderConfig = descriptor(
    4,
    concat(
      u8(64),
      // MPEG-4 audio
      u8(21),
      // audio stream
      new Uint8Array([0, 0, 0]),
      // buffer size, left unspecified
      u32(0),
      // max bitrate, unspecified
      u32(0),
      // average bitrate, unspecified
      decoderSpecific
    )
  );
  const slConfig = descriptor(6, u8(2));
  const es = descriptor(3, concat(u16(0), u8(0), decoderConfig, slConfig));
  return fullBox("esds", 0, 0, es);
}
var AC3_SAMPLE_RATES = [48e3, 44100, 32e3];
function dac3(frame) {
  const reader = new BitReader(frame);
  if (reader.read(16) !== 2935) throw new Error("Trame AC-3 sans mot de synchronisation.");
  reader.skip(16);
  const fscod = reader.read(2);
  const frmsizecod = reader.read(6);
  const bsid = reader.read(5);
  const bsmod = reader.read(3);
  const acmod = reader.read(3);
  if ((acmod & 1) !== 0 && acmod !== 1) reader.skip(2);
  if ((acmod & 4) !== 0) reader.skip(2);
  if (acmod === 2) reader.skip(2);
  const lfeon = reader.read(1);
  return box(
    "dac3",
    new BitWriter2().write(fscod, 2).write(bsid, 5).write(bsmod, 3).write(acmod, 3).write(lfeon, 1).write(frmsizecod >> 1, 5).write(0, 5).bytes()
  );
}
function dec3(frame) {
  const reader = new BitReader(frame);
  if (reader.read(16) !== 2935) throw new Error("Trame E-AC-3 sans mot de synchronisation.");
  reader.skip(2);
  reader.skip(3);
  const frmsiz = reader.read(11);
  const fscod = reader.read(2);
  const fscod2 = fscod === 3 ? reader.read(2) : null;
  const numblkscod = fscod === 3 ? 3 : reader.read(2);
  const acmod = reader.read(3);
  const lfeon = reader.read(1);
  const bsid = reader.read(5);
  const sampleRate = fscod2 !== null ? AC3_SAMPLE_RATES[fscod2] / 2 : AC3_SAMPLE_RATES[fscod];
  const blocks = [1, 2, 3, 6][numblkscod];
  const frameBytes = (frmsiz + 1) * 2;
  const dataRate = Math.round(frameBytes * 8 * sampleRate / (blocks * 256) / 1e3);
  return box(
    "dec3",
    new BitWriter2().write(Math.min(dataRate, 8191), 13).write(0, 3).write(fscod, 2).write(bsid, 5).write(0, 1).write(0, 1).write(0, 3).write(acmod, 3).write(lfeon, 1).write(0, 3).write(0, 4).write(0, 1).bytes()
  );
}
var ASC_SAMPLE_RATES = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
var AAC_CHANNEL_CONFIGURATIONS = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 8, 11: 7, 12: 8, 13: 24, 14: 8 };
function parseAacConfig2(config) {
  if (config.length < 2) return null;
  const reader = new BitReader(config);
  const readObjectType = () => {
    const value = reader.read(5);
    return value === 31 ? 32 + reader.read(6) : value;
  };
  const readRate = () => {
    const index = reader.read(4);
    return index === 15 ? reader.read(24) : ASC_SAMPLE_RATES[index] ?? 0;
  };
  let objectType = readObjectType();
  let sampleRate = readRate();
  const configuration = reader.read(4);
  let channels = AAC_CHANNEL_CONFIGURATIONS[configuration] ?? configuration;
  if (objectType === 0 || sampleRate === 0) return null;
  if (objectType === 5 || objectType === 29) {
    sampleRate = readRate();
    const core = readObjectType();
    if (objectType === 29 && channels === 1) channels = 2;
    if (core === 22) reader.skip(4);
  }
  return { objectType, sampleRate, channels };
}
function extractAudioSpecificConfig(bytes) {
  let position = 0;
  const readLength = () => {
    let length = 0;
    for (let i = 0; i < 4 && position < bytes.length; i++) {
      const byte = bytes[position++];
      length = length << 7 | byte & 127;
      if ((byte & 128) === 0) break;
    }
    return length;
  };
  const walk = (end) => {
    while (position + 2 <= end) {
      const tag = bytes[position++];
      const length = readLength();
      const payloadEnd = Math.min(position + length, end);
      if (payloadEnd > bytes.length) return null;
      switch (tag) {
        case 5:
          return bytes.subarray(position, payloadEnd);
        case 3:
          position += 3;
          return walk(payloadEnd);
        case 4:
          position += 13;
          return walk(payloadEnd);
        default:
          position = payloadEnd;
      }
    }
    return null;
  };
  if (bytes.length < 4 || bytes[0] !== 3 && bytes[0] !== 4 && bytes[0] !== 5) return null;
  return walk(bytes.length);
}
function dOps(opusHead) {
  if (opusHead.length < 19) throw new Error("En-t\xEAte Opus trop court.");
  const view = new DataView(opusHead.buffer, opusHead.byteOffset, opusHead.byteLength);
  const channels = opusHead[9];
  const preSkip = view.getUint16(10, true);
  const inputRate = view.getUint32(12, true);
  const outputGain = view.getInt16(16, true);
  const mappingFamily = opusHead[18];
  const head = concat(
    u8(0),
    // version of the box, which is not the version in the header
    u8(channels),
    u16(preSkip),
    u32(inputRate),
    u16(outputGain & 65535),
    u8(mappingFamily)
  );
  const table = mappingFamily === 0 ? new Uint8Array(0) : opusHead.subarray(19, 19 + 2 + channels);
  return box("dOps", head, table);
}
function opusSampleEntry(opusHead, channels, sampleRate) {
  return audioSampleEntry("Opus", channels, sampleRate, dOps(opusHead));
}
function isOpusHead(bytes) {
  if (!bytes || bytes.length < 19) return false;
  const magic = [79, 112, 117, 115, 72, 101, 97, 100];
  if (!magic.every((b, i) => bytes[i] === b)) return false;
  if ((bytes[8] & 240) !== 0) return false;
  const channels = bytes[9];
  if (channels === 0) return false;
  const family = bytes[18];
  if (family === 0) return channels <= 2;
  return bytes.length >= 19 + 2 + channels;
}
function flacBlocks(codecPrivate) {
  const hasMagic = codecPrivate.length > 8 && codecPrivate[0] === 102 && codecPrivate[1] === 76 && codecPrivate[2] === 97 && codecPrivate[3] === 67;
  const blocks = hasMagic ? codecPrivate.subarray(4) : codecPrivate;
  if (blocks.length < 38 || (blocks[0] & 127) !== 0) return null;
  return blocks;
}
function dfLa(codecPrivate) {
  const blocks = flacBlocks(codecPrivate);
  if (!blocks) return null;
  const streamInfo = blocks.slice(0, 38);
  streamInfo[0] |= 128;
  return box("dfLa", u32(0), streamInfo);
}
function flacBitsPerSample(codecPrivate) {
  const blocks = flacBlocks(codecPrivate);
  if (!blocks) return null;
  const info = blocks.subarray(4);
  return ((info[12] & 1) << 4 | info[13] >> 4) + 1;
}
function audioSampleEntryFor(input) {
  const { codecId, codecPrivate, channels, sampleRate, firstFrame } = input;
  switch (codecId) {
    case "A_AAC":
      if (!codecPrivate) throw new Error("Piste AAC sans configuration de d\xE9codeur.");
      return audioSampleEntry("mp4a", channels, sampleRate, esds(codecPrivate));
    case "A_FLAC": {
      if (!codecPrivate) throw new Error("Piste FLAC sans configuration de d\xE9codeur.");
      const configuration = dfLa(codecPrivate);
      if (!configuration) throw new Error("Configuration FLAC illisible.");
      return audioSampleEntry("fLaC", channels, sampleRate, configuration, flacBitsPerSample(codecPrivate) ?? 16);
    }
    case "A_AC3":
      if (!firstFrame) throw new Error("Piste AC-3 sans trame \xE0 analyser.");
      return audioSampleEntry("ac-3", channels, sampleRate, dac3(firstFrame));
    case "A_EAC3":
      if (!firstFrame) throw new Error("Piste E-AC-3 sans trame \xE0 analyser.");
      return audioSampleEntry("ec-3", channels, sampleRate, dec3(firstFrame));
    case "A_OPUS": {
      if (!isOpusHead(codecPrivate)) throw new Error("Configuration Opus illisible.");
      return opusSampleEntry(codecPrivate, codecPrivate[9], 48e3);
    }
    default:
      throw new Error(`Codec audio non remultiplexable : ${codecId}`);
  }
}

// src/engine/mp4Muxer.ts
var MOVIE_TIMESCALE = 1e3;
function packLanguage(language) {
  const code = /^[a-z]{3}$/.test(language) ? language : "und";
  return code.charCodeAt(0) - 96 << 10 | code.charCodeAt(1) - 96 << 5 | code.charCodeAt(2) - 96;
}
function mvhd(durationSeconds) {
  return fullBox(
    "mvhd",
    0,
    0,
    u32(0),
    u32(0),
    // created, modified
    u32(MOVIE_TIMESCALE),
    // Zero, deliberately: the real length lives in mehd and in the MediaSource's own duration.
    // Two places claiming a duration that disagree is worse than one place saying "ask elsewhere".
    u32(0),
    u32(65536),
    // rate 1.0
    u16(256),
    // volume 1.0
    u16(0),
    u32(0),
    u32(0),
    // reserved
    UNITY_MATRIX,
    zeros(24),
    // pre-defined
    u32(4294967295)
    // next track id: none to allocate, this movie is closed
  );
}
function tkhd(track) {
  const isVideo = track.kind === "video";
  return fullBox(
    "tkhd",
    0,
    7,
    // enabled, in movie, in preview
    u32(0),
    u32(0),
    u32(track.id),
    u32(0),
    // reserved
    u32(0),
    // duration, deferred to mehd as above
    u32(0),
    u32(0),
    // reserved
    u16(0),
    // layer
    u16(0),
    // alternate group
    u16(isVideo ? 0 : 256),
    // volume applies to sound only
    u16(0),
    // reserved
    UNITY_MATRIX,
    u32(isVideo ? track.width * 65536 : 0),
    // 16.16 fixed point
    u32(isVideo ? track.height * 65536 : 0)
  );
}
function mdia(track) {
  const isVideo = track.kind === "video";
  const handlerName = isVideo ? "VideoHandler" : "SoundHandler";
  const mdhd = fullBox(
    "mdhd",
    0,
    0,
    u32(0),
    u32(0),
    u32(track.timescale),
    u32(0),
    // duration
    u16(packLanguage(track.language)),
    u16(0)
    // pre-defined
  );
  const hdlr = fullBox(
    "hdlr",
    0,
    0,
    u32(0),
    // pre-defined
    new TextEncoder().encode(isVideo ? "vide" : "soun"),
    u32(0),
    u32(0),
    u32(0),
    // reserved
    new TextEncoder().encode(handlerName),
    u8(0)
  );
  const mediaHeader = isVideo ? fullBox("vmhd", 0, 1, u16(0), u16(0), u16(0), u16(0)) : fullBox("smhd", 0, 0, u16(0), u16(0));
  const dinf = box("dinf", fullBox("dref", 0, 0, u32(1), fullBox("url ", 0, 1)));
  const stbl = box(
    "stbl",
    fullBox("stsd", 0, 0, u32(1), track.sampleEntry),
    fullBox("stts", 0, 0, u32(0)),
    fullBox("stsc", 0, 0, u32(0)),
    fullBox("stsz", 0, 0, u32(0), u32(0)),
    fullBox("stco", 0, 0, u32(0))
  );
  return box("mdia", mdhd, hdlr, box("minf", mediaHeader, dinf, stbl));
}
function initSegment(track, durationSeconds) {
  const ftyp = box(
    "ftyp",
    new TextEncoder().encode("iso5"),
    u32(1),
    // minor version
    new TextEncoder().encode("iso5"),
    new TextEncoder().encode("iso6"),
    new TextEncoder().encode("mp41")
  );
  const mehd = fullBox("mehd", 1, 0, u64(Math.round(durationSeconds * MOVIE_TIMESCALE)));
  const trex = fullBox(
    "trex",
    0,
    0,
    u32(track.id),
    u32(1),
    // sample description index
    u32(0),
    u32(0),
    u32(0)
    // no defaults: every fragment states its samples in full
  );
  return concat(ftyp, box("moov", mvhd(durationSeconds), box("trak", tkhd(track), mdia(track)), box("mvex", mehd, trex)));
}
function sampleFlags(isKeyframe) {
  return isKeyframe ? u32(33554432) : u32(16842752);
}
function mediaSegment(track, sequenceNumber, samples, nextDecodeTime) {
  if (samples.length === 0) throw new Error("Segment m\xE9dia vide.");
  const perSample = concat(
    ...samples.flatMap((sample, index) => {
      const next = samples[index + 1];
      const duration = next ? Math.max(1, next.decodeTime - sample.decodeTime) : nextDecodeTime !== void 0 ? Math.max(1, nextDecodeTime - sample.decodeTime) : sample.duration;
      return [
        u32(duration),
        u32(sample.data.length),
        sampleFlags(sample.isKeyframe),
        i32(sample.compositionOffset)
      ];
    })
  );
  const buildMoof = (dataOffset) => {
    const traf = box(
      "traf",
      // default-base-is-moof: sample positions are measured from the start of this moof, so the
      // segment is self-contained and can be appended at any point in any order.
      fullBox("tfhd", 0, 131072, u32(track.id)),
      fullBox("tfdt", 1, 0, u64(samples[0].decodeTime)),
      // Version 1: composition offsets are signed. A reordered picture is shown before a
      // picture decoded earlier, so its offset is genuinely negative. The alternative — version 0
      // and delaying the whole presentation timeline — only works if every track is delayed by
      // the same amount, and getting that wrong is a lip-sync error rather than a visible break.
      // data-offset, sample-duration, sample-size, sample-flags, composition-offset all present.
      fullBox("trun", 1, 3841, u32(samples.length), i32(dataOffset), perSample)
    );
    return box("moof", fullBox("mfhd", 0, 0, u32(sequenceNumber)), traf);
  };
  const moofLength = buildMoof(0).length;
  const moof = buildMoof(moofLength + 8);
  return concat(moof, box("mdat", ...samples.map((sample) => sample.data)));
}

// src/engine/aacPceProbe.ts
var PROBE_ASC = Uint8Array.from([
  17,
  128,
  4,
  200,
  68,
  0,
  32,
  0,
  196,
  13,
  76,
  97,
  118,
  99,
  54,
  50,
  46,
  50,
  56,
  46,
  49,
  48,
  51,
  86,
  229,
  0
]);
var PROBE_FRAME = Uint8Array.from([
  33,
  16,
  4,
  96,
  140,
  0,
  35,
  4,
  0,
  3,
  24,
  32,
  1,
  24,
  128,
  35,
  4,
  96,
  224
]);
var STORAGE_KEY = "lumen-aac-pce-mse:v2";
var LEGACY_KEYS = ["lumen-aac-pce-mse:v1"];
var REFUSALS_KEY = "lumen-aac-pce-refus:v1";
var PROBE_TIMEOUT_MS = 1500;
function pceCopyAccepted() {
  try {
    if (typeof localStorage === "undefined" || typeof navigator === "undefined") return null;
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const stored = JSON.parse(raw);
    if (stored.ua !== navigator.userAgent || typeof stored.ok !== "boolean") return null;
    return stored.ok;
  } catch {
    return null;
  }
}
function effectivePceAnswer(asc) {
  dropLegacyKeys();
  try {
    if (typeof navigator === "undefined") return null;
    if (isChromiumEngine(navigator.userAgent ?? "")) return asc && shapeRefused(asc) ? false : pceCopyAccepted();
  } catch {
    return null;
  }
  return asc && shapeRefused(asc) ? false : true;
}
function shapeKey(asc) {
  let hex = "";
  for (const byte of asc) hex += byte.toString(16).padStart(2, "0");
  return hex;
}
function readRefusals() {
  try {
    if (typeof localStorage === "undefined") return [];
    const raw = localStorage.getItem(REFUSALS_KEY);
    if (!raw) return [];
    const stored = JSON.parse(raw);
    if (stored.build !== hostBuild() || !Array.isArray(stored.shapes)) return [];
    return stored.shapes.filter((x) => typeof x === "string");
  } catch {
    return [];
  }
}
var refusedHere = /* @__PURE__ */ new Set();
function shapeRefused(asc) {
  const key = shapeKey(asc);
  return refusedHere.has(key) || readRefusals().includes(key);
}
var legacyDropped = false;
function dropLegacyKeys() {
  if (legacyDropped) return;
  legacyDropped = true;
  try {
    for (const key of LEGACY_KEYS) localStorage.removeItem(key);
  } catch {
  }
}
var pceCopyInEffect = false;
var pceCopyAsc = null;
var pendingFallback = null;
var lastPceDecision = null;
function notePceDecision(plan, copiedAsIs, asc) {
  lastPceDecision = { plan, answer: effectivePceAnswer(asc), fallback: pendingFallback };
  pendingFallback = null;
  if (copiedAsIs) {
    pceCopyInEffect = true;
    pceCopyAsc = asc ?? null;
  }
}
function resetPceCopyState() {
  pceCopyInEffect = false;
  pceCopyAsc = null;
  lastPceDecision = null;
}
function remember(ok) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ua: navigator.userAgent, ok }));
  } catch {
  }
}
var pending = null;
function primePceProbe() {
  if (pceCopyAccepted() !== null || pending) return;
  pending = probePceCopy().catch(() => null).finally(() => {
    pending = null;
  });
}
async function probePceCopy() {
  if (typeof document === "undefined") return null;
  const Source = sourceConstructor();
  if (!Source) return null;
  const mime = 'audio/mp4; codecs="mp4a.40.2"';
  try {
    if (!Source.isTypeSupported(mime)) {
      remember(false);
      return false;
    }
  } catch {
    return null;
  }
  const track = {
    id: 1,
    kind: "audio",
    timescale: 48e3,
    sampleEntry: audioSampleEntryFor({ codecId: "A_AAC", codecPrivate: PROBE_ASC, channels: 6, sampleRate: 48e3, firstFrame: null }),
    width: 0,
    height: 0,
    language: "und"
  };
  const init = initSegment(track, 0);
  const media = mediaSegment(track, 1, [
    { data: PROBE_FRAME, decodeTime: 0, duration: 1024, compositionOffset: 0, isKeyframe: true },
    { data: PROBE_FRAME, decodeTime: 1024, duration: 1024, compositionOffset: 0, isKeyframe: true }
  ]);
  const answer = await new Promise((resolve) => {
    const element = document.createElement("audio");
    element.disableRemotePlayback = true;
    const source = new Source();
    let url = null;
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        element.removeAttribute("src");
        if (url) URL.revokeObjectURL(url);
        element.load();
      } catch {
      }
      resolve(result);
    };
    const timer = setTimeout(() => finish(null), PROBE_TIMEOUT_MS);
    source.addEventListener(
      "sourceopen",
      () => {
        try {
          const buffer = source.addSourceBuffer(mime);
          buffer.addEventListener("error", () => finish(false), { once: true });
          source.addEventListener("sourceended", () => finish(false), { once: true });
          buffer.addEventListener(
            "updateend",
            () => {
              try {
                buffer.addEventListener(
                  "updateend",
                  () => finish(source.readyState === "open" && buffer.buffered.length > 0),
                  { once: true }
                );
                buffer.appendBuffer(media);
              } catch {
                finish(false);
              }
            },
            { once: true }
          );
          buffer.appendBuffer(init);
        } catch {
          finish(false);
        }
      },
      { once: true }
    );
    try {
      element.srcObject = source;
    } catch {
    }
    if (!element.srcObject) {
      try {
        url = URL.createObjectURL(source);
        element.src = url;
      } catch {
        finish(null);
      }
    }
  });
  if (answer !== null) remember(answer);
  return answer;
}

// src/engine/dialogueEnhance.ts
var DIALOGUE_TUNING = {
  on: {
    center: 3,
    front: -1,
    surround: -2,
    lfe: -4,
    mid: 2,
    side: -2,
    presence: 4,
    body: 1.5,
    low: -3,
    voiceTarget: -26,
    voiceMaxUp: 6,
    voiceCeil: -10,
    voiceCeilRatio: 2,
    duck: -2,
    margin: 4,
    relRatio: 2,
    bgThreshold: -10,
    bgRatio: 1.5
  },
  strong: {
    center: 5,
    front: -2,
    surround: -3,
    lfe: -9,
    mid: 3,
    side: -3,
    presence: 6,
    body: 2,
    low: -5,
    voiceTarget: -22,
    voiceMaxUp: 9,
    voiceCeil: -10,
    voiceCeilRatio: 2,
    duck: -4,
    margin: 0,
    relRatio: 3,
    bgThreshold: -16,
    bgRatio: 2.5
  }
};
var dbToGain = (db) => Math.pow(10, db / 20);
var CEILING = dbToGain(-1);
var KNEE_DB = 6;
var Biquad = class _Biquad {
  constructor(b0, b1, b2, a1, a2) {
    this.b0 = b0;
    this.b1 = b1;
    this.b2 = b2;
    this.a1 = a1;
    this.a2 = a2;
  }
  b0;
  b1;
  b2;
  a1;
  a2;
  x1 = 0;
  x2 = 0;
  y1 = 0;
  y2 = 0;
  static peaking(sr, freq, q, gainDb) {
    const a = Math.pow(10, gainDb / 40);
    const w = 2 * Math.PI * freq / sr;
    const alpha = Math.sin(w) / (2 * q);
    const cos = Math.cos(w);
    const a0 = 1 + alpha / a;
    return new _Biquad((1 + alpha * a) / a0, -2 * cos / a0, (1 - alpha * a) / a0, -2 * cos / a0, (1 - alpha / a) / a0);
  }
  static lowShelf(sr, freq, gainDb) {
    const a = Math.pow(10, gainDb / 40);
    const w = 2 * Math.PI * freq / sr;
    const cos = Math.cos(w);
    const alpha = Math.sin(w) / 2 * Math.SQRT2;
    const sq = 2 * Math.sqrt(a) * alpha;
    const a0 = a + 1 + (a - 1) * cos + sq;
    return new _Biquad(
      a * (a + 1 - (a - 1) * cos + sq) / a0,
      2 * a * (a - 1 - (a + 1) * cos) / a0,
      a * (a + 1 - (a - 1) * cos - sq) / a0,
      -2 * (a - 1 + (a + 1) * cos) / a0,
      (a + 1 + (a - 1) * cos - sq) / a0
    );
  }
  static highPass(sr, freq, q = Math.SQRT1_2) {
    const w = 2 * Math.PI * freq / sr;
    const cos = Math.cos(w);
    const alpha = Math.sin(w) / (2 * q);
    const a0 = 1 + alpha;
    return new _Biquad((1 + cos) / 2 / a0, -(1 + cos) / a0, (1 + cos) / 2 / a0, -2 * cos / a0, (1 - alpha) / a0);
  }
  static lowPass(sr, freq, q = Math.SQRT1_2) {
    const w = 2 * Math.PI * freq / sr;
    const cos = Math.cos(w);
    const alpha = Math.sin(w) / (2 * q);
    const a0 = 1 + alpha;
    return new _Biquad((1 - cos) / 2 / a0, (1 - cos) / a0, (1 - cos) / 2 / a0, -2 * cos / a0, (1 - alpha) / a0);
  }
  run(x) {
    const y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;
    this.x2 = this.x1;
    this.x1 = x;
    this.y2 = this.y1;
    this.y1 = y;
    return y;
  }
  reset() {
    this.x1 = this.x2 = this.y1 = this.y2 = 0;
  }
};
var Chain = class {
  constructor(stages) {
    this.stages = stages;
  }
  stages;
  run(x) {
    let y = x;
    for (const s of this.stages) y = s.run(y);
    return y;
  }
  reset() {
    for (const s of this.stages) s.reset();
  }
};
function compGain(levelDb, threshold, ratio) {
  const over = levelDb - threshold;
  let reduction;
  if (over <= -KNEE_DB / 2) reduction = 0;
  else if (over >= KNEE_DB / 2) reduction = over * (1 - 1 / ratio);
  else {
    const x = over + KNEE_DB / 2;
    reduction = (1 - 1 / ratio) * x * x / (2 * KNEE_DB);
  }
  return dbToGain(-reduction);
}
var smoothstep = (lo, hi, x) => {
  const t = Math.min(1, Math.max(0, (x - lo) / (hi - lo)));
  return t * t * (3 - 2 * t);
};
var toDb = (power) => power > 1e-12 ? 10 * Math.log10(power) : -120;
function layoutOf(channels) {
  if (channels === 1) return "mono";
  if (channels === 2) return "stereo";
  if (channels === 3 || channels === 6 || channels === 8) return "centre";
  return "other";
}
var Envelope = class {
  constructor(attack, release) {
    this.attack = attack;
    this.release = release;
  }
  attack;
  release;
  value = 0;
  run(x) {
    const k = x > this.value ? this.attack : this.release;
    this.value = k * this.value + (1 - k) * x;
    return this.value;
  }
};
var DialogueEnhancer = class {
  constructor(sampleRate, channels, mode) {
    this.sampleRate = sampleRate;
    this.channels = channels;
    this.mode = mode;
    const t = this.t = DIALOGUE_TUNING[mode];
    this.layout = layoutOf(channels);
    this.coef = (ms) => Math.exp(-1 / (ms / 1e3 * sampleRate));
    const c = this.coef;
    this.k = { speechUp: c(40), speechDown: c(450), levelDown: c(60), levelUp: c(800), lim: c(80) };
    this.eq = new Chain([
      Biquad.lowShelf(sampleRate, 150, t.low),
      Biquad.peaking(sampleRate, 1e3, 0.8, t.body),
      Biquad.peaking(sampleRate, 3e3, 0.9, t.presence)
    ]);
    this.band = new Chain([Biquad.highPass(sampleRate, 300), Biquad.lowPass(sampleRate, 3400)]);
    this.voiceIndex = this.layout === "centre" ? 2 : 0;
    this.gains = Array.from({ length: channels }, (_, i) => {
      if (this.layout === "centre") {
        if (i === 0 || i === 1) return dbToGain(t.front);
        if (i === 2) return dbToGain(t.center);
        if (i === 3 && channels > 3) return dbToGain(t.lfe);
        return dbToGain(t.surround);
      }
      return 1;
    });
    this.reset();
  }
  sampleRate;
  channels;
  mode;
  layout;
  t;
  eq;
  /** Bande de la parole (300–3400 Hz), sur le canal des voix avant égalisation : le détecteur. */
  band;
  /** Gains fixes par plan (le canal des voix compris : son gain fixe). */
  gains;
  voiceIndex;
  coef;
  // États.
  bandEnv;
  fullEnv;
  voiceEnv;
  ceilEnv;
  bgEnv;
  /** Niveau de la voix mise en forme, lent : la référence du fond relatif. */
  refEnv;
  /** Gain du niveleur, en dB (≥ 0). */
  levelUp = 0;
  /** Part de parole détectée, lissée (0…1). */
  speech = 0;
  limGain = 1;
  voiceLim = 1;
  k;
  reset() {
    const c = this.coef;
    this.eq.reset();
    this.band.reset();
    this.bandEnv = new Envelope(c(10), c(120));
    this.fullEnv = new Envelope(c(10), c(120));
    this.voiceEnv = new Envelope(c(50), c(400));
    this.ceilEnv = new Envelope(c(10), c(150));
    this.bgEnv = new Envelope(c(20), c(250));
    this.refEnv = new Envelope(c(50), c(600));
    this.levelUp = 0;
    this.speech = 0;
    this.limGain = 1;
    this.voiceLim = 1;
  }
  /** Part de parole dans le signal des voix (0…1), lissée : vite pour s'effacer, lentement pour revenir. */
  detect(raw) {
    const b = this.band.run(raw);
    const band = this.bandEnv.run(b * b);
    const full = this.fullEnv.run(raw * raw);
    const ratio = full > 1e-12 ? band / full : 0;
    const target = smoothstep(0.3, 0.6, ratio) * smoothstep(-55, -45, toDb(band));
    const k = target > this.speech ? this.k.speechUp : this.k.speechDown;
    this.speech = k * this.speech + (1 - k) * target;
    return this.speech;
  }
  /**
   * Le gain du fond (linéaire) pour une puissance de fond et la part de parole : gain fixe à part,
   * le retrait et la compression relative pèsent selon la parole, le compresseur absolu toujours.
   */
  backgroundGain(bgPower, s) {
    const t = this.t;
    const bg = toDb(this.bgEnv.run(bgPower));
    const ref = toDb(this.refEnv.value);
    const over = bg - (ref + t.margin);
    const rel = over > 0 ? over * (1 - 1 / t.relRatio) : 0;
    return compGain(bg, t.bgThreshold, t.bgRatio) * dbToGain(s * (t.duck - rel));
  }
  /** Le signal des voix, mis en forme : égalisé, gain fixe, niveleur (vers le haut seulement), plafond. */
  shapeVoice(raw, fixedGain) {
    const t = this.t;
    const v = this.eq.run(raw) * fixedGain;
    const level = toDb(this.voiceEnv.run(v * v));
    const want = Math.min(t.voiceMaxUp, Math.max(0, t.voiceTarget - level)) * smoothstep(-62, -50, level);
    const k = want < this.levelUp ? this.k.levelDown : this.k.levelUp;
    this.levelUp = k * this.levelUp + (1 - k) * want;
    let y = v * dbToGain(this.levelUp);
    const ceil = toDb(this.ceilEnv.run(y * y));
    y *= compGain(ceil, t.voiceCeil, t.voiceCeilRatio);
    this.refEnv.run(y * y);
    return y;
  }
  /** Un pas de limiteur : attaque immédiate, relâche douce. */
  limit(gain, peak) {
    const need = peak > CEILING ? CEILING / peak : 1;
    const g = need < gain ? need : this.k.lim * gain + (1 - this.k.lim) * Math.min(1, need);
    return g > need ? need : g;
  }
  process(planes) {
    const n = planes.length;
    if (n !== this.channels || n === 0) return planes;
    const frames = planes[0].length;
    const out = planes.map(() => new Float32Array(frames));
    const frame = new Float64Array(n);
    const t = this.t;
    for (let i = 0; i < frames; i++) {
      if (this.layout === "centre") {
        const raw = planes[2][i];
        const s = this.detect(raw);
        const voice = this.shapeVoice(raw, this.gains[2]);
        let bgPower = 0;
        for (let c = 0; c < n; c++) {
          if (c === 2) continue;
          const x = planes[c][i] * this.gains[c];
          frame[c] = x;
          bgPower += x * x;
        }
        const bgGain = this.backgroundGain(bgPower, s);
        for (let c = 0; c < n; c++) if (c !== 2) frame[c] *= bgGain;
        frame[2] = voice;
      } else if (this.layout === "stereo") {
        const l = planes[0][i];
        const r = planes[1][i];
        const midRaw = (l + r) * 0.5;
        const s = this.detect(midRaw);
        const mid = this.shapeVoice(midRaw, dbToGain(t.mid));
        let side = (l - r) * 0.5 * dbToGain(t.side);
        side *= this.backgroundGain(side * side * 2, s);
        frame[0] = mid + side;
        frame[1] = mid - side;
      } else if (this.layout === "mono") {
        frame[0] = this.shapeVoice(planes[0][i], 1);
      } else {
        let power = 0;
        for (let c = 0; c < n; c++) power += planes[c][i] * planes[c][i];
        const g = compGain(toDb(this.bgEnv.run(power)), t.bgThreshold, t.bgRatio);
        for (let c = 0; c < n; c++) frame[c] = planes[c][i] * g;
      }
      const v = this.voiceIndex;
      const hasVoice = this.layout === "centre" || this.layout === "mono";
      let peak = 0;
      for (let c = 0; c < n; c++) {
        if (hasVoice && c === v) continue;
        const a = Math.abs(frame[c]);
        if (a > peak) peak = a;
      }
      this.limGain = this.limit(this.limGain, peak);
      if (hasVoice) this.voiceLim = this.limit(this.voiceLim, Math.abs(frame[v]));
      for (let c = 0; c < n; c++) out[c][i] = frame[c] * (hasVoice && c === v ? this.voiceLim : this.limGain);
    }
    return out;
  }
};

// src/engine/softwareAudio.ts
var lastAacRoute = null;
var lastOwnDemux = null;
var lastTrueHdThread = null;
var SoftwareAudioTrack = class _SoftwareAudioTrack {
  constructor(produce, format, dispose) {
    this.produce = produce;
    this.format = format;
    this.dispose = dispose;
  }
  produce;
  format;
  dispose;
  /**
   * Opens the given Matroska track for software decoding.
   *
   * Throws with a specific reason rather than returning null: "no sound" with no explanation is
   * exactly the kind of failure that costs a round trip to diagnose, and every step here can fail
   * for a different reason — the module not loading, the worker not starting, the track not being
   * found, the decoder declining it.
   */
  static async open(source, trackNumber, codecId, file, options = {}) {
    if (codecId === "A_TRUEHD" || codecId === "A_MLP") {
      let track;
      try {
        track = await (await import("./lumen-truehdAudio-ZX7BVCPT.js")).openTrueHdTrack(source, trackNumber, file);
      } catch (error) {
        throw new Error(`d\xE9codeur TrueHD non charg\xE9 (${error instanceof Error ? error.message : "import \xE9chou\xE9"})`);
      }
      lastTrueHdThread = { thread: track.thread, ...track.workerRefusal !== void 0 ? { workerRefusal: track.workerRefusal } : {} };
      return new _SoftwareAudioTrack(track.samples, track.format, () => track.close());
    }
    if (codecId === "A_AAC" && (aacDecoderRouteHere() === "wasm" || options.measuredAacDecoder)) return _SoftwareAudioTrack.openWasmAac(source, trackNumber, file);
    if (codecId === "A_AAC") {
      try {
        return await _SoftwareAudioTrack.openOwn(source, trackNumber, codecId, file);
      } catch (error) {
        try {
          return await _SoftwareAudioTrack.openWasmAac(source, trackNumber, file);
        } catch {
          throw error;
        }
      }
    }
    return _SoftwareAudioTrack.openOwn(source, trackNumber, codecId, file);
  }
  /** Un AAC à PCE par le décodeur de FFmpeg en WebAssembly — voir aac/aacWasmAudio.ts. */
  static async openWasmAac(source, trackNumber, file) {
    let track;
    try {
      track = await (await import("./lumen-aacWasmAudio-ACSHL75W.js")).openWasmAacTrack(source, trackNumber, file);
    } catch (error) {
      throw new Error(`d\xE9codeur AAC non charg\xE9 (${error instanceof Error ? error.message : "import \xE9chou\xE9"})`);
    }
    lastAacRoute = "wasm-decode";
    const { channels, rows } = aacShaping(file, trackNumber, track.format.numberOfChannels, true) ?? { channels: track.format.numberOfChannels, rows: null };
    const produce = rows ? (fromSeconds) => remapped(track.samples(fromSeconds), rows) : channels < track.format.numberOfChannels ? (fromSeconds) => firstPlanes(track.samples(fromSeconds), channels) : (fromSeconds) => track.samples(fromSeconds);
    return new _SoftwareAudioTrack(produce, { sampleRate: track.format.sampleRate, numberOfChannels: channels }, () => track.close());
  }
  /** Une piste ouverte par nos paquets (ownAudio.ts), rangée comme les autres — l'AAC à PCE compris. */
  static fromOwn(own, codecId, file, trackNumber) {
    lastOwnDemux = own;
    const shape = codecId === "A_AAC" ? aacShaping(file, trackNumber, own.format.numberOfChannels) : null;
    if (codecId === "A_AAC") lastAacRoute = "browser-decode";
    const produce = shape?.rows ? (fromSeconds) => remapped(own.samples(fromSeconds), shape.rows) : shape && shape.channels < own.format.numberOfChannels ? (fromSeconds) => firstPlanes(own.samples(fromSeconds), shape.channels) : (fromSeconds) => own.samples(fromSeconds);
    return new _SoftwareAudioTrack(produce, { sampleRate: own.format.sampleRate, numberOfChannels: shape ? shape.channels : own.format.numberOfChannels }, () => {
    });
  }
  /**
   * Nos paquets et le décodeur du codec (ownAudio.ts). Le fichier déjà lu par le lecteur est
   * nécessaire : c'est son en-tête et son index qui servent — on ne les relit jamais.
   */
  static async openOwn(source, trackNumber, codecId, file) {
    if (!file) throw new Error("d\xE9codeur audio non charg\xE9 (fichier non lu)");
    let own;
    try {
      own = await (await import("./lumen-ownAudio-ASW6D5YS.js")).openOwnAudioTrack(source, file, trackNumber);
    } catch (error) {
      throw new Error(`d\xE9codeur audio non charg\xE9 (${error instanceof Error ? error.message : "import \xE9chou\xE9"})`);
    }
    return _SoftwareAudioTrack.fromOwn(own, codecId, file, trackNumber);
  }
  /** Decoded audio from `fromSeconds` onwards, as plain float planes. */
  samples(fromSeconds) {
    return this.produce(fromSeconds);
  }
  close() {
    this.dispose();
  }
};
function aacShaping(file, trackNumber, decoded, ffmpegDecoder = false) {
  const asc = file?.tracks.find((t) => t.number === trackNumber)?.codecPrivate;
  if (!asc) return null;
  const plan = ffmpegDecoder ? aacPlan(asc, { pceAccepted: false, orderMeasured: true }) : aacPlan(asc, { pceAccepted: effectivePceAnswer(asc) });
  if (plan.action !== "decode") return null;
  if (plan.rows) return plan.rows[0]?.length === decoded ? { channels: plan.channels, rows: plan.rows } : { channels: Math.min(3, decoded), rows: null };
  return { channels: Math.min(plan.channels, decoded), rows: null };
}
async function* remapped(source, rows) {
  for await (const decoded of source) yield { ...decoded, planes: remapPlanes(decoded.planes, rows) };
}
async function* firstPlanes(source, count) {
  for await (const decoded of source) yield { ...decoded, planes: decoded.planes.slice(0, count) };
}

// src/engine/audioLeadGap.ts
var AUDIO_LEAD_GAP_SECONDS = 2;
function audioLeadGapSeconds(videoStartSeconds, firstAudioSeconds) {
  const gap = firstAudioSeconds - videoStartSeconds;
  return gap > AUDIO_LEAD_GAP_SECONDS ? gap : null;
}
var lateTracks = /* @__PURE__ */ new WeakMap();
function rememberLeadGap(file, trackNumber, gapS) {
  let tracks = lateTracks.get(file);
  if (!tracks) lateTracks.set(file, tracks = /* @__PURE__ */ new Map());
  tracks.set(trackNumber, Math.max(gapS, tracks.get(trackNumber) ?? 0));
}
function rememberedLeadGap(file, trackNumber) {
  return lateTracks.get(file)?.get(trackNumber);
}
var SILENCE_BLOCK_FRAMES = 4096;
async function* withLeadSilence(decoded, fromSeconds, onGap) {
  try {
    const first = await decoded.next();
    if (first.done) return;
    const block = first.value;
    const gap = audioLeadGapSeconds(fromSeconds, block.timestampSeconds);
    if (gap !== null) {
      onGap?.(gap);
      const rate = block.sampleRate;
      const total = Math.round(gap * rate);
      const full = Array.from({ length: block.planes.length }, () => new Float32Array(SILENCE_BLOCK_FRAMES));
      for (let done = 0; done < total; done += SILENCE_BLOCK_FRAMES) {
        const frames = Math.min(SILENCE_BLOCK_FRAMES, total - done);
        yield {
          planes: frames === SILENCE_BLOCK_FRAMES ? full : full.map(() => new Float32Array(frames)),
          sampleRate: rate,
          timestampSeconds: fromSeconds + done / rate
        };
      }
    }
    yield block;
    yield* decoded;
  } finally {
    await decoded.return?.(void 0);
  }
}

// src/engine/audioTranscode.ts
var TARGET_CODEC = "mp4a.40.2";
var FALLBACK_CODEC = "opus";
var ENCODER_LOOKAHEAD_SECONDS = 0.3;
var PRIMING_TIMEOUT_MS = 8e3;
var KBITS_PER_CHANNEL = [96, 64, 40];
var ceilings = /* @__PURE__ */ new Map();
function bitrateLadder(channels) {
  const ceiling = ceilings.get(channels) ?? Infinity;
  const all = [...new Set(KBITS_PER_CHANNEL.map((k) => Math.max(128e3, k * 1e3 * channels)))];
  const below = all.filter((rate) => rate < ceiling);
  return below.length > 0 ? below : all.slice(-1);
}
var DECODABLE_HERE = /* @__PURE__ */ new Set([
  "A_DTS",
  "A_DTS/EXPRESS",
  "A_DTS/LOSSLESS",
  "A_AC3",
  "A_EAC3",
  // Carried untouched wherever the browser takes it (Chrome, Firefox); decoded here, by
  // libFLAC, only where it does not — Safari. See flacDecoder.ts.
  "A_FLAC",
  // No browser takes these anywhere. FFmpeg's own decoder, compiled to WebAssembly since
  // 21/09/2026 — see truehd/truehdAudio.ts.
  "A_TRUEHD",
  "A_MLP"
  // A_OPUS aussi, en mono et en stéréo seulement — voir transcodableAudio. Safari décode l'Opus
  // mais ne le prend pas dans MediaSource : 608 pistes de séries ici. Décodé par le navigateur
  // lui-même (son AudioDecoder, ownAudio.ts), ré-encodé en AAC. Au-delà de deux canaux,
  // l'ordre dans lequel le décodeur d'Apple rend un Opus multicanal n'a jamais été mesuré : ces
  // pistes (76, en 3.0) gardent leur chemin d'avant plutôt qu'un pari sur la place des voix.
]);
function audioDecoderExists(track) {
  if (audioConfigFor(track)) return true;
  if (track.codecId === "A_OPUS" || DECODABLE_HERE.has(track.codecId)) return true;
  return /^A_(AAC|MPEG\/L3|VORBIS|PCM)/.test(track.codecId);
}
function transcodableAudio(track) {
  if (track.codecId === "A_OPUS") return (track.audio?.channels ?? 2) <= 2;
  if (track.codecId === "A_AAC") return aacPlan(track.codecPrivate, { pceAccepted: effectivePceAnswer(track.codecPrivate) }).action === "decode";
  return DECODABLE_HERE.has(track.codecId);
}
function candidateConfigs(codec, sampleRate, numberOfChannels) {
  const rates = bitrateLadder(numberOfChannels);
  return codec === TARGET_CODEC ? [
    ...rates.map((bitrate) => ({ codec, sampleRate, numberOfChannels, bitrate, aac: { format: "aac" } })),
    { codec, sampleRate, numberOfChannels, aac: { format: "aac" } },
    { codec, sampleRate, numberOfChannels }
  ] : [
    ...rates.map((bitrate) => ({ codec, sampleRate, numberOfChannels, bitrate })),
    { codec, sampleRate, numberOfChannels }
  ];
}
async function firstSupported(codec, sampleRate, channels) {
  const Encoder = globalThis.AudioEncoder;
  if (!Encoder?.isConfigSupported) return null;
  for (const config of candidateConfigs(codec, sampleRate, channels)) {
    try {
      if ((await Encoder.isConfigSupported(config)).supported) return config;
    } catch {
    }
  }
  return null;
}
async function supportedConfigs(codec, sampleRate, channels) {
  const Encoder = globalThis.AudioEncoder;
  const accepted = [];
  for (const config of candidateConfigs(codec, sampleRate, channels)) {
    try {
      if ((await Encoder?.isConfigSupported(config))?.supported) accepted.push(config);
    } catch {
    }
  }
  return accepted.length > 0 ? accepted : [{ codec, sampleRate, numberOfChannels: channels }];
}
function describeRate(config) {
  return config.bitrate ? `${Math.round(config.bitrate / 1e3)} kbit/s` : "d\xE9bit laiss\xE9 au navigateur";
}
async function primeEncoder(Encoder, config, decoder, fromSeconds, outChannels) {
  let description = null;
  let encoderError = null;
  const sink = {
    frame: (_frame) => {
    },
    failed: (message) => {
      encoderError = message;
    },
    current: null
  };
  const encoder = new Encoder({
    output: (chunk, metadata) => {
      if (sink.current !== encoder) return;
      const carried = metadata?.decoderConfig?.description;
      if (carried && !description) description = toBytes(carried);
      sink.frame(toFrame(chunk));
    },
    error: (error) => {
      if (sink.current === encoder) sink.failed(error.message);
    }
  });
  sink.current = encoder;
  const close = () => {
    try {
      encoder.close();
    } catch {
    }
  };
  try {
    encoder.configure(config);
  } catch (error) {
    close();
    return { error: error instanceof Error ? error.message : String(error), timedOut: false };
  }
  trace(`transcodage audio : encodeur configur\xE9 (${config.codec}, ${describeRate(config)}), amor\xE7age \xE0 ${fromSeconds.toFixed(1)} s`);
  const primer = decoder.samples(Math.max(0, fromSeconds));
  let firstSeconds = null;
  const prime = async () => {
    while (!description && !encoderError) {
      for (let i = 0; i < 8; i++) {
        const next = await primer.next();
        if (next.done) return;
        firstSeconds ??= next.value.timestampSeconds;
        if (encoderError) return;
        encode(encoder, next.value, outChannels, config.codec);
      }
      for (let i = 0; i < 200 && encoder.encodeQueueSize > 0; i++) {
        await new Promise((resolve) => setTimeout(resolve, 5));
      }
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  };
  let timer;
  let timedOut = false;
  try {
    await Promise.race([
      prime(),
      new Promise((resolve) => {
        timer = setTimeout(() => {
          timedOut = true;
          resolve();
        }, PRIMING_TIMEOUT_MS);
      })
    ]);
  } catch (error) {
    close();
    throw error;
  } finally {
    clearTimeout(timer);
    void primer.return?.(void 0);
  }
  if (encoderError) {
    close();
    return { error: `Encodage audio refus\xE9 : ${encoderError}`, timedOut: false };
  }
  if (!description) {
    close();
    return {
      error: timedOut ? `L'encodeur audio n'a pas r\xE9pondu en ${PRIMING_TIMEOUT_MS / 1e3} s.` : "L'encodeur audio n'a pas d\xE9crit le flux qu'il produit.",
      timedOut
    };
  }
  return { encoder, description, config, sink, firstSeconds };
}
async function chooseTranscodeCodec(sampleRate, channels) {
  return (await chooseTranscodePlan(sampleRate, channels))?.codec ?? null;
}
async function chooseTranscodePlan(sampleRate, channels) {
  const first = knownLayoutAtLeast(channels);
  const wanted = [first, ...[6, 2].filter((n) => n < first)];
  for (const target of wanted) {
    for (const codec of [TARGET_CODEC, FALLBACK_CODEC]) {
      if (target > appleAacCap(codec)) continue;
      if (!containerAccepts(`audio/mp4; codecs="${codec}"`)) continue;
      if (await firstSupported(codec, sampleRate, target)) {
        chosenTarget = codec;
        const plan = { codec, channels: target };
        knownPlans.set(planKey(sampleRate, channels), plan);
        return plan;
      }
    }
  }
  knownPlans.set(planKey(sampleRate, channels), null);
  return null;
}
function knownTranscodePlan(sampleRate, channels) {
  return knownPlans.get(planKey(sampleRate, channels));
}
var knownPlans = /* @__PURE__ */ new Map();
var planKey = (sampleRate, channels) => `${sampleRate}/${channels}`;
function transcodeTargetCodec() {
  return chosenTarget;
}
var chosenTarget = TARGET_CODEC;
var AudioTranscoder = class _AudioTranscoder {
  constructor(decoder, encoder, sampleEntry, sampleRate, channels, actualCodec = "mp4a.40.2", config = { codec: actualCodec, sampleRate, numberOfChannels: channels }, renew = null, enhancer = null, firstPrimedSeconds = null) {
    this.decoder = decoder;
    this.encoder = encoder;
    this.sampleEntry = sampleEntry;
    this.sampleRate = sampleRate;
    this.channels = channels;
    this.actualCodec = actualCodec;
    this.config = config;
    this.renew = renew;
    this.enhancer = enhancer;
    this.firstPrimedSeconds = firstPrimedSeconds;
  }
  decoder;
  encoder;
  sampleEntry;
  sampleRate;
  channels;
  actualCodec;
  config;
  renew;
  enhancer;
  firstPrimedSeconds;
  generator = null;
  /** Voir `AudioTimingStats` : l'état du flux en cours, et le pire de la séance. */
  timing = { firstInUs: null, inFrames: 0, firstOutUs: null, outFrames: 0 };
  timingWorst = { sourceUs: 0, encoderUs: 0 };
  pending = [];
  lastDecodedSeconds = 0;
  exhausted = false;
  failure = null;
  /** Le vidage de fin de piste est en cours, ou déjà fait (une fois par flux) — voir `flushTail`. */
  flushingTail = false;
  tailFlushed = false;
  /** What the encoder actually produced, not what it was asked for. */
  get codecString() {
    return this.actualCodec;
  }
  /**
   * Toute la piste a été décodée, encodée et rendue : il n'y a plus rien à demander.
   *
   * C'est ce qui permet au remultiplexeur de dire que le fichier est fini — voir
   * `Remuxer.readUntilSettled`, qui ne le disait jamais tant qu'un transcodeur existait.
   */
  get drained() {
    return this.exhausted && this.pending.length === 0;
  }
  /**
   * Opens the track and gets far enough to describe it.
   *
   * The description an MP4 needs is not in the file — it is produced by the encoder, and only
   * once it has encoded something. So a little sound is pushed through here and kept, which is
   * also the earliest point at which a browser that cannot do this at all will say so.
   */
  static async open(source, track, fromSeconds = 0, unifiedChannels, file, dialogue, copiedTrack = false) {
    const Encoder = globalThis.AudioEncoder;
    if (!Encoder) throw new Error("Ce navigateur ne sait pas encoder de l'audio.");
    trace(`transcodage audio : chargement du d\xE9codeur ${track.codecId}`);
    const measuredAacDecoder = (!!dialogue && dialogue !== "off" || copiedTrack) && track.codecId === "A_AAC" && (track.audio?.channels ?? 2) > 2;
    const decoder = await SoftwareAudioTrack.open(readingAs(source, "son"), track.number, track.codecId, file, measuredAacDecoder ? { measuredAacDecoder } : {});
    let primedEncoder = null;
    try {
      return await _AudioTranscoder.build(
        Encoder,
        decoder,
        fromSeconds,
        unifiedChannels,
        (encoder) => {
          primedEncoder = encoder;
        },
        dialogue
      );
    } catch (error) {
      try {
        primedEncoder?.close();
      } catch {
      }
      try {
        decoder.close();
      } catch {
      }
      throw error;
    }
  }
  /** La suite de `open`, une fois le décodeur ouvert — séparée pour que `open` ferme tout en cas d'échec. */
  static async build(Encoder, decoder, fromSeconds, unifiedChannels, onPrimed, dialogue) {
    const { sampleRate, numberOfChannels } = decoder.format;
    trace(`transcodage audio : d\xE9codeur pr\xEAt \u2014 ${sampleRate} Hz, ${numberOfChannels} canaux`);
    const wanted = unifiedChannels ?? numberOfChannels;
    if (wanted !== numberOfChannels) {
      trace(`transcodage audio : disposition unifi\xE9e du fichier \u2014 ${numberOfChannels} canaux port\xE9s \xE0 ${wanted}`);
    }
    const plan = await chooseTranscodePlan(sampleRate, wanted);
    if (!plan) throw new Error(`Ce navigateur ne sait produire aucun codec audio en ${wanted} canaux.`);
    const target = plan.codec;
    const outChannels = plan.channels;
    if (outChannels < wanted) {
      trace(`transcodage audio : ${wanted} canaux non encodables ici, descente \xE0 ${outChannels}`);
    } else if (outChannels > wanted) {
      trace(`transcodage audio : ${wanted} canaux sans disposition connue, livr\xE9s en ${outChannels} (L R C gard\xE9s)`);
    }
    const configs = await supportedConfigs(target, sampleRate, outChannels);
    let primed = null;
    let failure = "";
    for (const config2 of configs) {
      const attempt = await primeEncoder(Encoder, config2, decoder, fromSeconds, outChannels);
      if ("encoder" in attempt) {
        primed = attempt;
        break;
      }
      failure = attempt.error;
      trace(`transcodage audio : ${describeRate(config2)} refus\xE9 \xE0 l'usage (${attempt.error})`);
      if (attempt.timedOut) break;
    }
    if (!primed) throw new Error(failure || "L'encodeur audio n'a pas d\xE9crit le flux qu'il produit.");
    const { encoder, description, sink, config, firstSeconds } = primed;
    onPrimed(encoder);
    const asc = target === TARGET_CODEC ? extractAudioSpecificConfig(description) ?? description : description;
    const actual = target === TARGET_CODEC ? parseAacConfig2(asc) : null;
    const read = target === TARGET_CODEC ? actual ? `AOT ${actual.objectType}, ${actual.sampleRate} Hz, ${actual.channels} canaux` : "illisible" : (
      // Opus says the same things in its own header: channels at byte 9, rate little-endian
      // at 12. Worth reading back for the same reason as the AAC one — the container is
      // about to state both, and it has to state what actually came out.
      `${asc[9]} canaux, ${new DataView(asc.buffer, asc.byteOffset, asc.byteLength).getUint32(12, true)} Hz`
    );
    trace(
      `transcodage audio : encodeur amorc\xE9 \u2014 description ${[...description].map((b) => b.toString(16).padStart(2, "0")).join(" ")}${asc === description ? "" : ` (config extraite : ${[...asc].map((b) => b.toString(16).padStart(2, "0")).join(" ")})`} \u2192 ${read}`
    );
    const entryRate = actual?.sampleRate ?? sampleRate;
    const entryChannels = actual?.channels || outChannels;
    const codecString = target === TARGET_CODEC ? actual ? `mp4a.40.${actual.objectType}` : TARGET_CODEC : target;
    const sampleEntry = target === TARGET_CODEC ? audioSampleEntryFor({
      codecId: "A_AAC",
      codecPrivate: asc,
      channels: entryChannels,
      sampleRate: entryRate,
      firstFrame: null
    }) : (
      // Opus describes itself with the identification header, which is not shaped like the
      // box an MP4 wants — see dOps.
      opusSampleEntry(asc, entryChannels, entryRate)
    );
    const renew = () => {
      const fresh = new Encoder({
        // Même sortie que le premier, et le même droit d'y écrire : être l'encodeur courant.
        output: (chunk) => {
          if (sink.current === fresh) sink.frame(toFrame(chunk));
        },
        error: (error) => {
          if (sink.current === fresh) sink.failed(error.message);
        }
      });
      try {
        fresh.configure(config);
      } catch (error) {
        try {
          fresh.close();
        } catch {
        }
        throw error;
      }
      sink.current = fresh;
      return fresh;
    };
    const enhancer = dialogue && dialogue !== "off" ? new DialogueEnhancer(sampleRate, outChannels, dialogue) : null;
    if (enhancer) trace(`transcodage audio : dialogues am\xE9lior\xE9s (${dialogue === "strong" ? "encore plus fort" : "normal"}) sur ${outChannels} canaux`);
    const transcoder = new _AudioTranscoder(
      decoder,
      encoder,
      sampleEntry,
      sampleRate,
      outChannels,
      codecString,
      config,
      renew,
      enhancer,
      firstSeconds
    );
    sink.frame = (frame) => transcoder.collect(frame);
    sink.failed = (message) => transcoder.fail(message);
    transcoder.seekTo(fromSeconds);
    return transcoder;
  }
  /** Restarts decoding at this point on the file's clock. */
  seekTo(seconds2) {
    void this.generator?.return?.(void 0);
    this.enhancer?.reset();
    try {
      if (this.renew) {
        const previous = this.encoder;
        this.encoder = this.renew();
        try {
          previous.close();
        } catch {
        }
      } else {
        this.encoder.reset();
        this.encoder.configure(this.config);
      }
    } catch (error) {
      this.failure ??= `Encodage audio interrompu : ${error instanceof Error ? error.message : String(error)}`;
    }
    const from = Math.max(0, seconds2);
    this.generator = withLeadSilence(
      this.decoder.samples(from),
      from,
      (gap) => trace(`transcodage audio : le son commence ${gap.toFixed(2)} s apr\xE8s l'image (${from.toFixed(1)} s) \u2014 combl\xE9 par du silence`)
    );
    this.timing = { firstInUs: null, inFrames: 0, firstOutUs: null, outFrames: 0 };
    this.pending = [];
    this.lastDecodedSeconds = seconds2;
    this.exhausted = false;
    this.tailFlushed = false;
  }
  /**
   * Every frame up to a point on the file's clock, encoded and ready to mux.
   *
   * Flushed at each boundary so a segment holds exactly its own sound. An encoder left to its own
   * schedule would hand the tail of one segment to the next, and the two would then disagree
   * about where they start.
   */
  async framesUpTo(endSeconds) {
    if (this.failure) throw new Error(this.failure);
    if (!this.generator) this.seekTo(0);
    const feedUntil = endSeconds + ENCODER_LOOKAHEAD_SECONDS;
    while (!this.exhausted && this.lastDecodedSeconds < feedUntil) {
      const next = await this.generator.next();
      if (next.done) {
        this.exhausted = true;
        break;
      }
      this.lastDecodedSeconds = next.value.timestampSeconds;
      this.noteInput(next.value);
      if (this.failure) throw new Error(this.failure);
      encode(this.encoder, next.value, this.channels, this.actualCodec, this.enhancer);
    }
    if (this.exhausted) await this.flushTail();
    else await this.drain();
    if (this.failure) throw new Error(this.failure);
    const cut = endSeconds * 1e6;
    const ready = this.pending.filter((frame) => frame.timestampUs < cut);
    this.pending = this.pending.filter((frame) => frame.timestampUs >= cut);
    return ready;
  }
  /**
   * Le dernier vidage, une fois la piste entièrement donnée à l'encodeur — et un échec n'y est pas une panne.
   *
   * Il ne rend que le reste d'une image : moins de 1024 échantillons, ~20 ms de son au tout dernier
   * instant du film. Le 08/11/2026, l'encodeur AAC de Chrome Android a refusé ce vidage
   * (« Flushing error ») à 29 s de la fin d'un film, après 1 h 36 sans accroc : le lecteur l'a
   * pris pour une panne et a passé la main au serveur pour la fin du générique. Ce qui est déjà
   * encodé est gardé, le reste est perdu, et c'est tracé. Une seule fois par flux : rien n'est plus
   * donné à l'encodeur après la fin, et un encodeur qui a échoué est fermé.
   */
  async flushTail() {
    if (this.tailFlushed) return;
    this.flushingTail = true;
    try {
      await this.encoder.flush();
    } catch (error) {
      this.tailLost(error instanceof Error ? error.message : String(error));
    } finally {
      this.flushingTail = false;
      this.tailFlushed = true;
    }
  }
  tailLost(message) {
    trace(`transcodage audio : vidage de fin de piste refus\xE9 (${message}) \u2014 le dernier reste d'image est perdu, la lecture continue`);
  }
  /** Waits for what has been handed to the encoder to come back out, without forcing a frame. */
  async drain() {
    for (let i = 0; i < 200 && this.encoder.encodeQueueSize > 0; i++) {
      await new Promise((resolve) => setTimeout(resolve, 5));
    }
  }
  /** Both called by the encoder's own callbacks, redirected here once this object exists. */
  collect(frame) {
    this.noteOutput(frame);
    this.pending.push(frame);
  }
  /** Le son décodé qui entre : son instant selon le fichier, contre ce qui a été décodé avant. */
  noteInput(decoded) {
    const at = decoded.timestampSeconds * 1e6;
    const frames = decoded.planes[0]?.length ?? 0;
    const rate = decoded.sampleRate || this.sampleRate;
    const timing = this.timing;
    if (timing.firstInUs === null) timing.firstInUs = at;
    const drift = at - timing.firstInUs - timing.inFrames * 1e6 / rate;
    if (Math.abs(drift) > Math.abs(this.timingWorst.sourceUs)) this.timingWorst.sourceUs = drift;
    timing.inFrames += frames;
  }
  /** Une image encodée qui sort : son instant selon l'encodeur, contre ce qu'il a rendu avant. */
  noteOutput(frame) {
    const timing = this.timing;
    if (timing.firstOutUs === null) timing.firstOutUs = frame.timestampUs;
    const drift = frame.timestampUs - timing.firstOutUs - timing.outFrames * 1e6 / this.sampleRate;
    if (Math.abs(drift) > Math.abs(this.timingWorst.encoderUs)) this.timingWorst.encoderUs = drift;
    timing.outFrames += Math.round((frame.durationUs || 0) * this.sampleRate / 1e6);
  }
  /** Le pire écart de la séance, pour le journal — voir `AudioTimingStats`. */
  get timingStats() {
    return { ...this.timingWorst };
  }
  closed = false;
  fail(message) {
    if (this.flushingTail) return;
    this.failure = `Encodage audio interrompu : ${message}`;
    if (this.config.bitrate) ceilings.set(this.channels, Math.min(ceilings.get(this.channels) ?? Infinity, this.config.bitrate));
  }
  /**
   * Releases the decoder and the encoder. Safe to call twice.
   *
   * The decoder's close was unguarded while the encoder's was: closing an already-closed decoder
   * throws, and the throw happened *before* the encoder was reached — so a second close, or a
   * close after the decoder had already failed, leaked an encoder that nothing would ever come
   * back for. Both are guarded now, and each is only ever asked once.
   */
  close() {
    if (this.closed) return;
    this.closed = true;
    void this.generator?.return?.(void 0);
    try {
      this.decoder.close();
    } catch {
    }
    try {
      this.encoder.close();
    } catch {
    }
  }
};
function toBytes(source) {
  const view = ArrayBuffer.isView(source) ? new Uint8Array(source.buffer, source.byteOffset, source.byteLength) : new Uint8Array(source);
  return view.slice();
}
function toFrame(chunk) {
  const data = new Uint8Array(chunk.byteLength);
  chunk.copyTo(data);
  return { data, timestampUs: chunk.timestamp, durationUs: chunk.duration ?? 0 };
}
var KNOWN_LAYOUTS = /* @__PURE__ */ new Set([1, 2, 3, 6, 8]);
function knownLayoutAtLeast(channels) {
  if (KNOWN_LAYOUTS.has(channels)) return channels;
  return [...KNOWN_LAYOUTS].find((known) => known > channels) ?? 8;
}
var HALF_POWER = Math.SQRT1_2;
function frontOnly(planes) {
  return planes.slice(0, 3);
}
function fold(planes, to) {
  const from = planes.length;
  if (!KNOWN_LAYOUTS.has(from)) return fold(frontOnly(planes), to);
  if (to === from) return planes;
  if (to > from) {
    const frames = planes[0]?.length ?? 0;
    const silence = (count) => Array.from({ length: count }, () => new Float32Array(frames));
    if (from === 1) return [planes[0], planes[0], ...silence(to - 2)];
    return [...planes, ...silence(to - from)];
  }
  const [L, R, C, , Ls, Rs, Lrs, Rrs] = planes;
  const mix = (...parts) => {
    const out = new Float32Array(planes[0].length);
    for (let i = 0; i < out.length; i++) {
      let sum = 0;
      for (const [plane, gain] of parts) if (plane) sum += plane[i] * gain;
      out[i] = sum;
    }
    return out;
  };
  if (from === 8 && to === 6) {
    return [L, R, C, planes[3], mix([Ls, HALF_POWER], [Lrs, HALF_POWER]), mix([Rs, HALF_POWER], [Rrs, HALF_POWER])];
  }
  if (to === 2) {
    const back = from >= 8 ? [[Lrs, 0.5], [Rrs, 0.5]] : [];
    return [
      mix([L, 1], [C, HALF_POWER], [Ls, HALF_POWER], ...back.slice(0, 1)),
      mix([R, 1], [C, HALF_POWER], [Rs, HALF_POWER], ...back.slice(1, 2))
    ];
  }
  return planes.slice(0, to);
}
var AAC_ORDER = {};
var APPLE_AAC_ORDER = {
  // [L,R,C] → [C,L,R]
  3: [2, 0, 1],
  // [L,R,C,LFE,Ls,Rs] → [C,L,R,Ls,Rs,LFE]
  6: [2, 0, 1, 4, 5, 3]
};
function appleAacCap(codec) {
  return codec === TARGET_CODEC && appleAudioToolbox() ? 6 : Infinity;
}
function orderFor(codec) {
  if (codec.startsWith("mp4a.")) return appleAudioToolbox() ? APPLE_AAC_ORDER : AAC_ORDER;
  return null;
}
function toCodecChannelOrder(planes, codec) {
  const table = orderFor(codec);
  const order = table?.[planes.length];
  if (!order) return planes;
  return order.map((from) => planes[from]);
}
function encode(encoder, decoded, outChannels, codec, enhancer = null) {
  const folded = outChannels ? fold(decoded.planes, outChannels) : decoded.planes;
  const shaped = enhancer ? enhancer.process(folded) : folded;
  const planes = toCodecChannelOrder(shaped, codec);
  const channels = planes.length;
  const frames = planes[0]?.length ?? 0;
  if (frames === 0) return;
  const interleaved = new Float32Array(frames * channels);
  for (let channel = 0; channel < channels; channel++) {
    const plane = planes[channel];
    for (let i = 0; i < frames; i++) interleaved[i * channels + channel] = plane[i];
  }
  const data = new AudioData({
    format: "f32",
    sampleRate: decoded.sampleRate,
    numberOfFrames: frames,
    numberOfChannels: channels,
    timestamp: Math.round(decoded.timestampSeconds * 1e6),
    data: interleaved
  });
  try {
    encoder.encode(data);
  } finally {
    data.close();
  }
}

// src/engine/decodeOrder.ts
function assignDecodeTimes(samples, startDecodeTime) {
  if (samples.length === 0) return { samples: [], presentationDelay: 0, endDecodeTime: startDecodeTime };
  const sortedPresentation = samples.map((s) => s.presentation).sort((a, b) => a - b);
  const origin = sortedPresentation[0];
  const decodeTimes = [];
  let previous = -Infinity;
  for (let i = 0; i < samples.length; i++) {
    const decode = Math.max(startDecodeTime + (sortedPresentation[i] - origin), previous + 1);
    decodeTimes.push(decode);
    previous = decode;
  }
  const out = samples.map((sample, i) => ({
    decode: decodeTimes[i],
    compositionOffset: startDecodeTime + (sample.presentation - origin) - decodeTimes[i],
    duration: sample.duration
  }));
  const delay = Math.max(0, ...out.map((sample) => -sample.compositionOffset));
  let latest = 0;
  for (let i = 1; i < samples.length; i++) {
    if (samples[i].presentation > samples[latest].presentation) latest = i;
  }
  return {
    samples: out,
    presentationDelay: delay,
    endDecodeTime: decodeTimes[decodeTimes.length - 1] + samples[latest].duration
  };
}
function deriveDurations(presentationTimes, fallbackDuration) {
  if (presentationTimes.length === 0) return [];
  const sorted = [...presentationTimes].sort((a, b) => a - b);
  const gaps = [];
  for (let i = 0; i < sorted.length - 1; i++) gaps.push(sorted[i + 1] - sorted[i]);
  const typical = gaps.length > 0 ? median(gaps) : fallbackDuration;
  const byPresentation = /* @__PURE__ */ new Map();
  for (let i = 0; i < sorted.length; i++) {
    byPresentation.set(sorted[i], i < sorted.length - 1 ? sorted[i + 1] - sorted[i] : typical);
  }
  return presentationTimes.map((pts) => byPresentation.get(pts) ?? typical);
}
function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? Math.round((sorted[middle - 1] + sorted[middle]) / 2) : sorted[middle];
}

// src/engine/subtitleMarkup.ts
function stripSubtitleMarkup(text, options = {}) {
  const align = /\\an([1-9])/i.exec(text.match(/\{[^}]*\}/g)?.join("") ?? "")?.[1];
  const clean = text.replace(/<[^>]*>/g, "").replace(options.allBraces ? /\{[^}]*\}/g : /\{\\[^}]*\}/g, "");
  return align && align !== "2" && clean.trim() ? `{\\an${align}}${clean}` : clean;
}
function subtitlePlacement(text) {
  const match = /^\{\\an([1-9])\}/.exec(text);
  if (!match) return { text, top: false };
  return { text: text.slice(match[0].length), top: ["7", "8", "9"].includes(match[1]) };
}
var MAX_SIMULTANEOUS_CUES = 2;
function simultaneousText(covering) {
  if (covering.length === 0) return null;
  if (covering.length === 1) return covering[0].text;
  const seen = /* @__PURE__ */ new Set();
  const distinct = [...covering].sort((a, b) => a.startSeconds - b.startSeconds).filter((cue) => seen.has(cue.text) ? false : (seen.add(cue.text), true));
  const shown = distinct.slice(0, MAX_SIMULTANEOUS_CUES);
  const placed = shown.map((cue) => subtitlePlacement(cue.text));
  const text = placed.map((line) => line.text).join("\n");
  return placed.every((line) => line.top) ? `{\\an8}${text}` : text;
}
var TEXT_SUBTITLE_CODECS = /* @__PURE__ */ new Set(["S_TEXT/UTF8", "S_TEXT/ASCII", "S_TEXT/ASS", "S_TEXT/SSA"]);
function subtitleText(raw, codecId) {
  if (codecId !== "S_TEXT/ASS" && codecId !== "S_TEXT/SSA") {
    return stripSubtitleMarkup(raw).trim();
  }
  const fields = raw.split(",");
  const text = fields.length > 8 ? fields.slice(8).join(",") : raw;
  return stripSubtitleMarkup(text.replace(/\\N/gi, "\n").replace(/\\h/gi, " "), { allBraces: true }).trim();
}

// src/engine/remuxer.ts
var TIMESCALE = 1e6;
var SEGMENT_US = 2e6;
var MAX_ENCODER_RESTARTS = 3;
var GOOD_SEGMENTS_TO_FORGIVE = 30;
var INDEX_BACKUP_US = 12e6;
var MAX_INDEX_BACKUPS = 3;
var FRAGMENT_BYTES = 12e5;
var FRAGMENT_SAMPLES = 60;
var REORDER_LOOKAHEAD_GUESS = 64;
var REORDER_LOOKAHEAD_MARGIN = 4;
var FALLBACK_FRAME_US = 41667;
var DELAY_MARGIN_FRAMES = 3;
var FALLBACK_AUDIO_FRAME_US = 32e3;
var SUBTITLE_FALLBACK_SECONDS = 3;
function aacCodecString(codecPrivate) {
  const objectType = codecPrivate && codecPrivate.length > 0 ? codecPrivate[0] >> 3 : 2;
  return `mp4a.40.${objectType === 31 ? 2 : objectType}`;
}
function audioCodecString(track) {
  switch (track.codecId) {
    case "A_AAC":
      return aacCodecString(track.codecPrivate);
    case "A_FLAC":
      return "flac";
    case "A_AC3":
      return "ac-3";
    case "A_EAC3":
      return "ec-3";
    // Copié tel quel depuis le 11/10/2026 là où le navigateur le prend : avant, un Opus stéréo était
    // décodé puis ré-encodé en AAC partout (seconde génération avec perte, calcul sur l'appareil),
    // et un Opus multicanal partait au lecteur serveur. Un en-tête illisible garde ce chemin-là.
    case "A_OPUS":
      return opusCopyConsidered() && isOpusHead(track.codecPrivate) ? "opus" : null;
    default:
      return null;
  }
}
function videoCodecString(track) {
  if (!track.codecPrivate) return null;
  if (track.codecId === "V_MPEGH/ISO/HEVC") return hevcCodecString(track.codecPrivate);
  if (track.codecId === "V_MPEG4/ISO/AVC") return avcCodecString(track.codecPrivate);
  if (track.codecId === "V_AV1") return av1CodecString(track.codecPrivate);
  return null;
}
function plannedMimeTypes(videoTrack, audioTrack, file, options) {
  const video = videoCodecString(videoTrack);
  const audio = !audioTrack ? null : audioDelivery(audioTrack, file, options) === "transcode" ? TRANSCODED_CODEC() : audioCodecString(audioTrack);
  return {
    video: video ? `video/mp4; codecs="${video}"` : null,
    audio: audio ? `audio/mp4; codecs="${audio}"` : null
  };
}
function remuxableVideo(track) {
  return videoCodecString(track) !== null;
}
function trackAacPlan(track) {
  if (track.codecId !== "A_AAC") return { action: "copy" };
  const pceAccepted = effectivePceAnswer(track.codecPrivate);
  const plan = aacPlan(track.codecPrivate, { pceAccepted });
  if (plan.action === "decode" && pceAccepted === null) primePceProbe();
  return plan;
}
function copiedAsc(track) {
  resetPceCopyState();
  if (track.codecId === "A_AAC" && parseAacConfig(track.codecPrivate)?.pce) {
    const plan = trackAacPlan(track);
    notePceDecision(plan.action, plan.action === "copy", track.codecPrivate);
  }
  return rewrittenAsc(track) ?? track.codecPrivate;
}
function rewrittenAsc(track) {
  const plan = trackAacPlan(track);
  return plan.action === "rewrite" ? plan.asc : null;
}
function naturalDelivery(track) {
  const natural = audioCodecString(track);
  const copyable = track.codecId !== "A_AAC" || trackAacPlan(track).action !== "decode";
  if (natural && copyable && containerAccepts(`audio/mp4; codecs="${natural}"`)) return "copy";
  return transcodableAudio(track) ? "transcode" : "none";
}
var DEFAULT_PER_TRACK = true;
var perTrackOf = (options) => options?.perTrack ?? DEFAULT_PER_TRACK;
function cappedColour(colour, cap) {
  if (!colour || cap === null) return colour;
  const pq = colour.transferCharacteristics === 16;
  return {
    ...colour,
    ...colour.maxContentLightNits ? colour.maxContentLightNits > cap ? { maxContentLightNits: cap } : {} : pq ? { maxContentLightNits: cap } : {},
    ...colour.maxFrameAverageNits ? colour.maxFrameAverageNits > cap ? { maxFrameAverageNits: cap } : {} : pq ? { maxFrameAverageNits: cap } : {},
    ...colour.masteringMaxNits && colour.masteringMaxNits > cap ? { masteringMaxNits: cap } : {}
  };
}
var TRANSCODED_CODEC = () => transcodeTargetCodec();
function unifiedAudioCodec(file, options) {
  if (perTrackOf(options)) return null;
  const audio = file.tracks.filter((t) => t.type === "audio" && naturalDelivery(t) !== "none");
  if (audio.length < 2) return null;
  const delivered = new Set(
    audio.map((t) => naturalDelivery(t) === "copy" ? audioCodecString(t) : TRANSCODED_CODEC())
  );
  if (delivered.size < 2) return null;
  return audio.every((t) => audioCodecString(t) === TRANSCODED_CODEC() || transcodableAudio(t)) ? TRANSCODED_CODEC() : null;
}
function unifiedAudioChannels(file, options) {
  const perTrack = perTrackOf(options);
  const carried = file.tracks.filter(
    (t) => t.type === "audio" && (perTrack ? naturalDelivery(t) === "transcode" : naturalDelivery(t) !== "none")
  );
  if (carried.length < 2) return null;
  const counts = carried.map((t) => t.audio?.channels ?? 1);
  const max = Math.max(...counts);
  return counts.some((n) => n !== max) ? max : null;
}
function audioDelivery(track, file, options) {
  const delivery = fileAudioDelivery(track, file, options);
  if (delivery === "copy" && options?.dialogue && options.dialogue !== "off" && dialogueCanShape(track)) return "transcode";
  return delivery;
}
function dialogueCanShape(track) {
  const channels = track.audio?.channels ?? 2;
  if (track.codecId === "A_AAC") {
    const config = parseAacConfig(track.codecPrivate);
    if (config?.pce) return false;
    return channels <= 2 || channels === 6 && config?.channelConfiguration === 6;
  }
  if (track.codecId === "A_OPUS") return channels <= 3 || channels === 6 && geckoEngine();
  return DIALOGUE_DECODERS.has(track.codecId);
}
var DIALOGUE_DECODERS = /* @__PURE__ */ new Set(["A_AC3", "A_EAC3", "A_DTS", "A_DTS/EXPRESS", "A_DTS/LOSSLESS", "A_TRUEHD", "A_MLP", "A_FLAC"]);
function fileAudioDelivery(track, file, options) {
  const natural = naturalDelivery(track);
  if (!file || natural === "none") return natural;
  const unified = unifiedAudioCodec(file, options);
  if (!unified) return natural;
  if (natural === "copy" && audioCodecString(track) === unified) return "copy";
  return "transcode";
}
function playableAudio(track) {
  return audioDelivery(track) !== "none";
}
function deliveredAudio(track) {
  const delivery = audioDelivery(track);
  const aac = trackAacPlan(track);
  const pceKept = aac.action === "decode" ? aac.channels : Infinity;
  const source = Math.min(track.audio?.channels ?? 1, pceKept);
  if (delivery !== "transcode") return { copied: delivery === "copy", channels: source };
  const plan = knownTranscodePlan(track.audio?.sampleRate ?? 48e3, source);
  return { copied: false, channels: plan ? Math.min(source, plan.channels) : source };
}
async function primeAudioDelivery(file) {
  for (const track of file.tracks) {
    if (track.type !== "audio" || audioDelivery(track) !== "transcode") continue;
    try {
      await chooseTranscodePlan(track.audio?.sampleRate ?? 48e3, track.audio?.channels ?? 1);
    } catch {
    }
  }
}
function probeOffset(file, startSeconds, videoTrackNumber, start) {
  if (startSeconds <= 0) return start;
  return clusterOffsetForTime(file, Math.round(startSeconds * 1e6), videoTrackNumber) ?? start;
}
var PROBE_SAMPLES = 2e4;
async function probeTrackStart(source, file, from, track, videoTrackNumber) {
  const probe = createSampleReader(source, file, from);
  let firstVideoUs = null;
  for (let i = 0; i < PROBE_SAMPLES; i++) {
    const sample = await probe.next();
    if (!sample) break;
    if (sample.trackNumber === track.number) return { frame: sample.data, firstAudioUs: sample.timestampUs, firstVideoUs };
    if (firstVideoUs === null && sample.trackNumber === videoTrackNumber) firstVideoUs = sample.timestampUs;
  }
  return { frame: null, firstAudioUs: null, firstVideoUs };
}
async function describeAudio(source, file, start, track, preferred = start, firstPass = null) {
  let firstFrame = null;
  if (track.codecId === "A_AC3" || track.codecId === "A_EAC3") {
    for (const from of preferred === start ? [start] : [preferred, start]) {
      const found = from === preferred && firstPass ? firstPass : await probeTrackStart(source, file, from, track, null);
      firstFrame = found.frame;
      if (firstFrame) break;
    }
    if (!firstFrame) throw new Error("Aucune trame audio trouv\xE9e pour d\xE9crire la piste AC-3.");
  }
  return {
    id: 2,
    kind: "audio",
    timescale: TIMESCALE,
    sampleEntry: audioSampleEntryFor({
      codecId: track.codecId,
      // Un PCE équivalent à une configuration standard part réécrit ; les trames, elles, sont
      // copiées telles quelles (DECISIONS.md §62, couche 2).
      codecPrivate: copiedAsc(track),
      channels: track.audio?.channels ?? 2,
      sampleRate: track.audio?.sampleRate ?? 48e3,
      firstFrame
    }),
    width: 0,
    height: 0,
    language: track.language ?? "und"
  };
}
function assertContainerTakes(transcoder) {
  const mime = `audio/mp4; codecs="${transcoder.codecString}"`;
  if (containerAccepts(mime)) return;
  transcoder.close();
  throw new Error(`Ce navigateur produit un AAC qu'il n'accepte pas lui-m\xEAme : ${mime}`);
}
function reorderLookahead(delayUs, frameUs) {
  if (delayUs === null || frameUs === null) return REORDER_LOOKAHEAD_GUESS;
  const depth = Math.ceil(delayUs / Math.max(1, frameUs));
  return Math.min(REORDER_LOOKAHEAD_GUESS, depth + REORDER_LOOKAHEAD_MARGIN);
}
function planFragments(count, byteLengthOf) {
  const fragments = [];
  let from = 0;
  while (from < count) {
    let to = from;
    let bytes = 0;
    do {
      bytes += byteLengthOf(to);
      to += 1;
    } while (to < count && to - from < FRAGMENT_SAMPLES && bytes < FRAGMENT_BYTES);
    fragments.push(Array.from({ length: to - from }, (_, i) => from + i));
    from = to;
  }
  return fragments;
}
function sameShape(a, b) {
  return a.sampleRate === b.sampleRate && a.channels === b.channels;
}
function transcodedAudioInfo(transcoder, track) {
  return {
    id: 2,
    kind: "audio",
    timescale: TIMESCALE,
    sampleEntry: transcoder.sampleEntry,
    width: 0,
    height: 0,
    language: track.language ?? "und"
  };
}
var Remuxer = class _Remuxer {
  constructor(file, videoTrack, audioTrack, videoInfo, audioInfo, reader, source, transcoder, dolbyVisionCodec = null, settings = {
    perTrack: DEFAULT_PER_TRACK,
    lightCapNits: null,
    dialogue: "off"
  }) {
    this.file = file;
    this.videoTrack = videoTrack;
    this.audioTrack = audioTrack;
    this.videoInfo = videoInfo;
    this.audioInfo = audioInfo;
    this.reader = reader;
    this.source = source;
    this.transcoder = transcoder;
    this.dolbyVisionCodec = dolbyVisionCodec;
    this.settings = settings;
    this.nalLength = nalLengthSize(videoTrack.codecId, videoTrack.codecPrivate);
  }
  file;
  videoTrack;
  audioTrack;
  videoInfo;
  audioInfo;
  reader;
  source;
  transcoder;
  dolbyVisionCodec;
  settings;
  pendingVideo = [];
  pendingAudio = [];
  /** Units of a block with no picture, waiting to open the next picture. See strayUnits. */
  strayAhead = [];
  /**
   * Where the last segment's decode timeline ended. Reporting only: decode times are absolute,
   * anchored per segment on its own earliest picture, so nothing is chained off this.
   */
  videoDecodeTime = 0;
  encoderRestarts = 0;
  /** Segments de son produits sans échec depuis la dernière reconstruction — voir GOOD_SEGMENTS_TO_FORGIVE. */
  goodSegments = 0;
  /**
   * Fermé : plus rien ne s'ouvre au nom de cet objet.
   *
   * Un segment en cours pendant `close()` échouait sur l'encodeur fermé, et `retryTranscoder`
   * ouvrait alors un transcodeur **neuf** — un décodeur (pour le TrueHD, un contexte WebAssembly)
   * et un AudioEncoder, dont le navigateur n'accorde qu'un nombre fixe —, installé sur un
   * remultiplexeur que plus personne ne fermerait.
   */
  closed = false;
  /** La fin du son ré-encodé a été demandée, à la fin du fichier — voir nextSegment. */
  tailDone = false;
  /** How many of the current group's pictures have already been handed over. */
  emitted = 0;
  /** The picture that closes the current group and opens the next one. */
  boundary = null;
  /** Whether the current group's last picture has been read. */
  groupClosed = false;
  /** The group's own earliest presentation, fixed once enough of it has been read. */
  groupAnchorUs = null;
  /** The typical gap between pictures, for turning a reordering delay into a count of them. */
  frameDurationUs = null;
  /** Where a seek asked to be, while the reader is still looking for somewhere to start. */
  seekTargetUs = null;
  backupsLeft = 0;
  /** Read once from the codec's configuration record; see nalLengthSize. */
  nalLength;
  /**
   * Whether a decoder may start on this picture — which is not the same question as whether the
   * container called it a keyframe. See isRandomAccessPoint.
   */
  /**
   * A block that is not a picture, returned to the pictures it was cut from: its suffix units
   * close the last picture read, provided it has not been handed over yet — it virtually never
   * has, since the last few always wait on the reordering depth — and the rest opens the next.
   */
  putBack(stray) {
    const last2 = this.pendingVideo.length - 1;
    if (stray.before.length > 0 && last2 >= this.emitted) {
      const previous = this.pendingVideo[last2];
      this.pendingVideo[last2] = { ...previous, data: joinBytes([previous.data, ...stray.before]) };
    }
    this.strayAhead.push(...stray.after);
  }
  startsHere(sample) {
    return sample.isKey && isRandomAccessPoint(sample.data, this.videoTrack.codecId, this.nalLength);
  }
  presentationDelayUs = null;
  audioFrameUs = null;
  /**
   * La fin du dernier bloc audio remis, horloge du lecteur — le plancher du suivant. Oubliée à
   * chaque relecture (saut, recul faute d'index) : ce qui est lu ensuite ne suit plus rien.
   */
  audioEndUs = null;
  subtitleNumbersCache = null;
  /** Where the segment being built actually starts, on the file's clock. */
  segmentStartUs = 0;
  /** A seek the transcoder still owes, deferred until that start is known. */
  /**
   * Vrai d'emblée depuis le 22/09/2026 : le transcodeur est amorcé là où la lecture doit commencer
   * (voir `Remuxer.open`), mais la vidéo, elle, part du début quand le fichier n'a pas d'index —
   * aucun saut n'est alors demandé, et le son restait une heure en avance sur l'image, muet. Le
   * premier segment recale donc toujours le son sur son propre début.
   */
  transcoderSeekPending = true;
  videoCuePointsCache = null;
  needKeyframe = false;
  /**
   * Juste après la clé où la lecture a repris : les images RASL qui la suivent sont écartées, et
   * seulement celles-là — voir `isRaslPicture`. Retombe à la première image qui n'en est pas une.
   */
  dropLeading = false;
  /** Les RASL écartées depuis la dernière reprise, pour la trace. */
  leadingDropped = 0;
  /** Le son de la piste commence après l'image, et ce qu'on en a fait — voir `audioLeadGap` (§148). */
  leadGap = null;
  /**
   * Une piste que le navigateur prendrait telle quelle, ré-encodée pour combler un son en retard
   * (§148) : le transcodeur qui remplace un encodeur en échec doit s'ouvrir de la même façon.
   */
  decodesCopiedTrack = false;
  pendingSubtitles = [];
  clampedSamples = 0;
  sequence = 1;
  done = false;
  /**
   * Où une lecture bornée s'arrête (horloge du fichier, µs) : juste avant la première image clé à
   * cet instant ou après — voir `seekTo`. Null : jusqu'à la fin du fichier.
   */
  stopAtUs = null;
  stopReached = false;
  static async open(source, file, videoTrack, audioTrack, dimensions, dolbyVision = null, startSeconds = 0, options = {}) {
    const settings = { perTrack: perTrackOf(options), lightCapNits: options.lightCapNits ?? null, dialogue: options.dialogue ?? "off" };
    if (!remuxableVideo(videoTrack)) throw new Error(`Vid\xE9o non remultiplexable : ${videoTrack.codecId}`);
    if (audioTrack && !playableAudio(audioTrack)) throw new Error(`Audio non remultiplexable : ${audioTrack.codecId}`);
    const start = file.firstClusterOffset ?? file.segmentDataStart;
    const delivery = audioTrack ? audioDelivery(audioTrack, file, settings) : "none";
    let transcoder = audioTrack && delivery === "transcode" ? await AudioTranscoder.open(source, audioTrack, startSeconds, unifiedAudioChannels(file, settings) ?? void 0, file, settings.dialogue) : null;
    if (transcoder) assertContainerTakes(transcoder);
    const primedFirst = transcoder?.firstPrimedSeconds;
    let leadGap = null;
    if (typeof primedFirst === "number" && audioLeadGapSeconds(Math.max(0, startSeconds), primedFirst) !== null) {
      const readFromUs = startSeconds > 0 ? cueTimeAtOrBefore(file, Math.round(startSeconds * 1e6), videoTrack.number) ?? 0 : 0;
      leadGap = { gapS: primedFirst - readFromUs / TIMESCALE, action: "silence" };
    }
    const preferred = probeOffset(file, startSeconds, videoTrack.number, start);
    let firstPass = null;
    let decodesCopiedTrack = false;
    if (audioTrack && delivery === "copy" && dialogueCanShape(audioTrack)) {
      firstPass = await probeTrackStart(source, file, preferred, audioTrack, videoTrack.number);
      const seen = firstPass.firstAudioUs !== null && firstPass.firstVideoUs !== null ? audioLeadGapSeconds(firstPass.firstVideoUs / TIMESCALE, firstPass.firstAudioUs / TIMESCALE) : null;
      if (seen !== null) rememberLeadGap(file, audioTrack.number, seen);
      const gapS = seen ?? (firstPass.firstAudioUs !== null ? rememberedLeadGap(file, audioTrack.number) : void 0) ?? null;
      if (gapS !== null) {
        trace(
          seen !== null ? `son en retard : la piste ${audioTrack.number} (${audioTrack.codecId}) commence ${gapS.toFixed(2)} s apr\xE8s l'image \u2014 r\xE9-encod\xE9e pour combler par du silence` : `son en retard : la piste ${audioTrack.number} commence tard dans ce fichier (vu plus t\xF4t sur cette page) \u2014 r\xE9-encod\xE9e pour pouvoir y revenir`
        );
        try {
          transcoder = await AudioTranscoder.open(source, audioTrack, startSeconds, unifiedAudioChannels(file, settings) ?? void 0, file, settings.dialogue, true);
          assertContainerTakes(transcoder);
          decodesCopiedTrack = true;
          leadGap = { gapS, action: "silence" };
        } catch (error) {
          if (isReadAbandoned(error) || isNetworkFailure(error)) throw error;
          transcoder = null;
          leadGap = { gapS, action: "enjamb\xE9" };
          trace(`son en retard : r\xE9-encodage impossible (${error instanceof Error ? error.message : String(error)}) \u2014 copi\xE9 tel quel, trou enjamb\xE9`);
        }
      }
    }
    const audioInfo = audioTrack ? transcoder ? transcodedAudioInfo(transcoder, audioTrack) : await describeAudio(source, file, start, audioTrack, preferred, firstPass) : null;
    const reader = createSampleReader(source, file, start, { unreadable: "throw" });
    const videoInfo = {
      id: 1,
      kind: "video",
      timescale: TIMESCALE,
      sampleEntry: videoSampleEntry(
        videoTrack.codecId,
        videoTrack.codecPrivate,
        dimensions.width,
        dimensions.height,
        dolbyVision,
        cappedColour(videoTrack.video?.colour, settings.lightCapNits)
      ),
      width: dimensions.width,
      height: dimensions.height,
      language: videoTrack.language ?? "und"
    };
    const remuxer = new _Remuxer(
      file,
      videoTrack,
      audioTrack,
      videoInfo,
      audioInfo,
      reader,
      source,
      transcoder,
      dolbyVision ? dolbyVisionCodecString(dolbyVision.record) : null,
      settings
    );
    remuxer.leadGap = leadGap;
    remuxer.decodesCopiedTrack = decodesCopiedTrack;
    return remuxer;
  }
  /**
   * Le son de la piste ouverte commence après l'image, et ce que ce pipeline en a fait — `null` pour
   * tout fichier ordinaire. Pour la ligne `start` (DECISIONS.md §148).
   */
  audioLeadGap() {
    return this.leadGap;
  }
  plan() {
    const duration = this.file.durationSeconds ?? 0;
    return {
      videoMimeType: `video/mp4; codecs="${this.dolbyVisionCodec ?? videoCodecString(this.videoTrack)}"`,
      // Once there is a transcoder, it is the authority on what the audio buffer will carry:
      // `plannedMimeTypes` has to guess before one exists, and an encoder is free to answer with
      // a different profile than the one asked for.
      audioMimeType: !this.audioTrack ? null : this.transcoder ? `audio/mp4; codecs="${this.transcoder.codecString}"` : plannedMimeTypes(this.videoTrack, this.audioTrack, this.file, this.settings).audio,
      videoInit: initSegment(this.videoInfo, duration),
      audioInit: this.audioInfo ? initSegment(this.audioInfo, duration) : null,
      durationSeconds: duration
    };
  }
  /** Whether the file carries an index. Without one there is no way to reach a time directly. */
  get seekable() {
    return this.file.cues.length > 0;
  }
  /** Index entries that actually point at pictures, which is what a seek needs. */
  get videoCuePoints() {
    if (this.videoCuePointsCache === null) {
      this.videoCuePointsCache = this.file.cues.filter((cue) => cue.track === this.videoTrack.number).length;
    }
    return this.videoCuePointsCache;
  }
  /**
   * L'image clé indexée qui suit cet instant, sur l'horloge du fichier, ou null — voir
   * `cueTimeAfter`. Ce que `MseSource` vise quand redemander la même position n'a rien donné.
   */
  keyframeAfter(seconds2) {
    const us = cueTimeAfter(this.file, Math.round(seconds2 * 1e6), this.videoTrack.number);
    return us === null ? null : us / 1e6;
  }
  /**
   * Le premier point d'index vidéo dont la grappe commence au-delà de cet octet, en secondes sur
   * l'horloge du fichier, ou null : où un saut retrouve du film après une zone illisible (§93).
   */
  resumeAfterByte(byteOffset) {
    const own = this.file.cues.filter((cue) => cue.track === this.videoTrack.number);
    let best = null;
    for (const cue of own.length > 0 ? own : this.file.cues) {
      if (cue.clusterOffset > byteOffset && (best === null || cue.timeUs < best)) best = cue.timeUs;
    }
    return best === null ? null : best / 1e6;
  }
  /** L'image clé indexée à cet instant ou avant, sur l'horloge du fichier, ou null. */
  keyframeAtOrBefore(seconds2) {
    const us = cueTimeAtOrBefore(this.file, Math.round(seconds2 * 1e6), this.videoTrack.number);
    return us === null ? null : us / 1e6;
  }
  /** The subtitle tracks this path can render — the text ones; styled formats are not handled. */
  subtitleTracks() {
    return this.file.tracks.filter(
      (t) => t.type === "subtitle" && t.isEnabled && TEXT_SUBTITLE_CODECS.has(t.codecId)
    );
  }
  audioTracks() {
    return this.file.tracks.filter((t) => t.type === "audio");
  }
  /** Releases the decoder and encoder a transcoded track holds. */
  close() {
    this.closed = true;
    if (this.transcoder) this.retiredTiming.push(this.transcoder.timingStats);
    this.transcoder?.close();
    this.transcoder = null;
  }
  /**
   * Le pire écart d'horloge du son ré-encodé sur la séance, en millisecondes — voir
   * `AudioTimingStats`. Additionne ce qu'ont vu les transcodeurs déjà remplacés (changement de
   * piste, reprise après un échec) à celui qui tourne.
   */
  audioTiming() {
    const all = [...this.retiredTiming, ...this.transcoder ? [this.transcoder.timingStats] : []];
    if (all.length === 0) return null;
    const worst = (pick) => all.map(pick).reduce((a, b) => Math.abs(b) > Math.abs(a) ? b : a, 0);
    return {
      sourceMs: Math.round(worst((t) => t.sourceUs) / 100) / 10,
      encoderMs: Math.round(worst((t) => t.encoderUs) / 100) / 10
    };
  }
  retiredTiming = [];
  diagnostics() {
    return {
      presentationDelaySeconds: (this.presentationDelayUs ?? 0) / TIMESCALE,
      clampedSamples: this.clampedSamples,
      transcodedAudio: this.transcoder !== null,
      transcodedCodec: this.transcoder?.codecString ?? null,
      segmentStartSeconds: this.segmentStartUs / TIMESCALE
    };
  }
  /**
   * Restarts at the cluster containing this time. The caller must clear its source buffers.
   *
   * @param seconds a time on the *source's* clock. A caller working from the player's clock has
   *   to subtract `presentationDelaySeconds` first.
   */
  seekTo(seconds2, stopAt = null) {
    this.stopAtUs = stopAt === null ? null : Math.round(stopAt * 1e6);
    this.stopReached = false;
    const from = this.offsetFor(seconds2);
    this.reader.seekTo(from);
    this.source.warm?.(from);
    this.transcoderSeekPending = this.transcoder !== null;
    this.pendingVideo = [];
    this.pendingAudio = [];
    this.audioEndUs = null;
    this.pendingSubtitles = [];
    this.strayAhead = [];
    this.emitted = 0;
    this.boundary = null;
    this.groupClosed = false;
    this.groupAnchorUs = null;
    this.needKeyframe = true;
    this.dropLeading = false;
    this.seekTargetUs = Math.round(seconds2 * 1e6);
    this.backupsLeft = MAX_INDEX_BACKUPS;
    this.done = false;
    this.tailDone = false;
    this.videoDecodeTime = Math.round(seconds2 * TIMESCALE);
  }
  /**
   * La lecture bornée par `seekTo` a atteint sa borne : le segment qui vient d'être rendu était le
   * dernier (le groupe se ferme en lisant l'image clé de la borne), et `nextSegment` répond ensuite
   * null — ce null-là n'est pas la fin du fichier.
   */
  get stoppedShort() {
    return this.stopReached;
  }
  /** Une lecture bornée par `seekTo` qui n'a pas encore atteint sa borne. */
  get stopAhead() {
    return this.stopAtUs !== null && !this.stopReached;
  }
  /** Où la lecture reprendra pour ce temps (horloge du fichier) : le cluster que l'index désigne. */
  offsetFor(seconds2) {
    const offset = clusterOffsetForTime(this.file, Math.round(seconds2 * 1e6), this.videoTrack.number);
    return offset ?? this.file.firstClusterOffset ?? this.file.segmentDataStart;
  }
  /**
   * Un saut vient d'être demandé : les lectures réseau d'ailleurs sont abandonnées, et celles du
   * saut partent tout de suite — avant que le lecteur ait fini de vider ses tampons.
   *
   * Appelé au moment de la demande, pas quand le saut est servi : c'est l'attente de la lecture en
   * cours qui coûtait (voir `ByteSource.abandon`). Ceux qui attendaient reçoivent `ReadAbandoned` et
   * s'effacent ; `seekTo` remet ensuite tout d'aplomb, comme après n'importe quel saut.
   */
  prepareSeek(seconds2) {
    const from = this.offsetFor(seconds2);
    this.source.abandon?.(from);
    this.source.warm?.(from);
  }
  /** Le premier envoi d'une ouverture : la source rend l'avance qu'une reprise retenait (`focusOpening`). */
  openingSettled() {
    try {
      this.source.seekSettled?.();
    } catch {
    }
  }
  /** Le saut a sa première image : la source reprend sa lecture en avance entière. */
  seekSettled() {
    try {
      this.source.seekSettled?.();
    } catch {
    }
  }
  /** Le réseau depuis le dernier saut, pour la trace — voir `NetworkWindow`. */
  networkSinceSeek() {
    try {
      return this.source.networkSinceSeek?.() ?? null;
    } catch {
      return null;
    }
  }
  /** Le silence du réseau sous une demande — voir `ByteSource.networkSilentMs` (DECISIONS.md §97). */
  networkSilentMs() {
    try {
      return this.source.networkSilentMs?.() ?? 0;
    } catch {
      return 0;
    }
  }
  /** The next pair of segments, or null once the file is exhausted. */
  /**
   * The next piece of media, handed over as soon as it is settled rather than when the keyframe
   * group it belongs to has finished arriving.
   *
   * A picture's decode time is its rank among the group's presentation times, so nothing can be
   * emitted until the pictures that might hold a smaller presentation have been read. But that is
   * a handful of pictures — the reordering depth — and not the whole group. Waiting for the group
   * meant waiting for all of it: five megabytes on an ordinary file, fifteen on the two dozen in
   * this library whose keyframes sit twenty-five seconds apart, against forty milliseconds of
   * actual muxing.
   */
  async nextSegment() {
    if (!await this.readUntilSettled()) return null;
    if (this.done && this.transcoder && this.emitted >= this.pendingVideo.length) {
      this.tailDone = true;
      const audio2 = await this.buildTranscodedAudio(Infinity);
      const subtitles2 = this.buildSubtitles();
      this.pendingSubtitles = [];
      return { video: [], audio: audio2, subtitles: subtitles2, endSeconds: this.videoDecodeTime / TIMESCALE };
    }
    const video = this.buildVideo();
    const audio = this.transcoder ? await this.buildTranscodedAudio() : this.buildAudio();
    const subtitles = this.buildSubtitles();
    const endUs = this.videoDecodeTime;
    this.pendingAudio = [];
    this.pendingSubtitles = [];
    return { video, audio, subtitles, endSeconds: endUs / TIMESCALE };
  }
  /** Reads until a fragment's worth of pictures is settled, or the group ends. */
  async readUntilSettled() {
    if (this.groupClosed && this.emitted >= this.pendingVideo.length && !this.done) {
      this.pendingVideo = this.boundary ? [this.boundary] : [];
      this.boundary = null;
      this.emitted = 0;
      this.groupClosed = false;
      this.groupAnchorUs = null;
    }
    while (!this.groupClosed && !this.settled()) {
      let sample = await this.reader.next();
      if (!sample) {
        this.done = true;
        this.groupClosed = true;
        break;
      }
      if (sample.trackNumber === this.videoTrack.number) {
        const stray = strayUnits(sample.data, this.videoTrack.codecId, this.nalLength);
        if (stray) {
          this.putBack(stray);
          continue;
        }
        if (this.dropLeading) {
          if (isRaslPicture(sample.data, this.videoTrack.codecId, this.nalLength)) {
            this.leadingDropped += 1;
            continue;
          }
          this.dropLeading = false;
          if (this.leadingDropped > 0) trace(`reprise sur une image cl\xE9 CRA : ${this.leadingDropped} image(s) RASL \xE9cart\xE9e(s)`);
          this.leadingDropped = 0;
        }
        if (this.strayAhead.length > 0) {
          sample = { ...sample, data: joinBytes([...this.strayAhead, sample.data]) };
          this.strayAhead = [];
        }
        const cap = this.settings.lightCapNits;
        if (cap !== null && this.videoTrack.codecId === "V_MPEGH/ISO/HEVC") {
          sample = { ...sample, data: withCappedLightLevels(sample.data, this.nalLength, cap) };
        }
        if (this.needKeyframe) {
          if (!this.startsHere(sample)) {
            if (this.seekTargetUs !== null && sample.timestampUs > this.seekTargetUs) this.backUp();
            continue;
          }
          this.needKeyframe = false;
          this.seekTargetUs = null;
          this.dropLeading = true;
          this.leadingDropped = 0;
        }
        if (this.stopAtUs !== null && sample.timestampUs >= this.stopAtUs && this.startsHere(sample)) {
          this.stopReached = true;
          this.done = true;
          this.groupClosed = true;
          break;
        }
        const span = this.pendingVideo.length > 0 ? sample.timestampUs - this.pendingVideo[0].timestampUs : 0;
        if (this.startsHere(sample) && span >= SEGMENT_US) {
          this.boundary = sample;
          this.groupClosed = true;
          break;
        }
        this.pendingVideo.push(sample);
      } else if (this.audioTrack && !this.transcoder && sample.trackNumber === this.audioTrack.number) {
        this.pendingAudio.push(sample);
      } else if (this.subtitleNumbers.has(sample.trackNumber)) {
        this.pendingSubtitles.push(sample);
      }
    }
    const spent = this.emitted >= this.pendingVideo.length && this.pendingAudio.length === 0;
    const soundSpent = !this.transcoder || this.tailDone || this.transcoder.drained === true || this.stopReached;
    return !(this.done && spent && soundSpent);
  }
  /**
   * Whether enough has been read for the next fragment's timeline to be final.
   *
   * Past the reordering depth, what came before cannot move. The depth is measured on the first
   * group of the stream and used for every one after it — which is every seek; the first group is
   * given a generous guess instead, because there is nothing yet to measure it from.
   */
  settled() {
    return this.pendingVideo.length - this.emitted >= FRAGMENT_SAMPLES + this.reorderLookahead() + 1;
  }
  reorderLookahead() {
    return reorderLookahead(this.presentationDelayUs, this.frameDurationUs);
  }
  /** The text tracks worth collecting, worked out once and kept by number for the cue builder. */
  get subtitleNumbers() {
    if (!this.subtitleNumbersCache) {
      this.subtitleNumbersCache = new Map(this.subtitleTracks().map((t) => [t.number, t]));
    }
    return this.subtitleNumbersCache;
  }
  buildSubtitles() {
    if (this.pendingSubtitles.length === 0) return [];
    const delay = (this.presentationDelayUs ?? 0) / TIMESCALE;
    const cues = [];
    for (const sample of this.pendingSubtitles) {
      const track = this.subtitleNumbers.get(sample.trackNumber);
      if (!track) continue;
      const text = subtitleText(new TextDecoder().decode(sample.data), track.codecId);
      if (!text) continue;
      const startSeconds = sample.timestampUs / TIMESCALE + delay;
      cues.push({
        track: sample.trackNumber,
        startSeconds,
        endSeconds: startSeconds + (sample.durationUs !== null ? sample.durationUs / TIMESCALE : SUBTITLE_FALLBACK_SECONDS),
        text
      });
    }
    return cues;
  }
  /**
   * Sound that had to be decoded and encoded again, cut to this segment.
   *
   * Asked for by time rather than handed packets: the transcoder reads the file itself, through
   * the same cache, and runs its own decode and encode pipeline. Cutting at the video segment's
   * own end is what keeps the two tracks tiling together — each segment holds exactly the sound
   * belonging to the pictures beside it.
   */
  async buildTranscodedAudio(untilSeconds = this.videoDecodeTime / TIMESCALE) {
    if (!this.transcoder || !this.audioInfo) return null;
    if (this.transcoderSeekPending) {
      this.transcoderSeekPending = false;
      this.transcoder.seekTo(this.segmentStartUs / TIMESCALE);
    }
    let frames;
    const transcodeFrom = diagNow();
    try {
      frames = await this.transcoder.framesUpTo(untilSeconds);
      diagInterval("audio", transcodeFrom);
    } catch (error) {
      if (isReadAbandoned(error)) throw error;
      if (untilSeconds === Infinity) {
        trace(`transcodage audio : fin du son perdue (${error instanceof Error ? error.message : String(error)})`);
        return null;
      }
      frames = await this.retryTranscoder(error);
    }
    const transcoder = this.transcoder;
    if (!transcoder) return null;
    if (++this.goodSegments >= GOOD_SEGMENTS_TO_FORGIVE && this.encoderRestarts > 0) {
      trace(`transcodage audio : ${this.goodSegments} segments sans \xE9chec, reconstructions oubli\xE9es`);
      this.encoderRestarts = 0;
    }
    if (frames.length === 0) return null;
    const delay = this.presentationDelayUs ?? 0;
    const fallback = Math.round(1024 / transcoder.sampleRate * TIMESCALE);
    const samples = frames.map((frame) => ({
      data: frame.data,
      decodeTime: frame.timestampUs + delay,
      duration: Math.max(1, frame.durationUs || fallback),
      compositionOffset: 0,
      isKeyframe: true
    }));
    return mediaSegment(this.audioInfo, this.sequence, samples);
  }
  /**
   * Builds a fresh transcoder in place of one that failed, and asks it again.
   *
   * Bounded, because an encoder that refuses every time is a real possibility and retrying it for
   * ever would be a player that reads the whole film without ever producing a sound. Past the
   * limit the original failure is raised, which is the one worth reporting.
   */
  async retryTranscoder(cause) {
    const track = this.audioTrack;
    if (!track || this.closed || this.encoderRestarts >= MAX_ENCODER_RESTARTS) throw cause;
    this.encoderRestarts += 1;
    this.goodSegments = 0;
    const at = this.segmentStartUs / TIMESCALE;
    const why = cause instanceof Error ? cause.message : String(cause);
    trace(`transcodage audio : cha\xEEne en \xE9chec (${why}), reconstruction (${this.encoderRestarts}) \xE0 ${at.toFixed(1)} s`);
    const previous = this.transcoder;
    let next;
    try {
      next = await AudioTranscoder.open(this.source, track, at, unifiedAudioChannels(this.file, this.settings) ?? void 0, this.file, this.settings.dialogue, this.decodesCopiedTrack);
    } catch (error) {
      if (isReadAbandoned(error)) this.encoderRestarts -= 1;
      throw error;
    }
    if (this.closed) {
      next.close();
      throw cause;
    }
    assertContainerTakes(next);
    if (previous && (next.codecString !== previous.codecString || !sameShape(previous, next))) {
      next.close();
      throw cause;
    }
    if (previous) this.retiredTiming.push(previous.timingStats);
    previous?.close();
    this.transcoder = next;
    this.audioInfo = transcodedAudioInfo(next, track);
    next.seekTo(at);
    return next.framesUpTo(this.videoDecodeTime / TIMESCALE);
  }
  /** Points the reader further back, one step at a time, and says whether it moved. */
  backUp() {
    if (this.seekTargetUs === null || this.backupsLeft <= 0) return false;
    const step = MAX_INDEX_BACKUPS - this.backupsLeft + 1;
    this.backupsLeft -= 1;
    if (step > 1 && this.seekTargetUs - INDEX_BACKUP_US * (step - 1) <= 0) return false;
    const earlier = Math.max(0, this.seekTargetUs - INDEX_BACKUP_US * step);
    const start = this.file.firstClusterOffset ?? this.file.segmentDataStart;
    const from = clusterOffsetForTime(this.file, earlier, this.videoTrack.number) ?? start;
    this.reader.seekTo(from);
    this.source.warm?.(from);
    this.pendingVideo = [];
    this.pendingAudio = [];
    this.audioEndUs = null;
    this.pendingSubtitles = [];
    this.strayAhead = [];
    trace(
      `index : rien o\xF9 d\xE9marrer avant ${(this.seekTargetUs / 1e6).toFixed(1)} s, relecture depuis ${(earlier / 1e6).toFixed(1)} s`
    );
    return true;
  }
  buildVideo() {
    if (this.pendingVideo.length === 0 || this.emitted >= this.pendingVideo.length) return [];
    const presentations = this.pendingVideo.map((s) => s.timestampUs);
    const durations = deriveDurations(presentations, FALLBACK_FRAME_US);
    this.groupAnchorUs ??= Math.min(...presentations);
    this.segmentStartUs = this.groupAnchorUs;
    const ordered = assignDecodeTimes(
      presentations.map((presentation, i) => ({ presentation, duration: durations[i] })),
      this.segmentStartUs
    );
    if (this.presentationDelayUs === null) {
      this.frameDurationUs = durations[0] || FALLBACK_FRAME_US;
      this.presentationDelayUs = ordered.presentationDelay + DELAY_MARGIN_FRAMES * this.frameDurationUs;
    }
    const delay = this.presentationDelayUs;
    const from = this.emitted;
    const until = this.groupClosed ? this.pendingVideo.length : Math.min(this.pendingVideo.length - this.reorderLookahead() - 1, from + FRAGMENT_SAMPLES);
    if (until <= from) return [];
    const samples = [];
    for (let i = from; i < until; i++) {
      const sample = this.pendingVideo[i];
      const offset = ordered.samples[i].compositionOffset + delay;
      if (offset < 0) this.clampedSamples += 1;
      samples.push({
        data: sample.data,
        decodeTime: ordered.samples[i].decode,
        duration: ordered.samples[i].duration,
        compositionOffset: Math.max(0, offset),
        // The container's word is not enough here either: telling a player that a trailing
        // picture is a sync sample invites it to start decoding there.
        isKeyframe: this.startsHere(sample)
      });
    }
    this.emitted = until;
    this.videoDecodeTime = until >= this.pendingVideo.length ? ordered.endDecodeTime : ordered.samples[until].decode;
    return this.fragmentise(samples);
  }
  /**
   * Cuts one keyframe group's samples into several fragments.
   *
   * A fragment does not have to be a whole keyframe group — that is what a CMAF chunk is, and
   * what every low-latency packager produces. The group has to be *computed* whole, though, and
   * that is why this happens here and not in the reader: the decode timeline is recovered by
   * sorting a group's presentation times, which only works for a group reordering cannot cross.
   * Cut the samples before that and a B-picture's decode time comes out wrong, which is drift.
   *
   * What it buys: this library's keyframes sit anywhere from nothing to ten seconds apart, so a
   * group can be eight megabytes of pictures handed over in one call. Safari answers one of those
   * — nine seconds, 228 samples, 5.5 MB, at 1951 s of a real file — by closing the MediaSource
   * with "media failed to decode", the same bytes every time.
   */
  fragmentise(samples) {
    return planFragments(samples.length, (i) => samples[i].data.byteLength).map((indices) => {
      const from = indices[0];
      const to = indices[indices.length - 1] + 1;
      const next = to < samples.length ? samples[to].decodeTime : void 0;
      const segment = mediaSegment(this.videoInfo, this.sequence, samples.slice(from, to), next);
      this.sequence += 1;
      return segment;
    });
  }
  buildAudio() {
    if (!this.audioInfo || this.pendingAudio.length === 0) return null;
    const runs = [];
    for (const sample of this.pendingAudio) {
      const last2 = runs[runs.length - 1];
      if (last2 && last2.timestamp === sample.timestampUs) last2.frames.push(sample);
      else runs.push({ timestamp: sample.timestampUs, frames: [sample] });
    }
    const delay = this.presentationDelayUs ?? 0;
    const samples = [];
    for (let r = 0; r < runs.length; r++) {
      const run = runs[r];
      const next = runs[r + 1];
      let frameDuration = next ? (next.timestamp - run.timestamp) / run.frames.length : this.audioFrameUs ?? FALLBACK_AUDIO_FRAME_US;
      if (next && frameDuration > 0) this.audioFrameUs = frameDuration;
      else if (!(frameDuration > 0)) frameDuration = this.audioFrameUs ?? FALLBACK_AUDIO_FRAME_US;
      for (let i = 0; i < run.frames.length; i++) {
        let decode = Math.round(run.timestamp + i * frameDuration) + delay;
        const end = Math.round(run.timestamp + (i + 1) * frameDuration) + delay;
        if (this.audioEndUs !== null && decode < this.audioEndUs) {
          if (end - this.audioEndUs < frameDuration / 2) continue;
          decode = this.audioEndUs;
        }
        const duration = Math.max(1, end - decode);
        samples.push({
          data: run.frames[i].data,
          decodeTime: decode,
          duration,
          compositionOffset: 0,
          isKeyframe: true
        });
        this.audioEndUs = decode + duration;
      }
    }
    if (samples.length === 0) return null;
    return mediaSegment(this.audioInfo, this.sequence, samples);
  }
};

// src/engine/pathSelector.ts
var EMPTY = new Uint8Array(0);
var TRUST_DOLBY_VISION = true;
var DOLBY_VISION_CODECS = /* @__PURE__ */ new Set(["V_MPEGH/ISO/HEVC"]);
function planDolbyVision(track, videoRangeType, accepts, trusted = TRUST_DOLBY_VISION) {
  const noBaseLayer = videoRangeType === "DOVI";
  const dv = DOLBY_VISION_CODECS.has(track.codecId) ? track.dolbyVision : void 0;
  const info = dv ? dolbyVisionInfo(dv.record) : null;
  if (trusted && dv && info && accepts(`video/mp4; codecs="${info.codec}"`)) {
    return { kind: "dolby", codec: info.codec, box: dv };
  }
  if (!noBaseLayer) return { kind: "hdr10" };
  return {
    kind: "server",
    reason: `Le Dolby Vision sans couche HDR10 n'a pas de base standard : ce lecteur en rendrait les couleurs fausses.`
  };
}
async function tryRemux(input) {
  const { file, videoTrack, audioTrack, dimensions, source } = input;
  trace(`chemin : examen du remultiplexage \u2014 vid\xE9o ${videoTrack.codecId}, audio ${audioTrack?.codecId ?? "aucune"}`);
  if (audioTrack) {
    await chooseTranscodeCodec(audioTrack.audio?.sampleRate ?? 48e3, audioTrack.audio?.channels ?? 2);
  }
  if (!remuxableVideo(videoTrack)) return `vid\xE9o ${videoTrack.codecId} non remultiplexable`;
  if (audioTrack && !playableAudio(audioTrack)) {
    if (!audioDecoderExists(audioTrack)) return `audio ${audioTrack.codecId} : aucun d\xE9codeur, ni ici ni dans le navigateur`;
    return `audio ${audioTrack.codecId} non remultiplexable`;
  }
  if (audioTrack && audioDelivery(audioTrack, file, input.remux) === "transcode") {
    const rate = audioTrack.audio?.sampleRate ?? 48e3;
    const channels = audioTrack.audio?.channels ?? 2;
    trace(`chemin : ${audioTrack.codecId} doit \xEAtre r\xE9-encod\xE9, on cherche un codec en ${channels} canaux`);
    const plan = await chooseTranscodePlan(rate, channels);
    if (!plan) {
      return `ce navigateur n'accepte pas ${audioTrack.codecId} et ne sait produire aucun codec de remplacement`;
    }
    trace(`chemin : codec de remplacement retenu \u2014 ${plan.codec} en ${plan.channels} canaux`);
    if (plan.channels !== channels) {
      trace(`chemin : ${channels} canaux non encodables ici, la piste sera livr\xE9e en ${plan.channels}`);
    }
  }
  const mime = plannedMimeTypes(videoTrack, audioTrack, file, input.remux);
  const playable = playabilityOf({
    videoMimeType: mime.video ?? "",
    audioMimeType: mime.audio,
    videoInit: EMPTY,
    audioInit: null,
    durationSeconds: 0
  });
  trace(`chemin : le navigateur accepte-t-il ${mime.video ?? "?"} + ${mime.audio ?? "aucun"} \u2192 ${playable.ok ? "oui" : "non"}`);
  if (!playable.ok) return playable.reason;
  const dv = planDolbyVision(
    videoTrack,
    input.videoRangeType,
    (videoMimeType) => playabilityOf({ videoMimeType, audioMimeType: mime.audio, videoInit: EMPTY, audioInit: null, durationSeconds: 0 }).ok
  );
  if (videoTrack.dolbyVision) {
    const detail = dv.kind === "dolby" ? `livr\xE9 en ${dv.codec}` : dv.kind === "hdr10" ? "refus\xE9 ou non demand\xE9 \u2014 la couche de base HDR10 prend le relais" : "refus\xE9, et sans couche de base : passage au lecteur serveur";
    trace(`dolby vision : ${videoTrack.dolbyVision.type} pr\xE9sent \u2014 ${detail}`);
  }
  if (dv.kind === "server") return dv.reason;
  try {
    input.onViable?.();
  } catch {
  }
  try {
    const remuxer = await Remuxer.open(
      source,
      file,
      videoTrack,
      audioTrack,
      dimensions,
      dv.kind === "dolby" ? dv.box : null,
      input.startSeconds ?? 0,
      input.remux
    );
    trace("chemin : remultiplexeur ouvert");
    if (audioTrack?.codecId === "A_AAC" && parseAacConfig(audioTrack.codecPrivate)?.pce && audioDelivery(audioTrack, file, input.remux) === "transcode") {
      notePceDecision("decode", false, audioTrack.codecPrivate);
    }
    return { remuxer, plan: remuxer.plan() };
  } catch (error) {
    if (isNetworkFailure(error) || isReadAbandoned(error)) throw error;
    return error instanceof Error ? error.message : "ouverture impossible";
  }
}
async function choosePlaybackPath(input) {
  const remux = await tryRemux(input);
  if (typeof remux !== "string") return { path: "remux", remuxer: remux.remuxer, plan: remux.plan };
  trace(`chemin : remultiplexage refus\xE9 \u2014 ${remux}`);
  throw new Error(`Aucun chemin de lecture disponible pour ce fichier. remux : ${remux}`);
}
var NATIVE_PATH = "remultiplexage \u2192 lecteur natif";

// src/support/trackPreferences.ts
var TWO_WAYS = {
  alb: "sq",
  sqi: "sq",
  arm: "hy",
  hye: "hy",
  baq: "eu",
  eus: "eu",
  bur: "my",
  mya: "my",
  chi: "zh",
  zho: "zh",
  cze: "cs",
  ces: "cs",
  dut: "nl",
  nld: "nl",
  fre: "fr",
  fra: "fr",
  geo: "ka",
  kat: "ka",
  ger: "de",
  deu: "de",
  gre: "el",
  ell: "el",
  ice: "is",
  isl: "is",
  mac: "mk",
  mkd: "mk",
  mao: "mi",
  mri: "mi",
  may: "ms",
  msa: "ms",
  per: "fa",
  fas: "fa",
  rum: "ro",
  ron: "ro",
  slo: "sk",
  slk: "sk",
  tib: "bo",
  bod: "bo",
  wel: "cy",
  cym: "cy"
};
var TO_TWO = {
  eng: "en",
  spa: "es",
  ita: "it",
  por: "pt",
  rus: "ru",
  jpn: "ja",
  kor: "ko",
  ara: "ar",
  heb: "he",
  hin: "hi",
  tur: "tr",
  pol: "pl",
  swe: "sv",
  nor: "no",
  dan: "da",
  fin: "fi",
  hun: "hu",
  ukr: "uk",
  tha: "th",
  vie: "vi",
  ind: "id",
  cat: "ca",
  lat: "la"
};
function normaliseLanguage(tag) {
  if (!tag) return null;
  const clean = tag.trim().toLowerCase().replace(/_/g, "-");
  if (!clean || clean === "und" || clean === "mis" || clean === "zxx" || clean === "mul") return null;
  const base = clean.split("-")[0];
  return TWO_WAYS[base] ?? TO_TWO[base] ?? base;
}
var NAMED_IN_TITLE = [
  [/\b(vff|vfq|vfi|vf|vfb)\b|fran[çc]ais|french/i, "fr"],
  // Not "VO": that means *version originale*, and this library has a track named
  // "Espagnol [VO]" whose original version is Spanish. It says a track is not dubbed, which is
  // not the same as saying what language it is in.
  [/\benglish\b|anglais/i, "en"],
  [/espa[ñn]ol|spanish|espagnol/i, "es"],
  [/deutsch|german|allemand/i, "de"],
  [/italiano|italian|italien/i, "it"],
  [/portugu[êe]s|portuguese/i, "pt"],
  [/日本語|japanese|japonais/i, "ja"]
];
function isAudioDescription(track) {
  const name = track.name ?? "";
  return /\bad\b|audio[- ]?description|descriptive|narration|visually impaired|malvoyant/i.test(name);
}
function isCommentary(track) {
  return /commentaire|commentary|director'?s? track/i.test(track.name ?? "");
}
function trackLanguage(track) {
  const declared = normaliseLanguage(track.language);
  if (declared) return declared;
  for (const [pattern, language] of NAMED_IN_TITLE) {
    if (pattern.test(track.name ?? "")) return language;
  }
  return null;
}
function rank(tracks, wanted, carriable, delivered) {
  return tracks.map((track, order) => {
    const language = trackLanguage(track);
    let score = 0;
    if (wanted && language === wanted) score += 100;
    else if (language === null) score += 10;
    if (carriable && carriable(track)) score += 20;
    if (isAudioDescription(track)) score -= 200;
    if (isCommentary(track)) score -= 150;
    const out = delivered ? delivered(track) : { channels: canaux(track), copied: false };
    return { track, score, order, channels: out.channels, copied: out.copied };
  }).sort(
    (a, b) => b.score - a.score || b.channels - a.channels || Number(b.copied) - Number(a.copied) || Number(b.track.isDefault) - Number(a.track.isDefault) || a.order - b.order
  ).map((entry) => entry.track);
}
function canaux(track) {
  const t = track;
  const n = t.channels ?? t.audio?.channels;
  return typeof n === "number" ? n : 0;
}
function chooseAudioTrack(tracks, preferences, carriable, delivered) {
  if (tracks.length === 0) return null;
  if (preferences.playDefaultAudioTrack) return null;
  const wanted = normaliseLanguage(preferences.audioLanguage);
  if (!wanted) return null;
  const best = rank(tracks, wanted, carriable, delivered)[0];
  return best && trackLanguage(best) === wanted ? best : null;
}

// src/engine/remuxPlayback.ts
var DISK_WAIT_MS = 150;
var CUE_HISTORY_SECONDS = 60;
var CUE_FUTURE_SECONDS = 120;
var KEEP_EVERY_SECONDS = 2;
function preferredAudio(file, preferences) {
  const audio = file.tracks.filter((t) => t.type === "audio");
  const playable = audio.filter(playableAudio);
  if (preferences && playable.length > 0) {
    const wanted = chooseAudioTrack(playable, preferences, playableAudio, deliveredAudio);
    if (wanted) return wanted;
  }
  if (playable.length === 0) return audio.find((t) => t.isDefault) ?? audio[0] ?? null;
  const preferred = audio.find((t) => t.isDefault) ?? audio[0];
  const language = preferred?.language ?? null;
  const sameLanguage = playable.filter((t) => t.language === language);
  const pool = sameLanguage.length > 0 ? sameLanguage : playable;
  return pool.reduce((best, t) => {
    const [a, b] = [deliveredAudio(t), deliveredAudio(best)];
    return a.channels > b.channels || a.channels === b.channels && a.copied && !b.copied ? t : best;
  }, pool[0]);
}
function openingAudio(file, preferences, chosen) {
  if (chosen !== null && chosen !== void 0) {
    const track = file.tracks.find((t) => t.type === "audio" && t.number === chosen);
    if (track && playableAudio(track)) return track;
  }
  return preferredAudio(file, preferences);
}
async function probePlaybackPath(options) {
  traceReset();
  const displayHdr = displayIsHdr();
  const lightCap = hdrLightCap();
  trace("ouverture du flux");
  trace(
    `\xE9cran HDR : ${displayHdr === null ? "inconnu" : displayHdr ? "oui" : "non"}` + (lightCap !== null ? ` \u2014 lumi\xE8re HDR annonc\xE9e plafonn\xE9e \xE0 ${lightCap} nits (choix de l'appareil)` : "")
  );
  const disk = options.disk ? await Promise.race([options.disk.catch(() => null), new Promise((resolve) => setTimeout(() => resolve(null), DISK_WAIT_MS))]) : null;
  const source = await HttpByteSource.open(options.streamUrl, options.knownSize, disk, options.fileVersion ? mediaHeaderKey(options.streamUrl, options.fileVersion) : null);
  trace(`flux ouvert \u2014 ${source.size} octets`);
  try {
    return await probeOpened(source, options, lightCap);
  } catch (error) {
    source.close();
    throw error;
  }
}
async function probeOpened(source, options, lightCap) {
  const headerAt = Date.now();
  const resuming = options.startSeconds > NO_INDEX_REACH_SECONDS;
  if (resuming) source.holdReadahead?.(true);
  const headerKey = mediaHeaderKey(options.streamUrl, options.fileVersion);
  source.whenSizeCorrected?.(() => forgetMediaHeader(headerKey));
  let file;
  try {
    file = await openMediaFile(source, headerKey);
  } finally {
    if (resuming) source.holdReadahead?.(false);
  }
  if (resuming && source instanceof HttpByteSource) {
    const from = keptRangeAt(file, options.startSeconds, file.tracks.find((t) => t.type === "video")?.number)?.from;
    if (from !== void 0) {
      source.focusOpening();
      source.warm(from);
    }
  }
  const headerMs = Date.now() - headerAt;
  trace(
    `en-t\xEAte ${headerMs < 15 ? "d\xE9j\xE0 connu" : "lu"} en ${headerMs} ms \u2014 ${file.tracks.length} pistes, ${file.cues.length} points d'index, ` + file.tracks.map((t) => `${t.number}:${t.type}:${t.codecId}${t.language ? `/${t.language}` : ""}`).join(" ")
  );
  const videoTrack = file.tracks.find((t) => t.type === "video");
  if (!videoTrack) throw new Error("Ce fichier ne contient aucune piste vid\xE9o.");
  await primeAudioDelivery(file);
  const picked = options.audioTrackNumber ?? options.pickAudioTrack?.(file.tracks.filter((t) => t.type === "audio").map((t) => ({ ...fromMatroskaTrack(t), delivered: deliveredAudio(t) }))) ?? null;
  const audioTrack = openingAudio(file, options.audioPreferences, picked);
  trace(`piste audio retenue : ${audioTrack ? `${audioTrack.codecId} ${audioTrack.audio?.channels ?? "?"}ch ${audioTrack.language ?? "?"}` : "aucune"}`);
  if (options.dialogue && options.dialogue !== "off") trace(`dialogues am\xE9lior\xE9s demand\xE9s (${options.dialogue === "strong" ? "encore plus fort" : "normal"})`);
  takeLumenFacts();
  const chosen = await choosePlaybackPath({
    source,
    file,
    videoTrack,
    audioTrack,
    dimensions: { width: videoTrack.video?.width ?? 1920, height: videoTrack.video?.height ?? 1080 },
    videoRangeType: options.videoRangeType,
    startSeconds: options.startSeconds,
    onViable: options.onViable,
    remux: {
      lightCapNits: lightCap,
      ...options.dialogue && options.dialogue !== "off" ? { dialogue: options.dialogue } : {}
    }
  });
  trace(`chemin choisi : ${NATIVE_PATH}`);
  return {
    path: "remux",
    chosen,
    audioTracks: chosen.remuxer.audioTracks().map((t) => ({ ...fromMatroskaTrack(t), delivered: deliveredAudio(t) })),
    audioTrack: audioTrack?.number ?? null,
    start: (video) => RemuxPlayback.start(video, source, file, videoTrack, audioTrack, chosen, options),
    // For a caller that asked and then changed its mind: the remuxer holds the software decoder
    // and the encoder, and the source holds the connection.
    discard: () => {
      chosen.remuxer.close();
      source.close();
    }
  };
}
function cueKey(cue) {
  return `${cue.track}:${cue.startSeconds.toFixed(3)}:${cue.text}`;
}
var RemuxPlayback = class _RemuxPlayback {
  constructor(video, source, file, videoTrack, audioTrack, remuxer, options) {
    this.video = video;
    this.source = source;
    this.file = file;
    this.videoTrack = videoTrack;
    this.audioTrack = audioTrack;
    this.remuxer = remuxer;
    this.options = options;
  }
  video;
  source;
  file;
  videoTrack;
  audioTrack;
  remuxer;
  options;
  mse = null;
  cues = [];
  currentSubtitle = null;
  destroyed = false;
  static async start(video, source, file, videoTrack, audioTrack, chosen, options) {
    const playback = new _RemuxPlayback(video, source, file, videoTrack, audioTrack, chosen.remuxer, options);
    try {
      await playback.attach(chosen.plan, options.startSeconds);
    } catch (error) {
      playback.destroy();
      throw error;
    }
    return playback;
  }
  /**
   * De quoi faire tourner la réserve d'avance en mémoire (`MemoryReserve`) à côté de ce lecteur : sa
   * source, l'index du fichier, l'élément et l'avance du tampon. Null pour une source qui ne lit pas
   * le réseau.
   */
  reserveContext() {
    if (this.destroyed || !(this.source instanceof HttpByteSource)) return null;
    return {
      source: this.source,
      file: this.file,
      video: this.video,
      lead: () => this.mse?.bufferedLead ?? 0,
      delay: () => this.mse?.presentationDelay ?? 0
    };
  }
  /** Ce que la source tient en mémoire — voir `ByteSource.held`. Ne lève jamais. */
  heldBytes() {
    try {
      return this.source.held?.() ?? null;
    } catch {
      return null;
    }
  }
  /** Où la zone gardée a été posée pour la dernière fois, en secondes du lecteur. */
  keptAt = -Infinity;
  /**
   * Garde en mémoire les octets autour de la tête de lecture — voir `MAX_KEPT_CHUNKS` dans
   * byteSource.ts. C'est ce qu'un changement de piste relit, et ce que la lecture en avance
   * chassait du cache. Toutes les deux secondes de lecture, et à chaque saut : un calcul sur
   * l'index déjà en mémoire, rien de plus.
   */
  keepAroundHead = (event) => {
    if (this.destroyed || !this.source.keep) return;
    const now = this.video.currentTime;
    if (event?.type === "timeupdate" && Math.abs(now - this.keptAt) < KEEP_EVERY_SECONDS) return;
    this.keptAt = now;
    const range = keptRangeAt(this.file, Math.max(0, now - (this.mse?.presentationDelay ?? 0)), this.videoTrack.number);
    if (range) this.source.keep(range.from, range.to);
  };
  async attach(plan, startSeconds) {
    trace(`attachement de MediaSource \u2014 ${plan.videoMimeType} + ${plan.audioMimeType ?? "aucun audio"}`);
    diagMedia(this.source.size, plan.durationSeconds, this.video);
    probeDecodingInfo(plan.videoMimeType, this.videoTrack, this.source.size, plan.durationSeconds);
    this.mse = await MseSource.attach(
      this.video,
      this.remuxer,
      plan,
      {
        onError: this.options.onError,
        onUnreadableZone: this.options.onUnreadableZone,
        onWarning: this.options.onWarning,
        onStarting: this.options.onStarting,
        onStall: this.options.onStall,
        onSubtitles: (cues) => this.collect(cues)
      },
      // Handed in rather than seeked to afterwards, so the first read happens where the viewer
      // is resuming instead of at the beginning of the file.
      startSeconds,
      this.options.startPaused ?? false
    );
    this.video.addEventListener("timeupdate", this.keepAroundHead);
    this.video.addEventListener("seeked", this.keepAroundHead);
  }
  collect(cues) {
    const known = new Set(this.cues.map(cueKey));
    for (const cue of cues) {
      const key = cueKey(cue);
      if (known.has(key)) continue;
      known.add(key);
      this.cues.push(cue);
    }
    if (this.cues.length <= 600) return;
    const now = this.video.currentTime;
    this.cues = this.cues.filter(
      (cue) => cue.endSeconds >= now - CUE_HISTORY_SECONDS && cue.startSeconds <= now + CUE_FUTURE_SECONDS
    );
  }
  get audioTracks() {
    return this.remuxer.audioTracks().map((t) => ({ ...fromMatroskaTrack(t), delivered: deliveredAudio(t) }));
  }
  get subtitleTracks() {
    return this.remuxer.subtitleTracks().map(fromMatroskaTrack);
  }
  get currentAudioTrack() {
    return this.audioTrack?.number ?? null;
  }
  /**
   * Ce que demande le passage à cette piste : `"rebuild"`, `"refused"`, ou `null` s'il n'y a rien
   * à faire (piste inconnue, déjà jouée, lecteur détruit).
   *
   * **Il n'y a plus qu'une façon de changer de piste : reconstruire le lecteur**, à la même
   * position, directement sur la nouvelle piste — l'appelant s'en charge. Il y en avait une
   * seconde jusqu'au 22/09/2026, « dans le tampon » : vider le son et le relire en gardant
   * l'image. Mesurée sur les trois moteurs, elle était plus lente (0,4 à 3,1 s en médiane, avec
   * des queues de plusieurs secondes, contre 0,05 à 0,35 s pour la reconstruction) et laissait sur
   * WebKit un décalage durable entre le son et l'image ; elle a été retirée.
   *
   * Refusé — un avertissement, la piste d'avant continue — sur un fichier sans index en cours de
   * film : voir `switchNeedsIndex`. Une demande, et non une question : c'est ici que le refus
   * est dit au spectateur, comme un saut refusé l'est par la source.
   */
  requestAudioTrack(trackNumber) {
    const track = this.file.tracks.find((t) => t.number === trackNumber && t.type === "audio");
    if (!track || this.destroyed || track.number === this.audioTrack?.number) return null;
    if (!playableAudio(track)) return "refused";
    if (this.switchNeedsIndex) {
      this.options.onWarning?.(playerWarning("noIndexAudio"));
      return "refused";
    }
    return "rebuild";
  }
  /**
   * Un changement de piste ici relirait le fichier depuis son début.
   *
   * La reconstruction rouvre à la position courante *par l'index*. Un fichier sans index n'a pas
   * de grappe à désigner — `clusterOffsetForTime` retombe sur la première —, et le film
   * reprendrait à zéro. Au tout début du film, en revanche, lire depuis le début *est* la bonne
   * réponse : même seuil qu'un saut refusé.
   */
  get switchNeedsIndex() {
    return !reachable(this.remuxer.seekable, this.video.currentTime);
  }
  /**
   * Whether this path could carry that track's sound at all — asked *before* anything is touched.
   *
   * A codec this path cannot carry will not be carried on the next attempt either, so the caller
   * steps aside to a player that *can* carry it instead of rebuilding this one onto a refusal, or
   * telling the viewer their language is unavailable.
   */
  /**
   * « Améliorer les dialogues » aurait-il prise sur cette piste ? Oui si elle est déjà ré-encodée
   * (DTS, TrueHD… là où le navigateur ne les prend pas), ou si notre chaîne sait la décoder pour la
   * ré-encoder (`dialogueCanShape`). Non pour un AAC 5.1 ou un MP3 copiés : le menu le dit.
   */
  canShapeDialogue(trackNumber) {
    const track = this.file.tracks.find((t) => t.number === trackNumber && t.type === "audio");
    if (!track) return true;
    return audioDelivery(track) === "transcode" || dialogueCanShape(track);
  }
  canCarryAudio(trackNumber) {
    const track = this.file.tracks.find((t) => t.number === trackNumber && t.type === "audio");
    return track ? playableAudio(track) : true;
  }
  get currentSubtitleTrack() {
    return this.currentSubtitle;
  }
  /**
   * Scanned in place, on purpose.
   *
   * This is asked several times a second while a film plays. Filtering to the chosen track first
   * allocated a fresh array of every line held, every time — and handed it to a helper that
   * prunes its argument as it goes, so the pruning was thrown away with the copy. A direct scan
   * allocates nothing and does not care that seeking leaves the lines out of order.
   */
  /**
   * Où l'horloge du lecteur se tient par rapport à celle du fichier.
   *
   * Les lignes du conteneur sont déjà posées sur l'horloge du lecteur ; un fichier de sous-titres
   * à côté du film, lui, est daté sur celle du fichier, et lu tel quel il arrivait d'autant en
   * avance — un quart de seconde sur un film HEVC (23/09/2026).
   */
  get presentationDelay() {
    return this.mse?.presentationDelay ?? 0;
  }
  /**
   * `track` absent : la piste choisie. Donnée : une autre piste du fichier — le second sous-titre
   * (DECISIONS.md §87), lu dans les mêmes lignes déjà en mémoire (toutes les pistes texte sont
   * recueillies d'un seul passage), sans rien changer au filtre de la piste choisie.
   */
  subtitleAt(seconds2, track = this.currentSubtitle) {
    if (track === null) return null;
    return simultaneousText(
      this.cues.filter((cue) => cue.track === track && cue.startSeconds <= seconds2 && seconds2 <= cue.endSeconds)
    );
  }
  /**
   * Changing subtitles is a change of filter and nothing else.
   *
   * Every text track's lines are already in hand, so there is nothing to fetch and nothing to
   * disturb. Re-reading the file for the newly chosen track — which is what this did first —
   * meant re-appending media the browser had already played, and it catches that up at speed:
   * choosing a subtitle came with a second of fast-forward before playback settled.
   */
  selectSubtitleTrack(trackNumber) {
    this.currentSubtitle = trackNumber;
  }
  /**
   * Voir `MseSource.openingHold` : ce que l'hôte attend avant `play()` à une ouverture depuis le
   * début (26/10/2026), ou `null` — sans source aussi : il n'y a alors rien à retenir.
   */
  openingHold() {
    return this.mse?.openingHold() ?? null;
  }
  /** See MseSource.lost: the platform took the source, and only a rebuild brings it back. */
  /** Voir `MseSource.seekPending`. Faux sans source : il n'y a alors rien en cours. */
  get seekPending() {
    return this.mse?.seekPending ?? false;
  }
  get lost() {
    return this.mse?.lost ?? false;
  }
  /** Voir `MseSource.seekPathFor` : comment le saut vers cette cible a été servi, pour la ligne `seek`. */
  seekPathFor(target) {
    return this.mse?.seekPathFor(target) ?? null;
  }
  /** Voir `MseSource.nextKeyframeAfter` : où rouvrir au-delà d'un passage qui a tué la source deux fois. */
  nextKeyframeAfter(playerSeconds) {
    return this.mse?.nextKeyframeAfter(playerSeconds) ?? null;
  }
  /** Voir `MseSource.lossReport` : ce que la ligne `rebuild` dit de la perte. */
  lossReport() {
    return this.mse?.lossReport() ?? {};
  }
  get position() {
    return this.mse?.position ?? 0;
  }
  seek(seconds2) {
    return this.mse?.seek(seconds2) ?? Promise.resolve();
  }
  /** Le pire écart d'horloge du son ré-encodé, `null` quand le son est copié — voir `Remuxer.audioTiming`. */
  /** Reprises, poussées, barreaux gravis et évictions sur la séance, pour la ligne `stop` — voir `MseSource.recoveryFacts`. */
  recoveryFacts() {
    return this.mse?.recoveryFacts ?? null;
  }
  audioTiming() {
    return this.remuxer.audioTiming();
  }
  /** Le son qui commence après l'image, et ce que ce pipeline en a fait — voir `Remuxer.audioLeadGap` (§148). */
  audioLeadGap() {
    return this.remuxer.audioLeadGap();
  }
  get diagnostics() {
    const remux = this.remuxer.diagnostics();
    return {
      Chemin: NATIVE_PATH,
      D\u00E9codage: "mat\xE9riel, par le navigateur",
      Vid\u00E9o: `${this.videoTrack.codecId} ${this.videoTrack.video?.width ?? "?"}\xD7${this.videoTrack.video?.height ?? "?"}`,
      Audio: this.audioTrack ? `${this.audioTrack.codecId} ${this.audioTrack.audio?.channels ?? "?"} canaux` : "aucune",
      // Worth stating plainly: on this path the sound is the one thing that may not be the
      // file's own bytes, and knowing which of the two is happening explains everything else.
      // A codec string is what the container says; a name is what a reader needs.
      "Traitement audio": remux.transcodedCodec ? `d\xE9cod\xE9 puis r\xE9-encod\xE9 en ${remux.transcodedCodec.startsWith("mp4a") ? "AAC" : remux.transcodedCodec === "opus" ? "Opus" : remux.transcodedCodec}` : "copi\xE9 tel quel",
      "D\xE9calage de pr\xE9sentation": `${(remux.presentationDelaySeconds * 1e3).toFixed(0)} ms`,
      "Images recal\xE9es": String(remux.clampedSamples),
      Index: `${this.remuxer.videoCuePoints} points vid\xE9o / ${this.file.cues.length}`,
      // The spans themselves, not one number derived from them. A single figure hid which range
      // it was measured against, and read as a large negative number while the player was in
      // fact working correctly on a range it had not been told about.
      ...this.mse?.debug ?? {},
      "Sous-titres en m\xE9moire": String(this.cues.length)
    };
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.video.removeEventListener("timeupdate", this.keepAroundHead);
    this.video.removeEventListener("seeked", this.keepAroundHead);
    this.mse?.destroy();
    this.mse = null;
    this.remuxer.close();
    this.source.close();
  }
};

// src/engine/externalSubtitles.ts
var TIMING = /(\d+):(\d{2}):(\d{2})[.,](\d{1,3})\s*-->\s*(\d+):(\d{2}):(\d{2})[.,](\d{1,3})/;
function seconds(h, m, s, fraction) {
  return Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(fraction) / 10 ** fraction.length;
}
function plainText(lines) {
  return decodeCueEntities(stripSubtitleMarkup(lines.join("\n"))).trim();
}
var NAMED_ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\xA0", lrm: "\u200E", rlm: "\u200F" };
function decodeCueEntities(text) {
  if (!text.includes("&")) return text;
  return text.replace(/&(#x[0-9a-f]{1,6}|#[0-9]{1,7}|[a-z]{2,6});/gi, (whole, name) => {
    if (name[0] === "#") {
      const code = name[1] === "x" || name[1] === "X" ? parseInt(name.slice(2), 16) : parseInt(name.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code <= 1114111 ? String.fromCodePoint(code) : whole;
    }
    return NAMED_ENTITIES[name.toLowerCase()] ?? whole;
  });
}
function parseSubtitles(text) {
  const cues = [];
  for (const block of text.replace(/\r/g, "").split(/\n{2,}/)) {
    const lines = block.split("\n");
    const at = lines.findIndex((line) => TIMING.test(line));
    if (at === -1) continue;
    const [, h1, m1, s1, f1, h2, m2, s2, f2] = TIMING.exec(lines[at]);
    const body = plainText(lines.slice(at + 1));
    if (!body) continue;
    cues.push({
      startSeconds: seconds(h1, m1, s1, f1),
      endSeconds: seconds(h2, m2, s2, f2),
      text: body
    });
  }
  return cues.sort((a, b) => a.startSeconds - b.startSeconds);
}
var ExternalSubtitleTrack = class _ExternalSubtitleTrack {
  constructor(id, cues) {
    this.id = id;
    this.cues = cues;
  }
  id;
  cues;
  static async load(source, signal) {
    const res = await fetch(source.url, withHostHeaders({ signal }));
    if (!res.ok) throw new Error(`sous-titres indisponibles (${res.status})`);
    return new _ExternalSubtitleTrack(source.id, parseSubtitles(await res.text()));
  }
  get count() {
    return this.cues.length;
  }
  /**
   * Une piste déjà en mémoire — les lignes d'une génération finie, gardées telles quelles le temps
   * que le fichier final arrive (DECISIONS.md §70) : basculer dessus ne coûte aucune requête, donc
   * aucune seconde sans texte.
   */
  static fromCues(id, cues) {
    return new _ExternalSubtitleTrack(id, [...cues].sort((a, b) => a.startSeconds - b.startSeconds));
  }
  textAt(seconds2) {
    return cueTextAt(this.cues, seconds2);
  }
};
function cueTextAt(cues, seconds2) {
  let low = 0;
  let high = cues.length;
  while (low < high) {
    const mid = low + high >> 1;
    if (cues[mid].startSeconds <= seconds2) low = mid + 1;
    else high = mid;
  }
  const covering = [];
  for (let i = low - 1; i >= 0 && i >= low - 32; i--) {
    const cue = cues[i];
    if (cue.startSeconds <= seconds2 && cue.endSeconds >= seconds2) covering.push(cue);
  }
  return simultaneousText(covering);
}

// src/engine/decoderWarmup.ts
function warmPlayerDecoders() {
  try {
    const connection = navigator.connection;
    if (connection?.saveData) return;
    void import("./lumen-flac-YGIJ4G6V.js").catch(() => {
    });
    void import("./lumen-truehdDecoder-B2LXJK4T.js").then((m) => Promise.all([m.warmAc3Dts(), m.warmTrueHd()])).catch(() => {
    });
  } catch {
  }
}

// src/support/headerWarmup.ts
var HEADER_WARMUP_DELAY_MS = 1e3;
var RESUME_ZONE_CHUNKS = 7;
var RESUME_FROM_SECONDS = 5;
var current = null;
function savesData() {
  const connection = navigator.connection;
  return connection?.saveData === true;
}
function scheduleHeaderWarmup(file, delayMs = HEADER_WARMUP_DELAY_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => {
    if (controller.signal.aborted || document.hidden || savesData()) return;
    void warmHeader(file, controller);
  }, delayMs);
  return () => {
    clearTimeout(timer);
    controller.abort();
  };
}
async function warmHeader(file, controller) {
  current?.abort();
  current = controller;
  const { signal } = controller;
  try {
    if (holdsHandover(file.streamUrl)) return;
    const key = mediaHeaderKey(file.streamUrl, file.fileVersion);
    if (file.fileVersion && holdsPrepared(key)) return;
    const startedAt = Date.now();
    const source = (await HttpByteSource.open(file.streamUrl, file.knownSize ?? null, null)).withoutReadahead();
    const stop = () => source.close(false);
    signal.addEventListener("abort", stop, { once: true });
    try {
      if (signal.aborted) return;
      const parsed = await openMediaFile(source, key);
      if (signal.aborted) return;
      const resume = file.resumeSeconds ?? 0;
      if (resume > RESUME_FROM_SECONDS) {
        const zone = keptRangeAt(parsed, resume, parsed.tracks.find((t) => t.type === "video")?.number, 0);
        if (zone) {
          const first = Math.max(0, Math.floor(zone.from / CHUNK_SIZE) - 1);
          const last2 = Math.min(Math.floor(Math.min(zone.to, source.size - 1) / CHUNK_SIZE), first + RESUME_ZONE_CHUNKS - 1);
          await Promise.all(Array.from({ length: last2 - first + 1 }, (_, i) => source.read((first + i) * CHUNK_SIZE, 1)));
        }
        if (signal.aborted) return;
      }
      trace(`fiche : en-t\xEAte et index pr\xE9par\xE9s en ${Date.now() - startedAt} ms`);
      if (file.fileVersion) source.closePrepared(key);
    } finally {
      signal.removeEventListener("abort", stop);
      stop();
    }
  } catch {
  } finally {
    if (current === controller) current = null;
  }
}
export {
  ExternalSubtitleTrack,
  NetworkUnavailable,
  RemuxPlayback,
  SessionEnded,
  configureHost,
  networkUnstable,
  probePlaybackPath,
  scheduleHeaderWarmup,
  subscribeNetworkTrouble,
  traceElapsed,
  traceRecent,
  traceText,
  warmPlayerDecoders
};
//# sourceMappingURL=lumen-core.js.map
