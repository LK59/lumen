"use strict";
(() => {
  // src/journal.ts
  var MIN_WAIT_MS = 250;
  var KEPT = 50;
  var PlaybackRecorder = class {
    entry;
    constructor(itemId, title) {
      this.entry = { itemId, title, player: "jellyfin", playMethod: null, transcodeReasons: null, refusal: null, audio: null, firstFrameMs: null, openingSteps: null, seeksMs: [], streamChangesMs: [], waits: 0, waitsMs: 0, watchedSeconds: 0, rebuilds: 0, errors: 0 };
    }
    get itemId() {
      return this.entry.itemId;
    }
    /** Une image est-elle déjà venue ? Avant elle, tout arrêt fait partie de l'ouverture. */
    get opened() {
      return this.entry.firstFrameMs !== null;
    }
    /** Ce que le serveur sert pour ce flux — redit à chaque changement de flux, le dernier compte. */
    stream(facts) {
      Object.assign(this.entry, facts);
    }
    refused(reason) {
      this.entry.refusal = reason.slice(0, 300);
    }
    /** La première image d'un flux : celle de l'ouverture, ou celle qui suit un changement de flux. */
    frame(ms) {
      if (this.entry.firstFrameMs === null) this.entry.firstFrameMs = Math.round(ms);
      else if (this.entry.streamChangesMs.length < KEPT) this.entry.streamChangesMs.push(Math.round(ms));
    }
    opening(steps) {
      this.entry.openingSteps = steps;
    }
    openingTrace(trace) {
      const openings = this.entry.openings ??= [];
      if (openings.length < 4) openings.push(trace);
    }
    seek(ms) {
      if (this.entry.seeksMs.length < KEPT) this.entry.seeksMs.push(Math.round(ms));
    }
    wait(ms) {
      if (ms < MIN_WAIT_MS) return;
      this.entry.waits += 1;
      this.entry.waitsMs += Math.round(ms);
    }
    watched(seconds) {
      if (seconds > 0 && seconds < 2) this.entry.watchedSeconds += seconds;
    }
    rebuilt() {
      this.entry.rebuilds += 1;
    }
    error() {
      this.entry.errors += 1;
    }
    finish() {
      return { ...this.entry, watchedSeconds: Math.round(this.entry.watchedSeconds) };
    }
  };
  function transcodeReasonsOf(url) {
    const match = /[?&]TranscodeReasons=([^&]+)/i.exec(url ?? "");
    return match ? decodeURIComponent(match[1]) : null;
  }

  // src/rules.ts
  var PLUGIN_NAME = "lumenPlayer";
  function eligible(item) {
    if (!item?.Id || item.MediaType !== "Video" || item.IsPlaceHolder) return false;
    if (item.LocationType && item.LocationType !== "FileSystem") return false;
    if (item.VideoType && item.VideoType !== "VideoFile") return false;
    return !["TvChannel", "LiveTvChannel", "Program", "LiveTvProgram", "Recording"].includes(item.Type ?? "");
  }
  function streamAddress(server, itemId, mediaSourceId) {
    return `${server.replace(/\/+$/, "")}/Videos/${encodeURIComponent(itemId)}/stream?static=true&mediaSourceId=${encodeURIComponent(mediaSourceId)}`;
  }
  function lumenProfile(base) {
    return { ...base, DirectPlayProfiles: [{ Type: "Video" }], CodecProfiles: [], ContainerProfiles: [] };
  }
  function audioTrackFor(streams, wantedIndex, trackNumbers) {
    if (wantedIndex === null || wantedIndex === void 0 || wantedIndex < 0) return null;
    const internal = (streams ?? []).filter((s) => s.Type === "Audio" && !s.IsExternal).sort((a, b) => (a.Index ?? 0) - (b.Index ?? 0));
    const rank = internal.findIndex((s) => s.Index === wantedIndex);
    if (rank < 0 || internal.length !== trackNumbers.length) return null;
    return trackNumbers[rank] ?? null;
  }
  function televisionClient(userAgent) {
    return /web0s|webos|tizen|smart-?tv|netcast|vidaa|viera|hbbtv|playstation|xbox/i.test(userAgent);
  }

  // src/bridge.ts
  var w = window;
  var script = document.currentScript;
  var config = { enabled: true, base: script?.src ? new URL(".", script.src).href : new URL("lumen/", document.baseURI).href, build: "dev", ...w.LumenConfig ?? {} };
  var log = (...args) => console.info("[Lumen]", ...args);
  var states = /* @__PURE__ */ new WeakMap();
  var instance = null;
  var VERDICT_MS = 10 * 6e4;
  var REFUSALS_BEFORE_HANDOVER = 4;
  var REFUSAL_WINDOW_MS = 1e4;
  var SETTINGS_MS = 5e3;
  var STANDBY_MS = 2e4;
  var ORDER_MS = 15e3;
  var CHECK_TIMEOUT_MS = 8e3;
  var core = null;
  function loadCore() {
    core ??= import(
      /* @vite-ignore */
      new URL("lumen-core.js", config.base).href
    ).catch((error) => {
      core = null;
      throw error;
    });
    return core;
  }
  var warmed = false;
  function warmEngine() {
    if (warmed || !config.enabled) return;
    warmed = true;
    const warm = () => void loadCore().then((engine) => engine.warmPlayerDecoders()).catch(() => {
    });
    const idle = window.requestIdleCallback;
    setTimeout(() => idle ? idle(warm, { timeout: 5e3 }) : warm(), 1500);
  }
  var stopSheetWarmup = () => {
  };
  function watchSheets(state) {
    document.addEventListener("viewshow", (event) => {
      stopSheetWarmup();
      stopSheetWarmup = () => {
      };
      try {
        const page = event.target;
        const params = event.detail?.params;
        if (!config.enabled || !page?.classList?.contains("itemDetailPage") || !params?.id) return;
        if (state.playback || state.rebuilding !== null) return;
        let stopped = false;
        stopSheetWarmup = () => stopped = true;
        const api = state.deps.ServerConnections.getApiClient(params.serverId);
        if (typeof api.getItem !== "function") return;
        const id = params.id;
        void settingsOf(state, api).then((answer) => {
          if (stopped || !answer.enabled) return;
          warmEngine();
          return api.getItem(api.getCurrentUserId(), id);
        }).then(async (item) => {
          if (!item) return;
          const source = item.MediaSources?.find((s) => s.Id === item.Id) ?? item.MediaSources?.[0];
          if (stopped || !eligible(item) || !source?.Id) return;
          const verdict = state.verdicts.get(item.Id);
          if (verdict && !verdict.ok && Date.now() - verdict.at < VERDICT_MS) return;
          const engine = await loadCore();
          if (stopped) return;
          hostFor(state, engine, item);
          const cancel = engine.scheduleHeaderWarmup({
            streamUrl: streamAddress(api.serverAddress(), item.Id, source.Id),
            knownSize: source.Size ?? null,
            fileVersion: source.ETag ?? null,
            // Là où ce compte s'était arrêté : « Reprendre » y trouvera ses premiers octets.
            resumeSeconds: (item.UserData?.PlaybackPositionTicks ?? 0) / 1e7
          });
          stopSheetWarmup = () => {
            stopped = true;
            cancel();
          };
        }).catch(() => {
        });
      } catch {
      }
    });
  }
  var NEXT_WARMUP_S = 60;
  var preparedNext = /* @__PURE__ */ new Set();
  function watchForNext(state, element, current) {
    let asked = false;
    const look = () => {
      if (asked || !state.playback || !(element.duration - element.currentTime < NEXT_WARMUP_S)) return;
      asked = true;
      element.removeEventListener("timeupdate", look);
      void (async () => {
        const manager = state.deps.playbackManager;
        if (typeof manager.getPlaylist !== "function" || typeof manager.getCurrentPlaylistIndex !== "function") return;
        const next = (await manager.getPlaylist())[manager.getCurrentPlaylistIndex() + 1];
        if (!next?.Id || next.Id === current.Id || preparedNext.has(next.Id)) return;
        preparedNext.add(next.Id);
        const api = state.deps.ServerConnections.getApiClient(next.ServerId ?? current.ServerId);
        if (typeof api.getItem !== "function") return;
        const item = await api.getItem(api.getCurrentUserId(), next.Id);
        const source = item.MediaSources?.find((s) => s.Id === item.Id) ?? item.MediaSources?.[0];
        if (!eligible(item) || !source?.Id || !state.playback) return;
        const engine = await loadCore();
        stopSheetWarmup();
        stopSheetWarmup = engine.scheduleHeaderWarmup({ streamUrl: streamAddress(api.serverAddress(), item.Id, source.Id), knownSize: source.Size ?? null, fileVersion: source.ETag ?? null }, 0);
      })().catch(() => {
      });
    };
    element.addEventListener("timeupdate", look);
  }
  var LumenPlayer = class {
    name = "Lumen";
    type = "mediaplayer";
    id = "lumenplayer";
    /** Avant le lecteur de jellyfin-web (1) : à type de média égal, le premier de la liste est pris. */
    priority = -1;
    isLocalPlayer = true;
    constructor(deps) {
      const state = { deps, standby: null, order: null, adopted: null, playback: null, opening: 0, verdicts: /* @__PURE__ */ new Map(), settings: /* @__PURE__ */ new Map(), recorder: null, recorderServerId: void 0, askedAt: null, element: null, busy: 0, seekTarget: null, steps: {}, stepsFrom: 0, offered: null, current: null, rebuilds: [], rebuilding: null, seekAfterRebuild: null, lastPosition: 0, wasPaused: false, handedOver: false, onRangeRefused: null };
      states.set(this, state);
      instance = this;
      if (!televisionClient(navigator.userAgent)) watchSheets(state);
    }
    canPlayMediaType(mediaType) {
      return adopt(this) ? this.canPlayMediaType(mediaType) : false;
    }
    // jellyfin-web greffe `getVolume`/`setVolume` sur un lecteur qui ne les a pas, à l'enregistrement —
    // des propriétés de l'objet, qui masqueraient ensuite celles du lecteur adopté. Elles existent donc
    // d'avance ; rien ne les appelle tant que ce lecteur ne lit rien.
    getVolume() {
      return 100;
    }
    setVolume() {
    }
  };
  function adopt(self) {
    const state = states.get(self);
    if (state.adopted !== null) return state.adopted;
    if (televisionClient(navigator.userAgent)) {
      state.adopted = false;
      log("TV or game console: playback left to the web client");
      return false;
    }
    const html = state.deps.playbackManager.getPlayers().find((player) => player.id === "htmlvideoplayer");
    if (!html) return false;
    const Base = html.constructor;
    const own = { ...self };
    const before = Object.getPrototypeOf(self);
    try {
      for (const name of ["getDeviceProfile", "setCurrentSrc", "play", "currentTime", "stop", "destroy", "canPlayMediaType"]) {
        if (typeof Base.prototype[name] !== "function") throw new Error(`le lecteur de jellyfin-web n'a pas de m\xE9thode \xAB ${name} \xBB`);
      }
      Object.setPrototypeOf(self, lumenPrototype(Base.prototype));
      Base.call(self);
      const htmlName = String(self.name || "Html Video Player");
      Object.assign(self, own);
      Object.defineProperty(self, "name", { configurable: true, enumerable: true, get: () => state.playback ? "Lumen" : htmlName });
      state.adopted = true;
      watchPlayOrders(state);
      try {
        const api = state.deps.ServerConnections.currentApiClient?.();
        if (api?.accessToken()) void settingsOf(state, api).then((answer) => answer.enabled && warmEngine());
      } catch {
      }
      log("ready, plugged into the web client's video player");
    } catch (error) {
      Object.setPrototypeOf(self, before);
      state.adopted = false;
      console.warn("[Lumen] inactive: the video player of this web client version cannot be extended:", error);
    }
    return state.adopted;
  }
  function watchPlayOrders(state) {
    try {
      const manager = state.deps.playbackManager;
      const play = manager.play;
      if (typeof play !== "function") return;
      manager.play = function(options, ...rest) {
        try {
          state.order = { at: performance.now(), seconds: (Number(options?.startPositionTicks) || 0) / 1e7 };
        } catch {
        }
        return play.call(this, options, ...rest);
      };
    } catch {
    }
  }
  function lumenPrototype(base) {
    return Object.assign(Object.create(base), {
      canPlayMediaType(mediaType) {
        return config.enabled && (mediaType ?? "").toLowerCase() === "video";
      },
      /** Seulement les fichiers vidéo de la bibliothèque : pour le reste, jellyfin-web prend son lecteur. */
      canPlayItem(item) {
        return config.enabled && eligible(item);
      },
      /**
       * Le profil annoncé au serveur — c'est ici que se décide qui lira.
       *
       * jellyfin-web le demande avant de négocier la lecture. On pose donc la question au moteur à ce
       * moment-là, sur le fichier : s'il le porte, le profil dit « lecture directe » et le serveur répond
       * par l'adresse du fichier brut ; s'il le refuse, le profil est celui de jellyfin-web et tout se
       * passe comme sans Lumen, transcodage compris. Le refus ne coûte ainsi ni erreur à l'écran ni
       * seconde négociation.
       *
       * `isRetry` : jellyfin-web renégocie après une erreur de lecture, pour obtenir un transcodage. Ce
       * n'est plus le moment de proposer le chemin qui vient d'échouer.
       */
      async getDeviceProfile(item, options) {
        const state = states.get(this);
        state.askedAt = performance.now();
        state.stepsFrom = state.askedAt;
        state.steps = {};
        state.offered = null;
        stopSheetWarmup();
        if (options?.isRetry) state.recorder?.error();
        const asked = base.getDeviceProfile.call(this, item, options);
        if (!config.enabled || options?.isRetry || !eligible(item)) {
          dropStandby(state);
          return asked;
        }
        const allowing = settings(state, item);
        const speculate = state.playback === null && state.rebuilding === null;
        const checking = settingsHint(state, item) === true ? check(this, item, speculate) : null;
        checking?.catch(() => {
        });
        const profile = await asked;
        step(state, "profile");
        const allowed = (await allowing).enabled;
        step(state, "settings");
        if (!allowed) {
          dropStandby(state);
          return profile;
        }
        const verdict = await (checking ?? check(this, item, speculate));
        step(state, "check");
        if (!verdict?.ok) return profile;
        state.offered = item.Id ?? null;
        return lumenProfile(profile);
      },
      /**
       * La source. jellyfin-web appelle ceci avec l'élément `<video>` qu'il vient de créer et ce que le
       * serveur a répondu.
       *
       * Hors lecture directe d'un fichier accepté, c'est le lecteur de jellyfin-web tel quel. Sinon, sa
       * méthode est tout de même appelée — elle prépare les sous-titres, la piste son, l'état que le reste
       * du lecteur relit — mais sur un élément dont deux gestes sont détournés : poser `src` ne fait rien,
       * et `play()` ouvre Lumen sur le vrai élément avant de lancer la lecture. Un échec de l'ouverture
       * rejette `play()`, que jellyfin-web traite comme toute erreur de lecture : il renégocie.
       */
      /**
       * Le départ d'un flux : une ouverture, ou un changement de flux pendant la lecture (piste son,
       * qualité, repli). Rien n'est changé à ce que fait jellyfin-web ; le journal de la lecture s'ouvre ici.
       */
      async play(options) {
        const state = states.get(this);
        const item = options.item;
        step(state, "answered");
        claimPlaybackAudio();
        if (item?.Id && (await settings(state, item)).journal) {
          if (state.recorder?.itemId !== item.Id) {
            flush(state);
            state.recorderServerId = item.ServerId;
            state.recorder = new PlaybackRecorder(item.Id, [item.SeriesName, item.Name].filter(Boolean).join(", "));
          }
          const verdict = state.verdicts.get(item.Id);
          if (verdict && !verdict.ok && verdict.reason) state.recorder.refused(verdict.reason);
        } else {
          state.recorder = null;
        }
        if (item?.Id && state.offered === item.Id) skipOpeningAnimation();
        return base.play.call(this, options);
      },
      async setCurrentSrc(element, options) {
        const state = states.get(this);
        close(state);
        step(state, "negotiated");
        observe(state, element, options);
        alignSubtitles(state, element);
        const verdict = options.item?.Id ? state.verdicts.get(options.item.Id) : void 0;
        if (!config.enabled || options.playMethod !== "DirectPlay" || !verdict || !options.mediaSource?.Id || !options.item?.Id || state.offered !== options.item.Id) {
          return base.setCurrentSrc.call(this, element, options);
        }
        const self = this;
        const shield = new Proxy(element, {
          set(target, property, value) {
            if (property !== "src" && property !== "autoplay") target[property] = value;
            return true;
          },
          get(target, property) {
            if (property === "play") {
              return () => {
                if (!verdict.ok) return Promise.reject(new Error(verdict.reason ?? "Lumen declined this file"));
                watchForNext(state, target, options.item);
                state.current = { element: target, options };
                state.rebuilds = [];
                state.wasPaused = false;
                return open(self, target, options);
              };
            }
            if (property === "addEventListener") return (type, ...rest) => type === "error" ? void 0 : target.addEventListener(type, ...rest);
            const value = target[property];
            return typeof value === "function" ? value.bind(target) : value;
          }
        });
        return base.setCurrentSrc.call(this, shield, options);
      },
      /** La position, en millisecondes. Un saut passe par le moteur ; la position lue est celle du film. */
      currentTime(ms) {
        const state = states.get(this);
        const playback = state.playback;
        const seeking = ms !== void 0 && ms !== null;
        if (seeking) timeSeek(state);
        if (state.rebuilding !== null) {
          if (seeking) state.seekAfterRebuild = ms / 1e3;
          return seeking ? void 0 : (state.seekAfterRebuild ?? state.rebuilding) * 1e3;
        }
        if (!playback) return base.currentTime.call(this, ms);
        if (seeking) {
          const seconds = ms / 1e3;
          const element = state.element;
          if (element && !playback.seekPending && !element.seeking && loadedAt(element, seconds)) {
            state.seekTarget = null;
            element.currentTime = seconds;
          } else {
            state.seekTarget = seconds;
            void playback.seek(seconds);
          }
          return void 0;
        }
        if (state.seekTarget !== null && !playback.seekPending) state.seekTarget = null;
        const position = playback.lost && playback.position === 0 ? state.lastPosition : playback.position;
        return (state.seekTarget ?? position) * 1e3;
      },
      /**
       * Changer de piste son : Lumen le fait lui-même, en rouvrant le fichier sur la nouvelle piste à la
       * position courante (`switchAudio`) — le moteur ne change jamais de piste dans le tampon vivant.
       *
       * Répondre « non » ici faisait renégocier le flux par jellyfin-web : le profil redemandé, un
       * aller-retour au serveur, puis `setCurrentSrc` — pour aboutir à la même réouverture. Seulement
       * quand le moteur porte toutes les pistes du fichier : sinon la piste choisie pourrait être celle
       * qu'il refuse, et c'est la renégociation qui sait alors passer la main au serveur.
       */
      canSetAudioStreamIndex() {
        const state = states.get(this);
        const playback = state.playback;
        if (!playback) return base.canSetAudioStreamIndex.call(this);
        return state.current !== null && state.rebuilding === null && playback.audioTracks.every((track) => playback.canCarryAudio(track.number));
      },
      setAudioStreamIndex(index) {
        const state = states.get(this);
        if (!state.playback || !state.current) return base.setAudioStreamIndex.call(this, index);
        switchAudio(this, index);
      },
      /**
       * Les statistiques du panneau « Playback Info » : celles de jellyfin-web, et quand Lumen lit, ce que
       * le moteur fait du fichier — c'est là qu'on vérifie d'un coup d'œil qui lit, et comment.
       */
      async getStats() {
        const stats = await base.getStats?.call(this) ?? {};
        const diagnostics = states.get(this).playback?.diagnostics;
        if (!diagnostics) return stats;
        const lines = [
          ["Video", diagnostics["Vid\xE9o"]],
          ["Audio", diagnostics["Audio"]?.replace(/ canaux?$/, " ch")],
          ["Audio handling", englishAudio(diagnostics["Traitement audio"])],
          ["Buffered ahead", diagnostics["Avance sur la t\xEAte"]]
        ].filter((line) => !!line[1]);
        return { ...stats, categories: [...stats.categories ?? [], { type: "lumen", name: "Lumen", stats: lines.map(([label, value]) => ({ label, value })) }] };
      },
      stop(destroyPlayer) {
        releasePlaybackAudio();
        flush(states.get(this));
        close(states.get(this));
        dropStandby(states.get(this));
        return base.stop.call(this, destroyPlayer);
      },
      destroy() {
        releasePlaybackAudio();
        flush(states.get(this));
        close(states.get(this));
        dropStandby(states.get(this));
        base.destroy.call(this);
      }
    });
  }
  var audioSessionBefore = null;
  function claimPlaybackAudio() {
    try {
      const session = navigator.audioSession;
      if (!session || typeof session.type !== "string" || session.type === "playback") return;
      audioSessionBefore ??= session.type;
      session.type = "playback";
    } catch {
    }
  }
  function releasePlaybackAudio() {
    try {
      const session = navigator.audioSession;
      if (session && audioSessionBefore !== null) session.type = audioSessionBefore;
    } catch {
    }
    audioSessionBefore = null;
  }
  function englishAudio(text) {
    if (text === "copi\xE9 tel quel") return "copied as is";
    const encoded = /^décodé puis ré-encodé en (.+)$/.exec(text ?? "");
    return encoded ? `decoded here, re-encoded to ${encoded[1]}` : text;
  }
  function close(state, rebuilding = false) {
    if (!rebuilding) {
      state.handedOver = false;
      state.current = null;
      state.rebuilding = null;
      state.seekAfterRebuild = null;
    }
    state.opening += 1;
    state.onRangeRefused = null;
    if (state.element) releasePicture(state.element);
    const playback = state.playback;
    state.playback = null;
    state.seekTarget = null;
    try {
      playback?.destroy();
    } catch (error) {
      console.warn("[Lumen] closing:", error);
    }
  }
  function settings(state, item) {
    return settingsOf(state, state.deps.ServerConnections.getApiClient(item.ServerId));
  }
  function settingsOf(state, api) {
    const key = `${api.serverAddress()}|${api.getCurrentUserId()}`;
    const known = state.settings.get(key);
    let answer = known && Date.now() - known.at < SETTINGS_MS ? known.answer : null;
    if (!answer) {
      answer = fetch(`${api.serverAddress().replace(/\/+$/, "")}/Lumen/Settings`, { headers: { Authorization: `MediaBrowser Token="${api.accessToken()}"` } }).then(async (response) => {
        if (response.status === 401 || response.status === 403) return { enabled: false, journal: false };
        if (!response.ok) return { enabled: true, journal: false };
        const answered = await response.json();
        settingsSeen.set(key, answered.Enabled !== false);
        if (answered.Enabled === false) log("regular player: Lumen does not play for this user (plugin settings)");
        return { enabled: answered.Enabled !== false, journal: answered.Journal === true };
      }).catch(() => ({ enabled: true, journal: false }));
      state.settings.set(key, { at: Date.now(), answer });
    }
    return answer;
  }
  var settingsSeen = /* @__PURE__ */ new Map();
  function settingsHint(state, item) {
    try {
      const api = state.deps.ServerConnections.getApiClient(item.ServerId);
      return settingsSeen.get(`${api.serverAddress()}|${api.getCurrentUserId()}`) ?? null;
    } catch {
      return null;
    }
  }
  function skipOpeningAnimation() {
    try {
      if (document.querySelector(".videoPlayerContainer")) return;
      const announce = (node) => {
        if (!(node instanceof HTMLElement) || !node.classList.contains("videoPlayerContainer")) return false;
        holdPictureUntilZoomed(node);
        for (const type of ["animationend", "webkitAnimationEnd"]) node.dispatchEvent(new Event(type));
        return true;
      };
      const observer = new MutationObserver((records) => {
        for (const record of records) {
          for (const node of Array.from(record.addedNodes)) {
            if (!announce(node)) continue;
            observer.disconnect();
            clearTimeout(timer);
            return;
          }
        }
      });
      const timer = setTimeout(() => observer.disconnect(), 3e3);
      observer.observe(document.body, { childList: true });
    } catch {
    }
  }
  function holdPictureUntilZoomed(container) {
    const video = container.querySelector("video");
    if (!video || !container.style.animation) return;
    holdPicture(video, "zoom");
    const types = ["animationend", "webkitAnimationEnd", "animationcancel"];
    const show = (event) => {
      if (event && !event.isTrusted) return;
      releasePicture(video, "zoom");
      clearTimeout(guard);
      for (const type of types) container.removeEventListener(type, show);
    };
    for (const type of types) container.addEventListener(type, show);
    const guard = setTimeout(show, 400);
  }
  var pictureHolds = /* @__PURE__ */ new WeakMap();
  function holdPicture(element, reason) {
    const reasons = pictureHolds.get(element) ?? /* @__PURE__ */ new Set();
    pictureHolds.set(element, reasons);
    reasons.add(reason);
    element.style.visibility = "hidden";
  }
  function releasePicture(element, reason) {
    const reasons = pictureHolds.get(element);
    if (!reasons) return;
    if (reason !== void 0) reasons.delete(reason);
    else for (const held of Array.from(reasons)) if (held !== "zoom") reasons.delete(held);
    if (reasons.size === 0) element.style.visibility = "";
  }
  var HOLD_FROM_SECONDS = 1;
  var HOLD_TOLERANCE_SECONDS = 1;
  var HOLD_GUARD_MS = 1500;
  var HOLD_CAP_MS = 15e3;
  var TRACED_FRAMES = 8;
  var holdCount = 0;
  function watchOpening(state, element, target, alive) {
    const reason = `position#${holdCount += 1}`;
    try {
      const from = performance.now();
      const since = () => Math.round(performance.now() - from);
      const holding = target >= HOLD_FROM_SECONDS;
      const marks = {};
      const frames = [];
      let shown = null;
      let reported = false;
      let guard;
      const ahead = () => {
        const { buffered, currentTime } = element;
        for (let i = 0; i < buffered.length; i += 1) if (buffered.start(i) <= currentTime + 0.1 && currentTime <= buffered.end(i)) return Math.round((buffered.end(i) - currentTime) * 10) / 10;
        return 0;
      };
      const types = ["loadeddata", "canplay", "canplaythrough", "seeked", "play", "playing", "waiting", "stalled", "pause", "timeupdate"];
      const show = (by) => {
        if (shown) return;
        shown = { heldMs: since(), shownBy: by };
        clearTimeout(guard);
        if (holding) releasePicture(element, reason);
      };
      const report = (why) => {
        if (reported) return;
        reported = true;
        show(why ?? "report");
        clearTimeout(cap);
        for (const type of types) element.removeEventListener(type, onEvent);
        if (alive()) state.recorder?.openingTrace({ target: Math.round(target * 10) / 10, ...holding && shown ? shown : {}, marks, frames });
      };
      const there = (seconds) => !element.seeking && seconds >= target - HOLD_TOLERANCE_SECONDS;
      const onEvent = (event) => {
        if (!alive()) return report("replaced");
        marks[event.type] ??= since();
        if (shown) return;
        if (holding) guard ??= setTimeout(() => show("guard"), HOLD_GUARD_MS);
        if (!holding || element.readyState >= 2 && there(element.currentTime)) show("position");
      };
      for (const type of types) element.addEventListener(type, onEvent);
      const cap = setTimeout(() => report("cap"), HOLD_CAP_MS);
      if (holding) holdPicture(element, reason);
      if (typeof element.requestVideoFrameCallback !== "function") return;
      const onFrame = (_now, meta) => {
        if (!alive()) return report("replaced");
        if (reported) return;
        frames.push([since(), Math.round(meta.mediaTime * 100) / 100, Math.round(element.currentTime * 100) / 100, element.seeking ? 1 : 0, ahead(), element.readyState]);
        if (!holding || there(meta.mediaTime)) show("frame");
        if (frames.length >= TRACED_FRAMES) return report();
        element.requestVideoFrameCallback?.(onFrame);
      };
      element.requestVideoFrameCallback(onFrame);
    } catch {
      releasePicture(element, reason);
    }
  }
  function nextFrame(element, cap = 12e4) {
    return new Promise((resolve) => {
      const until = performance.now() + cap;
      const arrived = () => {
        if (!element.seeking) return resolve(performance.now());
        if (performance.now() > until || !element.isConnected) return resolve(null);
        element.requestVideoFrameCallback?.(arrived);
      };
      if (typeof element.requestVideoFrameCallback !== "function") return resolve(null);
      element.requestVideoFrameCallback(arrived);
      setTimeout(() => resolve(null), cap);
    });
  }
  var watched = /* @__PURE__ */ new WeakSet();
  function observe(state, element, options) {
    const recorder = state.recorder;
    state.element = element;
    try {
      if (recorder) {
        const startedAt = state.askedAt ?? performance.now();
        state.askedAt = null;
        state.busy += 1;
        void nextFrame(element).then((at) => {
          state.busy -= 1;
          if (state.recorder !== recorder || at === null) return;
          recorder.stream({
            player: state.playback ? "lumen" : "jellyfin",
            playMethod: options.playMethod ?? null,
            transcodeReasons: transcodeReasonsOf(options.url),
            audio: state.playback?.diagnostics["Traitement audio"] ?? null
          });
          if (!recorder.opened) recorder.opening({ ...state.steps });
          recorder.frame(at - startedAt);
        });
      }
      if (watched.has(element)) return;
      watched.add(element);
      let waitingSince = null;
      let lastTime = null;
      element.addEventListener("waiting", () => {
        if (state.busy === 0 && !element.seeking && state.recorder?.opened) waitingSince ??= performance.now();
      });
      const resumed = () => {
        if (waitingSince !== null) state.recorder?.wait(performance.now() - waitingSince);
        waitingSince = null;
      };
      element.addEventListener("playing", resumed);
      for (const type of ["pause", "play", "playing"]) {
        element.addEventListener(type, () => {
          if (state.playback && !state.playback.lost && state.rebuilding === null && element.readyState > 0) state.wasPaused = element.paused;
        });
      }
      element.addEventListener("seeking", () => waitingSince = null);
      element.addEventListener("timeupdate", () => {
        if (state.playback && !element.seeking && element.currentTime > 0) state.lastPosition = element.currentTime;
        if (lastTime !== null) state.recorder?.watched(element.currentTime - lastTime);
        lastTime = element.currentTime;
      });
    } catch {
    }
  }
  var aligned = /* @__PURE__ */ new WeakSet();
  var shifted = /* @__PURE__ */ new WeakSet();
  function alignSubtitles(state, element) {
    if (aligned.has(element)) return;
    aligned.add(element);
    element.addEventListener("timeupdate", () => {
      try {
        const delay = state.playback?.presentationDelay ?? 0;
        if (!(delay > 0.02)) return;
        for (const track of Array.from(element.textTracks)) {
          const cues = track.cues;
          if (!cues || cues.length === 0 || shifted.has(cues[0]) && shifted.has(cues[cues.length - 1])) continue;
          for (const cue of Array.from(cues)) {
            if (shifted.has(cue)) continue;
            shifted.add(cue);
            cue.endTime += delay;
            cue.startTime += delay;
          }
        }
      } catch {
      }
    });
  }
  function step(state, name) {
    if (!(name in state.steps)) state.steps[name] = Math.round(performance.now() - state.stepsFrom);
  }
  var LOADED_MARGIN_S = 1;
  function loadedAt(element, seconds) {
    const spans = element.buffered;
    for (let i = 0; i < spans.length; i += 1) {
      if (seconds >= spans.start(i) && seconds <= spans.end(i) - LOADED_MARGIN_S) return true;
    }
    return false;
  }
  function timeSeek(state) {
    const recorder = state.recorder;
    const element = state.element;
    if (!recorder || !element) return;
    const startedAt = performance.now();
    state.busy += 1;
    setTimeout(() => {
      void nextFrame(element, 6e4).then((at) => {
        state.busy -= 1;
        if (state.recorder === recorder && at !== null) recorder.seek(at - startedAt);
      });
    }, 0);
  }
  function flush(state) {
    const recorder = state.recorder;
    state.recorder = null;
    if (!recorder) return;
    try {
      const entry = recorder.finish();
      if (entry.firstFrameMs === null && entry.errors === 0 && !entry.refusal) return;
      const api = state.deps.ServerConnections.getApiClient(state.recorderServerId);
      void fetch(`${api.serverAddress().replace(/\/+$/, "")}/Lumen/Journal`, {
        method: "POST",
        keepalive: true,
        headers: { "Content-Type": "application/json", Authorization: `MediaBrowser Token="${api.accessToken()}"` },
        body: JSON.stringify(entry)
      }).catch(() => {
      });
    } catch (error) {
      console.debug("[Lumen] journal non envoy\xE9 :", error);
    }
  }
  function hostFor(state, core2, item) {
    const api = state.deps.ServerConnections.getApiClient(item.ServerId);
    core2.configureHost({
      build: config.build,
      requestHeaders: () => ({ Authorization: `MediaBrowser Token="${api.accessToken()}"` }),
      rangeRefused: (status) => state.onRangeRefused?.(status)
    });
    return api;
  }
  var optimistic = wasmAllowed();
  function wasmAllowed() {
    try {
      new WebAssembly.Module(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0]));
      return true;
    } catch {
      return false;
    }
  }
  var lastStandby = "none";
  function ask(state, engine, item, source, startSeconds, more, hooks) {
    const api = hostFor(state, engine, item);
    const video = source?.MediaStreams?.find((s) => s.Type === "Video");
    const { picked, ...options } = more;
    return engine.probePlaybackPath({
      streamUrl: streamAddress(api.serverAddress(), item.Id, source?.Id ?? item.Id),
      knownSize: source?.Size ?? null,
      fileVersion: source?.ETag ?? null,
      videoRangeType: video?.VideoRangeType ?? null,
      startSeconds,
      // La piste que le serveur a retenue (préférences du compte, choix au menu), traduite pour le moteur
      // une fois ses pistes connues : il ouvre dessus, au lieu d'ouvrir sur la sienne puis de recommencer.
      pickAudioTrack: (tracks) => {
        const track = audioTrackFor(source?.MediaStreams, source?.DefaultAudioStreamIndex, tracks.map((t) => t.number));
        picked?.(track);
        return track;
      },
      onWarning: (warning) => hooks.onWarning(warning),
      onError: (message, kind) => hooks.onError(message, kind),
      ...options
    });
  }
  function dropStandby(state) {
    const standby = state.standby;
    state.standby = null;
    if (!standby || standby.spent) return;
    standby.spent = true;
    clearTimeout(standby.timer);
    void standby.probe.then((probe) => probe.discard()).catch(() => {
    });
  }
  function takeStandby(state, itemId, mediaSourceId) {
    const standby = state.standby;
    if (!standby || standby.spent || standby.itemId !== itemId || standby.mediaSourceId !== mediaSourceId) return null;
    state.standby = null;
    standby.spent = true;
    clearTimeout(standby.timer);
    return standby;
  }
  function expectedStart(state) {
    return state.order && performance.now() - state.order.at < ORDER_MS ? state.order.seconds : 0;
  }
  async function check(self, item, speculate = true) {
    const state = states.get(self);
    const id = item.Id;
    const known = state.verdicts.get(id);
    const fresh = known && Date.now() - known.at < VERDICT_MS ? known : null;
    if (fresh && (!fresh.ok || !speculate)) return fresh;
    const source = item.MediaSources?.find((s) => s.Id === id) ?? item.MediaSources?.[0];
    const mediaSourceId = source?.Id ?? id;
    let engine;
    try {
      engine = await loadCore();
    } catch (error) {
      log("engine not found, regular player:", error instanceof Error ? error.message : error);
      return null;
    }
    const refusal = (error) => {
      const reason = error instanceof Error ? error.message : String(error);
      if (error instanceof engine.NetworkUnavailable || error instanceof engine.SessionEnded) {
        log("could not check the file, regular player:", reason);
        return null;
      }
      const verdict = { at: Date.now(), ok: false, reason, mediaSourceId };
      state.verdicts.set(id, verdict);
      log("declined, regular player:", reason);
      return verdict;
    };
    const startSeconds = expectedStart(state);
    let standby = state.standby;
    if (!standby || standby.spent || standby.itemId !== id || standby.mediaSourceId !== mediaSourceId || standby.startSeconds !== startSeconds) {
      dropStandby(state);
      let announce;
      const viable = new Promise((resolve) => announce = resolve);
      const hooks = { onWarning: () => {
      }, onError: () => {
      } };
      let picked;
      let probe;
      try {
        probe = ask(state, engine, item, source, startSeconds, { onViable: announce, picked: (track) => picked = track }, hooks);
      } catch (error) {
        return refusal(error);
      }
      const mine = { itemId: id, mediaSourceId, startSeconds, probe, viable, hooks, picked: () => picked, spent: false, timer: setTimeout(() => state.standby === mine && dropStandby(state), STANDBY_MS) };
      standby = state.standby = mine;
      probe.catch((error) => {
        if (state.standby === mine) state.standby = null;
        clearTimeout(mine.timer);
        if ((fresh || state.verdicts.get(id)?.ok) && refusal(error)) {
          optimistic = false;
          log("verdicts will wait for the full check from now on (a file was declined after being accepted)");
        }
      });
    }
    if (fresh) return fresh;
    const timeout = new Promise((resolve) => setTimeout(() => resolve("timeout"), CHECK_TIMEOUT_MS));
    try {
      const first = await Promise.race(optimistic ? [standby.viable, standby.probe, timeout] : [standby.probe, timeout]);
      if (first === "timeout") {
        if (state.standby === standby) dropStandby(state);
        log(`checking the file took too long (${CHECK_TIMEOUT_MS / 1e3} s), regular player`);
        return null;
      }
      const verdict = { at: Date.now(), ok: true, mediaSourceId };
      state.verdicts.set(id, verdict);
      return verdict;
    } catch (error) {
      return refusal(error);
    }
  }
  async function open(self, element, options, resume) {
    const state = states.get(self);
    const mine = ++state.opening;
    const item = options.item;
    const source = options.mediaSource;
    step(state, "play");
    const engine = await loadCore();
    const startSeconds = resume?.seconds ?? (options.playerStartPositionTicks ?? 0) / 1e7;
    const hooks = {
      onWarning: (warning) => log("engine warning:", warning.code, warning.detail ?? ""),
      // Le moteur a épuisé ses reprises sur cette source. On la rouvre à la même position, quelques
      // fois ; au-delà, c'est une erreur de lecture pour jellyfin-web, qui renégocie et transcode.
      onError: (message, kind) => {
        if (states.get(self).opening !== mine) return;
        log("the engine gave up:", message);
        void rebuild(self, kind === "network" ? "network" : "source lost").then((rebuilt) => {
          if (!rebuilt) handOver(self, kind === "network" ? "network" : "mediadecodeerror");
        });
      }
    };
    let refusals = 0;
    let lastRefusal = 0;
    state.onRangeRefused = (status) => {
      if (states.get(self).opening !== mine) return;
      const now = performance.now();
      refusals = now - lastRefusal > REFUSAL_WINDOW_MS ? 1 : refusals + 1;
      lastRefusal = now;
      if (refusals !== REFUSALS_BEFORE_HANDOVER) return;
      log(`the server refuses the file (status ${status}), handing over to the regular player`);
      handOver(self, "network");
    };
    let probe = null;
    const standby = resume ? null : takeStandby(state, item.Id, source.Id);
    lastStandby = "none";
    if (standby) {
      let ready = null;
      try {
        ready = await standby.probe;
      } catch (error) {
        lastStandby = "failed";
        if (!(error instanceof engine.NetworkUnavailable || error instanceof engine.SessionEnded)) throw error;
      }
      if (ready) {
        const wanted = audioTrackFor(source.MediaStreams, source.DefaultAudioStreamIndex, ready.audioTracks.map((track) => track.number));
        if (state.opening === mine && standby.startSeconds === startSeconds && standby.picked() === wanted) {
          standby.hooks.onWarning = hooks.onWarning;
          standby.hooks.onError = hooks.onError;
          probe = ready;
          lastStandby = "reused";
        } else {
          ready.discard();
          lastStandby = "mismatch";
        }
      }
    }
    if (state.opening !== mine) {
      probe?.discard();
      return;
    }
    probe ??= await ask(state, engine, item, source, startSeconds, { startPaused: resume?.paused ?? false }, hooks);
    if (state.opening !== mine) {
      probe.discard();
      return;
    }
    step(state, "probed");
    if (resume?.paused) element.autoplay = false;
    watchOpening(state, element, startSeconds, () => state.opening === mine);
    const playback = await probe.start(element);
    step(state, "started");
    if (state.opening !== mine) {
      playback.destroy();
      return;
    }
    state.playback = playback;
    await (playback.openingHold() ?? Promise.resolve());
    step(state, "released");
    if (state.opening !== mine) return;
    log(`playing: ${playback.diagnostics["Vid\xE9o"] ?? "?"}, audio ${englishAudio(playback.diagnostics["Traitement audio"]) ?? "?"}`);
    if (!resume?.paused) await element.play();
  }
  function handOver(self, type) {
    const state = states.get(self);
    if (state.handedOver) return;
    state.handedOver = true;
    state.deps.events.trigger(self, "error", [{ type }]);
  }
  function switchAudio(self, index) {
    const state = states.get(self);
    const current = state.current;
    const playback = state.playback;
    if (!current || !playback || state.rebuilding !== null) return;
    const source = current.options.mediaSource;
    const wanted = audioTrackFor(source.MediaStreams, index, playback.audioTracks.map((track) => track.number));
    if (wanted === null || wanted === playback.currentAudioTrack) return;
    current.options = { ...current.options, mediaSource: { ...source, DefaultAudioStreamIndex: index } };
    const seconds = playback.position > 0 ? playback.position : state.lastPosition;
    const startedAt = performance.now();
    const recorder = state.recorder;
    void reopen(self, current, seconds, state.wasPaused).then((reopened) => {
      if (!reopened) handOver(self, "mediadecodeerror");
    });
    state.busy += 1;
    void nextFrame(current.element, 6e4).then((at) => {
      state.busy -= 1;
      if (state.recorder === recorder && at !== null) recorder?.frame(at - startedAt);
    });
  }
  var MAX_REBUILDS = 3;
  var REBUILD_WINDOW_MS = 3 * 6e4;
  var SAME_PLACE_S = 2;
  async function rebuild(self, why) {
    const state = states.get(self);
    const current = state.current;
    const playback = state.playback;
    if (!current || !playback || state.rebuilding !== null) return state.rebuilding !== null;
    const now = performance.now();
    state.rebuilds = state.rebuilds.filter((past) => now - past.at < REBUILD_WINDOW_MS);
    if (state.rebuilds.length >= MAX_REBUILDS) {
      log(`reopened ${MAX_REBUILDS} times in ${REBUILD_WINDOW_MS / 6e4} minutes, handing over to the regular player`);
      return false;
    }
    let seconds = playback.position > 0 ? playback.position : state.lastPosition;
    const last = state.rebuilds[state.rebuilds.length - 1];
    if (last && Math.abs(last.seconds - seconds) < SAME_PLACE_S) seconds = playback.nextKeyframeAfter(seconds) ?? seconds;
    state.rebuilds.push({ at: now, seconds });
    const paused = state.wasPaused;
    log(`reopening (${why}) at ${seconds.toFixed(1)} s${paused ? ", paused" : ""}; engine at ${playback.position.toFixed(1)} s, last played position ${state.lastPosition.toFixed(1)} s`);
    state.recorder?.rebuilt();
    return reopen(self, current, seconds, paused);
  }
  async function reopen(self, current, seconds, paused) {
    const state = states.get(self);
    state.rebuilding = seconds;
    close(state, true);
    try {
      if (navigator.onLine === false) await new Promise((resolve) => window.addEventListener("online", () => resolve(), { once: true }));
      if (state.current !== current) return true;
      state.busy += 1;
      try {
        await open(self, current.element, current.options, { seconds, paused });
      } finally {
        state.busy -= 1;
      }
      if (state.current !== current) return true;
      const wanted = state.seekAfterRebuild;
      state.rebuilding = null;
      state.seekAfterRebuild = null;
      if (wanted !== null) void state.playback?.seek(wanted);
      return true;
    } catch (error) {
      if (state.current !== current) return true;
      state.rebuilding = null;
      log("could not reopen:", error instanceof Error ? error.message : error);
      return false;
    }
  }
  function checkAfterReturn() {
    if (document.visibilityState !== "visible") return;
    const look = () => {
      const state = instance ? states.get(instance) : null;
      if (!instance || !state?.playback?.lost || state.rebuilding !== null) return;
      const self = instance;
      void rebuild(self, "back to the foreground").then((rebuilt) => {
        if (!rebuilt) handOver(self, "mediadecodeerror");
      });
    };
    look();
    setTimeout(look, 400);
  }
  document.addEventListener("visibilitychange", checkAfterReturn);
  w[PLUGIN_NAME] = async () => LumenPlayer;
  window.addEventListener("pagehide", (event) => {
    if (event.target !== document && event.target !== window) return;
    const state = instance ? states.get(instance) : null;
    if (state) flush(state);
  });
  w.Lumen = {
    config,
    trace: () => core?.then((engine) => engine.traceText()) ?? Promise.resolve(""),
    status() {
      const state = instance ? states.get(instance) : null;
      if (!state) return null;
      return {
        adopted: state.adopted,
        playing: state.playback !== null,
        standby: lastStandby,
        position: state.playback?.position ?? null,
        audioTrack: state.playback?.currentAudioTrack ?? null,
        diagnostics: state.playback?.diagnostics ?? null,
        verdicts: [...state.verdicts].map(([id, verdict]) => ({ id, ok: verdict.ok, reason: verdict.reason ?? null }))
      };
    }
  };
})();
//# sourceMappingURL=lumen-jellyfin.js.map
