// src/host.ts
var DEFAULTS = { build: "dev", requestHeaders: null, sessionEnded: null, linkShaper: null, rangeRefused: null };
var host = { ...DEFAULTS };
function configureHost(next) {
  host = { ...host, ...next };
}
function hostBuild() {
  return host.build;
}
function withHostHeaders(init) {
  let extra = null;
  try {
    extra = host.requestHeaders?.() ?? null;
  } catch {
  }
  if (!extra || Object.keys(extra).length === 0) return init;
  return { ...init, headers: { ...extra, ...init?.headers } };
}
function hostSaysSessionEnded(res) {
  try {
    return res.status === 401 && host.sessionEnded?.(res) === true;
  } catch {
    return false;
  }
}
function noteRangeRefused(status) {
  try {
    host.rangeRefused?.(status);
  } catch {
  }
}
function linkShaper() {
  return host.linkShaper;
}

// src/engine/trace.ts
var KEPT_FROM_THE_START = 120;
var KEPT_AT_THE_END = 280;
var startedAt = 0;
var steps = [];
var keepAcrossNextReset = false;
var dropped = 0;
function traceReset() {
  if (keepAcrossNextReset) {
    keepAcrossNextReset = false;
    return;
  }
  startedAt = Date.now();
  steps = [];
  dropped = 0;
}
function trace(step) {
  try {
    if (startedAt === 0) startedAt = Date.now();
    steps.push({ at: Date.now() - startedAt, step });
    if (steps.length > KEPT_FROM_THE_START + KEPT_AT_THE_END + 64) {
      dropped += steps.length - (KEPT_FROM_THE_START + KEPT_AT_THE_END);
      steps = [...steps.slice(0, KEPT_FROM_THE_START), ...steps.slice(steps.length - KEPT_AT_THE_END)];
    }
  } catch {
  }
}
function traceText() {
  if (steps.length === 0) return "(aucune \xE9tape enregistr\xE9e)";
  const line = (s) => `${String(s.at).padStart(6)} ms  ${s.step}`;
  if (dropped === 0) return steps.map(line).join("\n");
  return [
    ...steps.slice(0, KEPT_FROM_THE_START).map(line),
    `         \u22EF  ${dropped} \xE9tapes plus anciennes retir\xE9es`,
    ...steps.slice(KEPT_FROM_THE_START).map(line)
  ].join("\n");
}
function traceElapsed() {
  return startedAt === 0 ? 0 : Date.now() - startedAt;
}
function traceRecent(ms, limit = 40, width = 140) {
  try {
    const from = traceElapsed() - ms;
    const recent = steps.filter((s) => s.at >= from).slice(-limit);
    return recent.map((s) => `+${Math.max(0, Math.round(s.at - from))} ms ${s.step.slice(0, width)}`);
  } catch {
    return [];
  }
}

// src/support/networkTrouble.ts
var retrying = 0;
var listeners = /* @__PURE__ */ new Set();
function emit() {
  const value = networkUnstable();
  for (const listener of listeners) {
    try {
      listener(value);
    } catch {
    }
  }
}
function noteFetchRetrying() {
  retrying += 1;
  if (retrying === 1) emit();
}
function noteFetchSettled() {
  if (retrying === 0) return;
  retrying -= 1;
  if (retrying === 0) emit();
}
function networkUnstable() {
  try {
    return retrying > 0 || typeof navigator !== "undefined" && navigator.onLine === false;
  } catch {
    return retrying > 0;
  }
}
function subscribeNetworkTrouble(listener) {
  listeners.add(listener);
  const onLine = () => emit();
  if (typeof window !== "undefined") {
    window.addEventListener("online", onLine);
    window.addEventListener("offline", onLine);
  }
  return () => {
    listeners.delete(listener);
    if (typeof window !== "undefined") {
      window.removeEventListener("online", onLine);
      window.removeEventListener("offline", onLine);
    }
  };
}

// src/support/slowLink.ts
var SLOW_LINK_REASON = "connexion trop lente";
var SLOW_LINK_LIGHTER_REASON = `${SLOW_LINK_REASON} (version all\xE9g\xE9e demand\xE9e)`;
var SLOW_LINK_STUTTER_REASON = `${SLOW_LINK_REASON} (saccades, version all\xE9g\xE9e demand\xE9e)`;
var MIN_MEASURED_MS = 1e4;
var MIN_RECEIVED_BYTES = 256 * 1024;
var SLOW_SHARE = 0.5;
function slowLinkVerdict(measure, needBps) {
  try {
    if (!measure || typeof needBps !== "number" || !Number.isFinite(needBps) || needBps <= 0) return null;
    const { bytes, receivingMs: receivingMs2 } = measure;
    if (!Number.isFinite(bytes) || !Number.isFinite(receivingMs2)) return null;
    if (receivingMs2 < MIN_MEASURED_MS) return null;
    if (bytes < MIN_RECEIVED_BYTES) return null;
    const recvBps = bytes * 8 / (receivingMs2 / 1e3);
    if (!(recvBps < SLOW_SHARE * needBps)) return null;
    return { recvBps, needBps, measuredMs: receivingMs2, bytes };
  } catch {
    return null;
  }
}
var openingMeter = null;
function meterOpeningRequest() {
  try {
    return openingMeter?.open() ?? null;
  } catch {
    return null;
  }
}
function readLink(measure, needBps) {
  try {
    const need = typeof needBps === "number" && needBps > 0 && Number.isFinite(needBps) ? needBps : null;
    if (!measure || !(measure.receivingMs > 0)) return { recvBps: null, needBps: need, verdict: "unknown", frozen: false };
    const recvBps = measure.bytes * 8 / (measure.receivingMs / 1e3);
    const enough = measure.receivingMs >= MIN_MEASURED_MS && measure.bytes >= MIN_RECEIVED_BYTES;
    const verdict = need === null || !enough ? "unknown" : slowLinkVerdict(measure, need) ? "slow" : "ok";
    return { recvBps: Number.isFinite(recvBps) ? recvBps : null, needBps: need, verdict, frozen: false };
  } catch {
    return { recvBps: null, needBps: null, verdict: "unknown", frozen: false };
  }
}
function linkVerdictWord(reading) {
  return reading.verdict === "ok" ? "suffisante" : reading.verdict === "slow" ? "trop lente" : "inconnue";
}

// src/engine/playbackDiagnosis.ts
var KEPT_MS = 12e4;
var STALL_WINDOW_MS = 3e4;
var DECODER_LEAD_SECONDS = 1;
var current = null;
function now() {
  return typeof performance !== "undefined" ? performance.now() : Date.now();
}
function connection() {
  try {
    const c = (typeof navigator !== "undefined" ? navigator.connection : void 0) ?? null;
    return c && typeof c === "object" ? c : null;
  } catch {
    return null;
  }
}
function prune(list, at) {
  if (list.length < 400) return;
  const limit = at - KEPT_MS;
  const first = list.findIndex((item) => (item.to ?? item.at ?? 0) >= limit);
  if (first > 0) list.splice(0, first);
}
function record(session, kind, from, to, bytes, firstByteMs) {
  if (!(to >= from)) return;
  session.intervals.push(firstByteMs === void 0 ? { kind, from, to, bytes } : { kind, from, to, bytes, firstByteMs });
  prune(session.intervals, to);
  const total = session.totals[kind];
  total.count += 1;
  total.bytes += bytes;
  total.ms += Math.max(0, to - Math.max(from, total.coveredUntil));
  total.coveredUntil = Math.max(total.coveredUntil, to);
}
function diagInterval(kind, from, bytes = 0) {
  try {
    if (current) record(current, kind, from, now(), bytes);
  } catch {
  }
}
function diagNow() {
  return now();
}
function diagRequest(sentAt, headersAt, endAt, bytes, serverMs) {
  try {
    const session = current;
    if (!session) return;
    record(session, "net", sentAt, endAt, bytes, headersAt - sentAt);
    const recv = session.recv;
    recv.bytes += bytes;
    recv.ms += Math.max(0, endAt - Math.max(headersAt, recv.coveredUntil));
    recv.coveredUntil = Math.max(recv.coveredUntil, endAt);
    session.firstBytes.push(headersAt - sentAt);
    if (session.firstBytes.length > 2e3) session.firstBytes.splice(0, 1e3);
    session.slowestMs = Math.max(session.slowestMs, endAt - sentAt);
    if (serverMs !== null) session.serverMaxMs = Math.max(session.serverMaxMs ?? 0, serverMs);
  } catch {
  }
}
function diagRequestFailed() {
  if (current) current.failedRequests += 1;
}
function foldReserveRun(totals, snapshot) {
  const run = snapshot.run;
  if (!run) return;
  totals.runs += 1;
  totals.netChunks += snapshot.netChunks;
  totals.bursts += run.bursts;
  totals.emptied += run.emptied;
  totals.emptiedMB += run.emptiedMB;
  totals.maxAheadMB = Math.max(totals.maxAheadMB, run.maxAheadMB);
  totals.maxAheadS = Math.max(totals.maxAheadS, run.maxAheadS);
  totals.activeMs += run.activeMs;
  totals.fetchedBytes += run.fetchedBytes;
  totals.fetchBusyMs += run.fetchBusyMs;
}
function reserveFacts(session, whole = false) {
  const r = session.reserve;
  if (!r) return {};
  const facts = {
    reserveNetMB: r.netChunks,
    reserveAheadMB: r.aheadChunks,
    reserveAllowedMB: r.allowedChunks,
    readReserveMB: r.reserveMB,
    readDeviceMB: r.deviceMB,
    readNetworkMB: r.networkMB
  };
  if (!whole || !r.run) return facts;
  const totals = { ...session.reserveDone };
  foldReserveRun(totals, r);
  facts.reserveNetMB = totals.netChunks;
  facts.reserveBursts = totals.bursts;
  facts.reserveEmptied = totals.emptied;
  facts.reserveEmptiedMB = totals.emptiedMB;
  facts.reserveMaxAheadMB = totals.maxAheadMB;
  facts.reserveMaxAheadS = totals.maxAheadS;
  facts.reserveS = Math.round(totals.activeMs / 1e3);
  if (totals.fetchBusyMs > 0) facts.reserveFetchMbps = mbps(totals.fetchedBytes, totals.fetchBusyMs) ?? 0;
  if (totals.runs > 1) facts.reserveRuns = totals.runs;
  if (r.run.idle) facts.reserveIdle = r.run.idle;
  return facts;
}
function diagMedia(bytes, seconds, video) {
  try {
    if (!current) return;
    if (bytes > 0 && seconds > 0) current.needBps = bytes * 8 / seconds;
    current.video = video;
  } catch {
  }
}
function busyMs(intervals, kinds, from, to) {
  const wanted = typeof kinds === "string" ? [kinds] : kinds;
  const spans = intervals.filter((i) => wanted.includes(i.kind) && i.to > from && i.from < to).map((i) => [Math.max(i.from, from), Math.min(i.to, to)]).sort((a, b) => a[0] - b[0]);
  let total = 0;
  let end = -Infinity;
  for (const [a, b] of spans) {
    if (b <= end) continue;
    total += b - Math.max(a, end);
    end = b;
  }
  return total;
}
function bytesIn(intervals, from, to) {
  let total = 0;
  for (const i of intervals) {
    if (i.kind !== "net" || i.to <= from || i.from >= to) continue;
    const length = i.to - i.from;
    total += length > 0 ? i.bytes * (Math.min(i.to, to) - Math.max(i.from, from)) / length : i.bytes;
  }
  return total;
}
function receivingMs(intervals, from, to) {
  const spans = intervals.filter((i) => i.kind === "net" && i.to > from && i.from + (i.firstByteMs ?? 0) < to).map((i) => [Math.max(i.from + (i.firstByteMs ?? 0), from), Math.min(i.to, to)]).sort((a, b) => a[0] - b[0]);
  let total = 0;
  let end = -Infinity;
  for (const [a, b] of spans) {
    if (b <= end) continue;
    total += b - Math.max(a, end);
    end = b;
  }
  return total;
}
function linkFacts(measure, needBps) {
  return { linkVerdict: linkVerdictWord(readLink(measure, needBps)), linkS: Math.round(measure.receivingMs / 100) / 10 };
}
function mbps(bytes, ms) {
  return ms > 0 ? Math.round(bytes * 8 / (ms / 1e3) / 1e6 * 10) / 10 : null;
}
function windowOf(session, from, to) {
  const { intervals } = session;
  return {
    spanMs: to - from,
    bytes: bytesIn(intervals, from, to),
    requests: intervals.filter((i) => i.kind === "net" && i.to > from && i.to <= to).length,
    netMs: busyMs(intervals, "net", from, to),
    readMs: busyMs(intervals, "read", from, to),
    segmentMs: busyMs(intervals, "segment", from, to),
    audioMs: busyMs(intervals, "audio", from, to),
    appendMs: busyMs(intervals, "append", from, to),
    longTaskMs: busyMs(intervals, "longtask", from, to),
    longTasks: intervals.filter((i) => i.kind === "longtask" && i.to > from && i.from < to).length,
    computeMs: computeMs(intervals, from, to)
  };
}
function computeMs(intervals, from, to) {
  const all = busyMs(intervals, ["segment", "read", "append", "longtask"], from, to);
  const readOrOther = busyMs(intervals, ["read", "append", "longtask"], from, to);
  const other = busyMs(intervals, ["append", "longtask"], from, to);
  return Math.max(0, all - readOrOther + other);
}
function verdictOf(w, lead) {
  if (lead !== null && lead >= DECODER_LEAD_SECONDS) return "d\xE9codeur";
  if (w.spanMs <= 0) return "autre";
  if (w.readMs / w.spanMs >= 0.5) return "r\xE9seau";
  if (w.computeMs / w.spanMs >= 0.5) return "calcul";
  return "autre";
}
function connectionFacts(session) {
  const facts = {};
  const c = connection();
  if (c) {
    if (typeof c.type === "string") facts.conn = c.type;
    if (typeof c.effectiveType === "string") facts.effectiveType = c.effectiveType;
    if (typeof c.downlink === "number") facts.downlinkMbps = c.downlink;
    if (typeof c.rtt === "number") facts.rttMs = c.rtt;
    if (c.saveData) facts.saveData = true;
  }
  if (session.connectionChanges > 0) facts.connChanges = session.connectionChanges;
  return facts;
}
function samplesIn(session, from, to) {
  return session.samples.filter((s) => s.at > from && s.at <= to);
}
function diagStallFacts(lead, windowMs = STALL_WINDOW_MS) {
  try {
    const session = current;
    if (!session) return {};
    const to = now();
    const from = Math.max(session.startedAt, to - windowMs);
    const w = windowOf(session, from, to);
    const samples = samplesIn(session, from, to);
    const framed = samples.filter((s) => s.frames !== null);
    const facts = {
      verdict: verdictOf(w, lead),
      winMs: Math.round(w.spanMs),
      recvMbps: mbps(w.bytes, w.spanMs) ?? 0,
      linkMbps: mbps(w.bytes, w.netMs) ?? 0,
      linkBusyPct: w.spanMs > 0 ? Math.round(w.netMs / w.spanMs * 100) : 0,
      req: w.requests,
      readWaitMs: Math.round(w.readMs),
      buildMs: Math.round(w.segmentMs),
      audioMs: Math.round(w.audioMs),
      appendMs: Math.round(w.appendMs),
      longTaskMs: Math.round(w.longTaskMs),
      longTasks: w.longTasks,
      lagMaxMs: samples.reduce((m, s) => Math.max(m, s.lagMs), 0)
    };
    const recent = session.intervals.filter((i) => i.kind === "net" && i.to > from);
    if (recent.length > 0) {
      facts.fbMaxMs = Math.round(Math.max(...recent.map((i) => i.firstByteMs ?? 0)));
      facts.slowestMs = Math.round(Math.max(...recent.map((i) => i.to - i.from)));
    }
    if (session.needBps !== null) facts.needMbps = Math.round(session.needBps / 1e6 * 10) / 10;
    Object.assign(facts, linkFacts({ bytes: w.bytes, receivingMs: receivingMs(session.intervals, from, to) }, session.needBps));
    if (framed.length >= 2) {
      const first = framed[0];
      const last = framed[framed.length - 1];
      const seconds = (last.at - first.at) / 1e3;
      if (seconds > 0) facts.fps = Math.round((last.frames - first.frames) / seconds * 10) / 10;
      facts.dropped = last.dropped - first.dropped;
    }
    if (session.failedRequests > 0) facts.reqFailed = session.failedRequests;
    return { ...facts, ...reserveFacts(session), ...connectionFacts(session) };
  } catch {
    return {};
  }
}

// src/engine/byteSource.ts
var SlicedSource = class _SlicedSource {
  constructor(bytes, base, size) {
    this.bytes = bytes;
    this.base = base;
    this.size = size;
  }
  bytes;
  base;
  size;
  static async of(source, start, end) {
    const bytes = await source.read(start, end - start);
    return new _SlicedSource(bytes, start, source.size);
  }
  async read(offset, length) {
    const from = offset - this.base;
    const start = Math.max(0, Math.min(from, this.bytes.length));
    const to = Math.max(start, Math.min(from + length, this.bytes.length));
    return this.bytes.subarray(start, to);
  }
  close() {
  }
};
var CHUNK_SIZE = 1 << 20;
var MAX_CACHED_CHUNKS = 64;
var MAX_KEPT_CHUNKS = 24;
var PREFETCH_CHUNKS = 6;
var SEEK_PREFETCH_CHUNKS = 2;
var SEEK_FIRST_BYTE_MS = 5e3;
var WAKE_FIRST_BYTE_WINDOW_MS = 15e3;
var SEEK_FOCUS_MS = 8e3;
var FETCH_ATTEMPTS = 4;
var FETCH_BACKOFF_MS = [200, 600, 1500];
var REQUEST_TIMEOUT_MS = 25e3;
function readSignal(playerSignal) {
  const any = AbortSignal.any;
  if (typeof any !== "function" || typeof AbortSignal.timeout !== "function") return playerSignal;
  return any([playerSignal, AbortSignal.timeout(REQUEST_TIMEOUT_MS)]);
}
var OFFLINE_PATIENCE_MS = 6e4;
var NetworkUnavailable = class extends Error {
  network = true;
  constructor(message) {
    super(message);
    this.name = "NetworkUnavailable";
  }
};
function describeNetwork(w) {
  const mbps2 = w.elapsedMs > 0 ? w.bytes * 8 / (w.elapsedMs / 1e3) / 1e6 : 0;
  return `${(w.bytes / 1048576).toFixed(1)} Mo en ${w.elapsedMs} ms (${mbps2.toFixed(0)} Mb/s), ${w.requests} requ\xEAte(s), premier octet ${w.firstByteMinMs}\u2013${w.firstByteMaxMs} ms, la plus lente ${w.slowestMs} ms` + (w.serverMaxMs !== null ? `, serveur \u2264 ${w.serverMaxMs} ms` : "") + describeProtocols(w.protocols) + describeDemand(w.demand);
}
function describeDemand(demand) {
  const seen = Object.entries(demand ?? {}).filter(([, d]) => d.reads > 0);
  if (seen.length === 0) return "";
  return `, demand\xE9 : ${seen.map(([who, d]) => `${who} ${(d.bytes / 1048576).toFixed(1)} Mo \xD7${d.reads}`).join(", ")}`;
}
function readingAs(source, who) {
  return new Proxy(source, {
    get(target, property) {
      if (property === "read") return (offset, length) => target.read(offset, length, who);
      const value = Reflect.get(target, property, target);
      return typeof value === "function" ? value.bind(target) : value;
    }
  });
}
function describeProtocols(protocols) {
  const seen = Object.entries(protocols ?? {}).sort((a, b) => b[1] - a[1]);
  if (seen.length === 0) return "";
  if (seen.length === 1) return `, protocole ${seen[0][0]}`;
  return `, protocoles ${seen.map(([name, count]) => `${name} \xD7${count}`).join(", ")}`;
}
function protocolOf(url) {
  try {
    if (typeof performance === "undefined" || typeof performance.getEntriesByName !== "function") return null;
    const name = typeof location !== "undefined" && location?.href ? new URL(url, location.href).href : url;
    const entries = performance.getEntriesByName(name, "resource");
    const last = entries[entries.length - 1];
    const protocol = last?.nextHopProtocol;
    return typeof protocol === "string" && protocol !== "" ? protocol : null;
  } catch {
    return null;
  }
}
function serverTimingApp(header) {
  const match = header ? /(?:^|,)\s*app;dur=([\d.]+)/.exec(header) : null;
  return match ? Math.round(Number(match[1])) : null;
}
var SessionEnded = class extends Error {
  constructor() {
    super("Session expir\xE9e");
    this.name = "SessionEnded";
  }
};
var ReadAbandoned = class extends Error {
  abandoned = true;
  constructor() {
    super("lecture abandonn\xE9e pour un saut");
    this.name = "ReadAbandoned";
  }
};
function isReadAbandoned(error) {
  return error instanceof Error && "abandoned" in error && error.abandoned === true;
}
function isNetworkFailure(error) {
  return error instanceof Error && "network" in error && error.network === true;
}
async function waitForNetwork(signal) {
  if (typeof navigator === "undefined" || navigator.onLine !== false) return false;
  if (signal?.aborted) return false;
  trace("r\xE9seau : hors ligne, la lecture attend le retour");
  let gaveUp = false;
  await new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      window.removeEventListener("online", done);
      signal?.removeEventListener("abort", done);
      resolve();
    };
    const timer = setTimeout(() => {
      gaveUp = navigator.onLine === false;
      done();
    }, OFFLINE_PATIENCE_MS);
    window.addEventListener("online", done, { once: true });
    signal?.addEventListener("abort", done, { once: true });
  });
  trace(gaveUp ? `r\xE9seau : toujours hors ligne apr\xE8s ${OFFLINE_PATIENCE_MS / 1e3} s` : "r\xE9seau : de retour");
  return gaveUp;
}
function backoff(ms, signal) {
  if (signal.aborted) return Promise.resolve();
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      signal.removeEventListener("abort", done);
      resolve();
    };
    const timer = setTimeout(done, ms);
    signal.addEventListener("abort", done, { once: true });
  });
}
function closedSource() {
  return new Error("source ferm\xE9e");
}
var HANDOVER_MS = 5e3;
var handover = null;
function takeHandover(url) {
  if (!handover || handover.url !== url) return null;
  const taken = handover;
  clearTimeout(taken.timer);
  handover = null;
  return { size: taken.size, chunks: taken.chunks, kept: taken.kept, reserve: taken.reserve };
}
function holdsHandover(url) {
  return handover !== null && handover.url === url;
}
function leaveHandover(url, size, chunks, kept, reserve) {
  if (handover) clearTimeout(handover.timer);
  if (chunks.size === 0 && reserve.size === 0) {
    handover = null;
    return;
  }
  const timer = setTimeout(() => {
    if (handover?.chunks === chunks) handover = null;
  }, HANDOVER_MS);
  handover = { url, size, chunks, kept, reserve, timer };
}
var PREPARED_MS = 3 * 6e4;
var MAX_PREPARED = 2;
var prepared = /* @__PURE__ */ new Map();
function takePrepared(key) {
  const entry = prepared.get(key);
  if (!entry) return null;
  clearTimeout(entry.timer);
  prepared.delete(key);
  return { size: entry.size, chunks: entry.chunks, kept: null, reserve: /* @__PURE__ */ new Map() };
}
function leavePrepared(key, size, chunks) {
  const before = prepared.get(key);
  if (before) clearTimeout(before.timer);
  prepared.delete(key);
  if (chunks.size === 0) return;
  const timer = setTimeout(() => {
    if (prepared.get(key)?.chunks === chunks) prepared.delete(key);
  }, PREPARED_MS);
  prepared.set(key, { size, chunks, timer });
  while (prepared.size > MAX_PREPARED) {
    const oldest = prepared.keys().next().value;
    clearTimeout(prepared.get(oldest).timer);
    prepared.delete(oldest);
  }
}
function holdsPrepared(key) {
  return prepared.has(key);
}
var lastOpened = /* @__PURE__ */ new Map();
var HttpByteSource = class _HttpByteSource {
  /** Octets servis depuis l'appareil, et depuis le réseau — voir `openingBytes`. */
  deviceBytes = 0;
  networkBytes = 0;
  /** Le `Last-Modified` de la première réponse qui en portait un : la date du fichier chez Jellyfin. */
  lastModified = null;
  /** Les morceaux gardés sur l'appareil pour ce fichier, s'il y en a — voir `DiskChunks`. */
  disk = null;
  /**
   * La taille du fichier — corrigée une fois, si le serveur en annonce une autre que celle avec
   * laquelle la source a été ouverte. Voir `checkTotal`.
   */
  get size() {
    return this.total;
  }
  total;
  /** Voir `whenSizeCorrected`. */
  sizeCorrected = false;
  onSizeCorrected = null;
  /**
   * `fn` est appelée une fois si `checkTotal` corrige la taille : le fichier n'est plus celui qu'on
   * croyait, et ce qui a été gardé ailleurs sous son adresse (l'en-tête lu) doit être oublié.
   * Tout de suite si c'est déjà fait : les deux premières plages partent dès l'ouverture
   * (`warmed`), et leur réponse peut précéder celui qui s'y abonne.
   */
  whenSizeCorrected(fn) {
    if (this.sizeCorrected) fn();
    else this.onSizeCorrected = fn;
  }
  /** Le total annoncé par une réponse a été lu et comparé : voir `checkTotal`. */
  totalChecked = false;
  url;
  chunks = /* @__PURE__ */ new Map();
  /** Les morceaux à garder de préférence, bornes comprises — voir `keep`. */
  kept = null;
  inflight = /* @__PURE__ */ new Map();
  /** L'interrupteur de chaque morceau en vol — pour n'abandonner que ceux qui ne servent plus. */
  inflightControllers = /* @__PURE__ */ new Map();
  controller = new AbortController();
  /** Voir `NetworkWindow` : remis à zéro à chaque `abandon`, c'est-à-dire à chaque saut. */
  /** Jusqu'à quand la lecture en avance est bridée — voir `SEEK_PREFETCH_CHUNKS`. */
  focusUntil = 0;
  /** Le dernier morceau qu'une lecture a demandé : d'où l'avance repart quand le saut aboutit. */
  lastDemanded = -1;
  /** Jusqu'à quand un retour au premier plan surveille le premier octet — `WAKE_FIRST_BYTE_WINDOW_MS`. */
  wakeUntil = 0;
  /** Les tentatives en vol sans en-têtes encore : un retour au premier plan leur pose l'échéance. */
  silentAttempts = /* @__PURE__ */ new Set();
  onVisibility = () => {
    if (document.visibilityState !== "visible") return;
    this.wakeUntil = performance.now() + WAKE_FIRST_BYTE_WINDOW_MS;
    for (const arm of this.silentAttempts) arm();
    this.silenceFloor = Date.now();
  };
  /**
   * Le silence du réseau, pour la borne d'une coupure en pleine lecture (DECISIONS.md §97).
   *
   * `demand` : les morceaux en cours de demande, tentatives, attentes entre elles et attente du
   * retour du réseau comprises (`fetchWithRetries`). `silentFrom` : le début de la demande restée
   * sans octet — posé quand une demande commence, effacé par un morceau arrivé ou par une demande
   * qui finit sans échec réseau, **gardé** par une demande qui échoue, si bien qu'un serveur qui
   * refuse aussitôt (essais de 2 s séparés de quelques secondes) reste un silence qui dure.
   * `silenceFloor` : un retour au premier plan ou `online` — le silence repart de là. En `Date.now()` :
   * des durées de quelques dizaines de secondes, et l'horloge que les minuteurs simulés savent avancer.
   */
  demand = 0;
  silentFrom = null;
  silenceFloor = 0;
  onOnline = () => {
    this.silenceFloor = Date.now();
  };
  window = null;
  constructor(url, size) {
    this.url = url;
    this.total = size;
    lastOpened.delete(url);
    lastOpened.set(url, this);
    while (lastOpened.size > 4) lastOpened.delete(lastOpened.keys().next().value);
    if (typeof document !== "undefined") document.addEventListener("visibilitychange", this.onVisibility);
    if (typeof window !== "undefined" && typeof window.addEventListener === "function") window.addEventListener("online", this.onOnline);
  }
  // The length has to come from the server before anything else can be parsed. HEAD is tried
  // first because it costs nothing; some proxies answer it without Content-Length, in which case
  // a one-byte ranged GET gets the total out of Content-Range instead.
  //
  // Sauf quand l'appelant la connaît déjà (`knownSize`). La description du fichier, que l'hôte a
  // demandée avant d'ouvrir quoi que ce soit, la porte — Jellyfin la tient de son analyse du
  // fichier. Le HEAD coûtait alors un aller-retour entier pour une réponse déjà en main, avant
  // que les deux premières plages puissent même partir : relevé le 22/09/2026 depuis un serveur
  // lointain, ~60 ms d'aller-retour, soit autant de moins à chaque ouverture. Une taille fausse
  // n'est pas crue sur parole : la première réponse la corrige — voir `checkTotal`.
  static async open(url, knownSize, disk, preparedKey) {
    const inherited = takeHandover(url) ?? (preparedKey ? takePrepared(preparedKey) : null);
    if (inherited) {
      const source = new _HttpByteSource(url, inherited.size);
      source.disk = disk ?? null;
      source.chunks = inherited.chunks;
      source.reserve = inherited.reserve;
      source.kept = inherited.kept;
      trace(
        `flux repris de la lecture pr\xE9c\xE9dente \u2014 ${inherited.chunks.size} Mo d\xE9j\xE0 l\xE0` + (inherited.reserve.size > 0 ? `, ${inherited.reserve.size} en r\xE9serve` : "")
      );
      return source;
    }
    if (typeof knownSize === "number" && Number.isFinite(knownSize) && knownSize > 0) {
      trace(`taille connue d'avance (${Math.floor(knownSize)} octets) \u2014 pas de HEAD`);
      return _HttpByteSource.warmed(url, Math.floor(knownSize), disk ?? null);
    }
    const head = await fetch(url, withHostHeaders({ method: "HEAD" })).catch((cause) => {
      throw new NetworkUnavailable(cause instanceof Error ? cause.message : "r\xE9seau indisponible");
    });
    const headLength = Number(head.headers.get("Content-Length"));
    if (head.ok && Number.isFinite(headLength) && headLength > 0) {
      return _HttpByteSource.warmed(url, headLength);
    }
    const probe = await fetch(url, withHostHeaders({ headers: { Range: "bytes=0-0" } })).catch((cause) => {
      throw new NetworkUnavailable(cause instanceof Error ? cause.message : "r\xE9seau indisponible");
    });
    const contentRange = probe.headers.get("Content-Range");
    const total = contentRange ? Number(contentRange.split("/")[1]) : NaN;
    if (!Number.isFinite(total) || total <= 0) {
      throw new Error("Le serveur ne fournit pas la taille du fichier (Content-Range absent).");
    }
    return _HttpByteSource.warmed(url, total);
  }
  /**
   * Starts the two fetches every Matroska file begins with, before anyone asks for them.
   *
   * Reading the header means the front of the file; reading the index means wherever the Cues
   * were written, which for a file made for streaming is the very end. Those two were fetched one
   * after the other, each paying its own round trip, and together they were most of the second
   * that passed between opening a file and knowing what was in it. Asked for together they cost
   * one round trip instead of two.
   *
   * Neither is awaited: a file whose Cues are at the front simply leaves the tail chunk unused,
   * which costs a megabyte and no time at all.
   */
  static warmed(url, size, disk = null) {
    const source = new _HttpByteSource(url, size);
    source.disk = disk;
    const last = Math.floor((size - 1) / CHUNK_SIZE);
    for (const index of last > 0 ? [0, last] : [0]) {
      void source.fetchChunk(index).catch(() => {
      });
    }
    return source;
  }
  /**
   * One range, fetched until it arrives or until there is reason to believe it never will.
   *
   * A server that answers 200 to a Range header is not having a bad moment — it does not honour
   * ranges at all, and asking again would only download a forty-gigabyte film four times.
   */
  async fetchWithRetries(start, end, own) {
    let retrying2 = false;
    this.demand += 1;
    this.silentFrom ??= Date.now();
    let networkFailed = false;
    try {
      return await this.fetchAttempts(start, end, own, () => {
        if (!retrying2) {
          retrying2 = true;
          noteFetchRetrying();
        }
      });
    } catch (error) {
      networkFailed = isNetworkFailure(error);
      throw error;
    } finally {
      this.demand -= 1;
      if (this.demand === 0 && !networkFailed) this.silentFrom = null;
      if (retrying2) noteFetchSettled();
    }
  }
  /**
   * Depuis combien de temps le réseau ne livre plus un octet alors qu'on lui demande quelque chose
   * (DECISIONS.md §97). Zéro quand rien n'est demandé, sauf après une demande qui a échoué : un film
   * en pause, un tampon plein, une lecture servie par l'appareil ne sont pas un silence. Un morceau arrivé (1 Mio, bien au-delà des
   * 256 Kio qui suffisent à dire un lien lent, §77) le remet à zéro ; un lien lent mais vivant en livre
   * un bien avant la borne — sous ~40 Ko/s, l'échéance de 25 s des requêtes l'aurait de toute façon
   * coupé. Mesure seulement : rien ici ne change une requête.
   */
  networkSilentMs() {
    if (this.silentFrom === null) return 0;
    return Math.max(0, Date.now() - Math.max(this.silentFrom, this.silenceFloor));
  }
  async fetchAttempts(start, end, own, noteRetrying) {
    let last;
    let deadlineUsed = false;
    for (let attempt = 0; attempt < FETCH_ATTEMPTS; attempt++) {
      if (attempt > 0) {
        if (await waitForNetwork(own)) {
          if (this.controller.signal.aborted) throw last ?? new Error("lecture annul\xE9e");
          if (own.aborted) throw new ReadAbandoned();
          break;
        }
        await backoff(FETCH_BACKOFF_MS[attempt - 1] ?? 1500, own);
        if (this.controller.signal.aborted) throw last ?? new Error("lecture annul\xE9e");
        if (own.aborted) throw new ReadAbandoned();
      }
      const attemptControl = new AbortController();
      const forward = () => attemptControl.abort();
      own.addEventListener("abort", forward, { once: true });
      let muted = false;
      let firstByteTimer = null;
      let deadlineWhy = "apr\xE8s un saut";
      const armDeadline = (why) => {
        if (firstByteTimer !== null || deadlineUsed) return;
        deadlineUsed = true;
        deadlineWhy = why;
        firstByteTimer = setTimeout(() => {
          muted = true;
          attemptControl.abort();
        }, SEEK_FIRST_BYTE_MS);
      };
      if (attempt === 0 && performance.now() < this.focusUntil) armDeadline("apr\xE8s un saut");
      else if (performance.now() < this.wakeUntil) armDeadline("au retour au premier plan");
      const armOnWake = () => armDeadline("au retour au premier plan");
      this.silentAttempts.add(armOnWake);
      const metered = meterOpeningRequest();
      try {
        const shaper = linkShaper();
        if (shaper) shaper.gate();
        const sentAt = performance.now();
        const res = await fetch(this.url, withHostHeaders({
          headers: { Range: `bytes=${start}-${end}` },
          // Le signal du lecteur *et* une échéance — voir `readSignal`. L'abandon sur échéance
          // laisse `this.controller.signal.aborted` à faux, si bien que la boucle ci-dessous le
          // traite comme n'importe quel échec réseau : une nouvelle tentative, puis l'écran.
          // Le signal de ce morceau, que la fermeture de la source coupe aussi — voir `abandon`.
          signal: readSignal(attemptControl.signal)
        }));
        if (firstByteTimer !== null) clearTimeout(firstByteTimer);
        this.silentAttempts.delete(armOnWake);
        if (res.status === 200) {
          throw new Error("Le serveur n'honore pas les requ\xEAtes de plage (statut 200).");
        }
        if (hostSaysSessionEnded(res)) throw new SessionEnded();
        if (res.status === 416) throw new Error("La plage demand\xE9e est hors du fichier (statut 416).");
        if (res.status !== 206) {
          noteRangeRefused(res.status);
          throw new Error(`Le serveur a refus\xE9 la plage demand\xE9e (statut ${res.status}).`);
        }
        this.checkTotal(res);
        const headersAt = performance.now();
        metered?.headers();
        const bytes = new Uint8Array(await res.arrayBuffer());
        if (shaper) await shaper.transfer(bytes.byteLength, headersAt, attemptControl.signal);
        const announced = /bytes (\d+)-(\d+)\//.exec(res.headers?.get?.("Content-Range") ?? "");
        if (announced && bytes.byteLength !== Number(announced[2]) - Number(announced[1]) + 1) {
          throw new Error(`plage tronqu\xE9e (${bytes.byteLength} octets sur ${Number(announced[2]) - Number(announced[1]) + 1})`);
        }
        metered?.received(bytes.byteLength);
        this.networkBytes += bytes.byteLength;
        this.silentFrom = this.demand > 1 ? Date.now() : null;
        const endAt = performance.now();
        this.note(sentAt, headersAt, endAt, bytes.byteLength, res);
        diagRequest(sentAt, headersAt, endAt, bytes.byteLength, serverTimingApp(res.headers?.get?.("Server-Timing") ?? null));
        return bytes;
      } catch (error) {
        if (this.controller.signal.aborted) throw error;
        if (own.aborted) throw new ReadAbandoned();
        if (error instanceof Error && (error.message.includes("statut 200") || error.message.includes("statut 416"))) throw error;
        if (error instanceof SessionEnded) throw error;
        last = error;
        diagRequestFailed();
        if (attempt < FETCH_ATTEMPTS - 1 && !muted) noteRetrying();
        if (muted) trace(`r\xE9seau : aucun octet en ${SEEK_FIRST_BYTE_MS / 1e3} s ${deadlineWhy}, plage ${start}-${end} redemand\xE9e`);
        else if (attempt === 0) trace(`r\xE9seau : plage ${start}-${end} refus\xE9e, nouvelle tentative`);
      } finally {
        metered?.end();
        if (firstByteTimer !== null) clearTimeout(firstByteTimer);
        this.silentAttempts.delete(armOnWake);
        own.removeEventListener("abort", forward);
      }
    }
    throw new NetworkUnavailable(
      last instanceof Error ? `Plage inaccessible : ${last.message}` : "Plage inaccessible."
    );
  }
  async fetchChunk(index) {
    if (this.controller.signal.aborted) throw closedSource();
    const cached = this.chunks.get(index);
    if (cached) return cached;
    const reserved = this.reserve.get(index);
    if (reserved) {
      this.reserve.delete(index);
      this.chunks.set(index, reserved);
      this.evict();
      this.reserveBytes += reserved.byteLength;
      return reserved;
    }
    const pending = this.inflight.get(index);
    if (pending) return pending;
    const start = index * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, this.size) - 1;
    const own = new AbortController();
    this.inflightControllers.set(index, own);
    const promise = this.fromDiskOrNetwork(index, start, end, own.signal).then((bytes) => {
      if (bytes.byteLength === this.expectedLength(index)) {
        this.chunks.set(index, bytes);
        this.evict();
      }
      return bytes;
    }).finally(() => {
      if (this.inflight.get(index) === promise) this.inflight.delete(index);
      if (this.inflightControllers.get(index) === own) this.inflightControllers.delete(index);
    });
    this.inflight.set(index, promise);
    return promise;
  }
  /**
   * L'appareil d'abord, s'il a ce morceau de ce fichier ; le réseau sinon — et aussi quand la
   * relecture sur l'appareil échoue ou rend une longueur inattendue. Ne lève jamais à cause de
   * l'appareil.
   */
  async fromDiskOrNetwork(index, start, end, own) {
    const disk = this.disk;
    if (disk?.has(index)) {
      try {
        const bytes = await disk.read(index);
        if (bytes && bytes.byteLength === this.expectedLength(index) && disk.has(index)) {
          this.deviceBytes += bytes.byteLength;
          return bytes;
        }
      } catch {
      }
      if (own.aborted || this.controller.signal.aborted) throw new ReadAbandoned();
    }
    return this.fetchWithRetries(start, end, own);
  }
  /**
   * Starts fetching the chunk after the one just used, without waiting for it.
   *
   * Playback reads strictly forward, and a 1 MiB chunk is well under a second of 4K video — so
   * without this, every chunk boundary is a full network round trip the decoder sits through.
   * That stall is what turns a decoder that can keep up into one that visibly cannot.
   */
  /** Voir `withoutReadahead`. */
  readahead = true;
  /**
   * Plus de lecture en avance : chaque octet lu est un octet demandé, rien de plus (28/09/2026). Pour
   * les sources qui préparent un titre au repos (`recordTitle`, l'épisode suivant) — la lecture en
   * avance y téléchargeait six mégaoctets après chaque lecture, que personne ne gardait. Jamais pour
   * le lecteur, dont c'est l'avance.
   */
  withoutReadahead() {
    this.readahead = false;
    return this;
  }
  /**
   * La lecture en avance suspendue le temps de lire l'en-tête d'une ouverture en reprise
   * (29/09/2026). Lire le morceau 0 lançait les morceaux 1 à 6 — le début du film, six mégaoctets
   * qu'une reprise à vingt minutes ne lit jamais, demandés avant que quiconque sache où elle
   * tomberait. Même un titre dont l'appareil tenait l'en-tête, l'index et la zone de reprise
   * allait chercher ces six-là sur le réseau, et rien d'autre. Rendue dès l'en-tête lu : la
   * lecture suivante, à la position de reprise, relance l'avance là où elle sert. Jamais pour une
   * ouverture au début, dont ces morceaux sont les premières images.
   */
  readaheadHeld = false;
  holdReadahead(held) {
    this.readaheadHeld = held;
  }
  prefetchAfter(index) {
    if (this.controller.signal.aborted || !this.readahead || this.readaheadHeld) return;
    const depth = performance.now() < this.focusUntil ? SEEK_PREFETCH_CHUNKS : PREFETCH_CHUNKS;
    for (let ahead = 1; ahead <= depth; ahead++) {
      const next = index + ahead;
      if (next * CHUNK_SIZE >= this.size) return;
      if (this.chunks.has(next) || this.inflight.has(next) || this.reserve.has(next) || this.reserveInflight.has(next)) continue;
      void this.fetchChunk(next).catch(() => {
      });
    }
  }
  /**
   * Fetches around an offset before anything reads there.
   *
   * A seek knows which cluster it is going to land in the moment the index is consulted, and
   * that is several milliseconds before the parser asks for its first byte. Until now those
   * milliseconds were spent idle and the one after them was spent waiting on a single request:
   * the read-ahead only started once that first chunk had already arrived, so the beginning of
   * every seek was one round trip during which the link carried one megabyte and nothing else —
   * on a file needing four before it can show a picture.
   *
   * Cheap to be wrong about: these are chunks the reader was about to ask for anyway, and a
   * fetch already in flight or already cached is left alone.
   */
  warm(offset) {
    if (this.controller.signal.aborted) return;
    const first = Math.floor(Math.max(0, Math.min(offset, this.size - 1)) / CHUNK_SIZE);
    if (!this.chunks.has(first) && !this.inflight.has(first)) {
      void this.fetchChunk(first).catch(() => {
      });
    }
    this.prefetchAfter(first);
  }
  /**
   * La lecture, et ce qu'elle a fait attendre : une lecture servie par le cache revient dans la
   * milliseconde, une qui attend le réseau ou le disque est notée — c'est le remultiplexeur à sec
   * (voir playbackDiagnosis.ts).
   */
  async read(offset, length, who = "lecteur") {
    const from = diagNow();
    const window2 = this.window;
    if (window2) {
      const d = window2.demand[who] ??= { reads: 0, bytes: 0 };
      d.reads += 1;
      d.bytes += Math.max(0, length);
    }
    const start = Math.max(0, Math.min(offset, this.size));
    const end = Math.max(start, Math.min(offset + length, this.size));
    let waiting = false;
    for (let index = Math.floor(start / CHUNK_SIZE); end > start && index <= Math.floor((end - 1) / CHUNK_SIZE); index++) {
      if (!this.chunks.has(index) && !this.reserve.has(index)) {
        waiting = true;
        break;
      }
    }
    if (waiting) this.waitingReads += 1;
    try {
      return await this.readBytes(offset, length);
    } finally {
      if (waiting) this.waitingReads -= 1;
      if (diagNow() - from >= 2) diagInterval("read", from);
    }
  }
  /** Les lectures en cours qui attendent un morceau absent de la mémoire — voir `read`. */
  waitingReads = 0;
  /**
   * La réserve d'avance en mémoire (`MemoryReserve`, 28/09/2026) : des morceaux téléchargés au-delà de
   * la lecture en avance, gardés à part du cache pour que ses évictions ne les chassent pas avant
   * qu'ils servent. Un morceau lu la quitte pour le cache (`fetchChunk`) ; la réserve retire elle-même
   * ce que la tête a dépassé. Rien sur l'appareil : la mémoire seulement, rendue à la fermeture.
   */
  reserve = /* @__PURE__ */ new Map();
  /** Octets que le lecteur a lus depuis la réserve mémoire. */
  reserveBytes = 0;
  /** Un morceau pour la réserve — refusé s'il est déjà là, ou s'il n'a pas sa longueur. */
  offerReserve(index, bytes) {
    if (this.controller.signal.aborted || this.chunks.has(index) || bytes.byteLength !== this.expectedLength(index)) return false;
    this.reserve.set(index, bytes);
    return true;
  }
  dropReserve(index) {
    this.reserve.delete(index);
  }
  clearReserve() {
    this.reserve.clear();
  }
  get reserveIndices() {
    return [...this.reserve.keys()];
  }
  /** Les morceaux que la réserve a en route — tenus par elle, lus par `prefetchAfter`. */
  reserveInflight = /* @__PURE__ */ new Set();
  /** Le lecteur a-t-il ce morceau en route ? La réserve ne le demande pas une seconde fois. */
  isFetching(index) {
    return this.inflight.has(index);
  }
  /** Le morceau est-il en mémoire, dans le cache ou dans la réserve ? */
  hasInMemory(index) {
    return this.chunks.has(index) || this.reserve.has(index);
  }
  /**
   * Ce que la réserve d'avance (`MemoryReserve`, 28/09/2026) lit de la source, sans rien y changer : où
   * en est le lecteur, s'il attend. Rien ici ne lance de requête.
   */
  get streamUrl() {
    return this.url;
  }
  get readsWaiting() {
    return this.waitingReads;
  }
  /** Le dernier morceau qu'une lecture a demandé — la lecture en avance court jusqu'à `PREFETCH_CHUNKS` au-delà. */
  get demandedChunk() {
    return this.lastDemanded;
  }
  /** Un saut attend sa première image : la lecture en avance est bridée, le lien est au saut. */
  get seekFocused() {
    return performance.now() < this.focusUntil;
  }
  async readBytes(offset, length) {
    if (this.controller.signal.aborted) throw closedSource();
    const start = Math.max(0, Math.min(offset, this.size));
    const end = Math.max(start, Math.min(offset + length, this.size));
    if (end === start) return new Uint8Array(0);
    const firstChunk = Math.floor(start / CHUNK_SIZE);
    const lastChunk = Math.floor((end - 1) / CHUNK_SIZE);
    this.lastDemanded = lastChunk;
    if (firstChunk === lastChunk) {
      const chunk = await this.fetchChunk(firstChunk);
      this.prefetchAfter(firstChunk);
      const from = start - firstChunk * CHUNK_SIZE;
      return chunk.subarray(from, from + (end - start));
    }
    const pending = [];
    for (let index = firstChunk; index <= lastChunk; index++) pending.push(this.fetchChunk(index));
    const fetched = await Promise.all(pending);
    const out = new Uint8Array(end - start);
    let written = 0;
    for (let index = firstChunk; index <= lastChunk; index++) {
      const chunk = fetched[index - firstChunk];
      const chunkStart = index * CHUNK_SIZE;
      const from = Math.max(0, start - chunkStart);
      const to = Math.min(chunk.length, end - chunkStart);
      if (to > from) {
        out.set(chunk.subarray(from, to), written);
        written += to - from;
      }
    }
    this.prefetchAfter(lastChunk);
    return written === out.length ? out : out.subarray(0, written);
  }
  /**
   * Un saut vient d'être demandé vers `keepOffset` : tout ce qui est en vol ailleurs est coupé.
   *
   * 22/09/2026, serveur lointain : un saut attendait la fin de la lecture en cours — jusqu'à deux
   * secondes — avant de repositionner le lecteur, et pendant ce temps les six morceaux lus en
   * avance de l'ancienne position occupaient le lien que la nouvelle attendait. On garde ce qui
   * sert le saut lui-même : le morceau où il tombe et l'avance qui le suit.
   */
  abandon(keepOffset) {
    this.focusUntil = performance.now() + SEEK_FOCUS_MS;
    this.window = { since: performance.now(), requests: 0, bytes: 0, lastEnd: 0, fbMin: Infinity, fbMax: 0, slowest: 0, server: null, protocols: {}, demand: {} };
    const first = Math.floor(Math.max(0, Math.min(keepOffset, this.size - 1)) / CHUNK_SIZE);
    let dropped2 = 0;
    for (const [index, own] of this.inflightControllers) {
      if (index >= first && index <= first + PREFETCH_CHUNKS) continue;
      own.abort();
      this.inflightControllers.delete(index);
      this.inflight.delete(index);
      dropped2 += 1;
    }
    if (dropped2 > 0) trace(`r\xE9seau : ${dropped2} lecture(s) de l'ancienne position abandonn\xE9e(s)`);
  }
  /** La longueur qu'a le morceau `index` dans un fichier de la taille actuelle. */
  expectedLength(index) {
    return Math.max(0, Math.min(CHUNK_SIZE, this.total - index * CHUNK_SIZE));
  }
  /**
   * La taille annoncée par la première réponse qui en porte une, comparée à celle de l'ouverture.
   *
   * Une taille connue d'avance vient de la description du fichier, que le lecteur garde en
   * mémoire toute la session : un fichier remplacé entre-temps par son gestionnaire en aurait une
   * autre. Le `Content-Range` d'une plage est la vérité du moment — il arrive avec les premiers
   * octets, avant que le démultiplexeur ait lu quoi que ce soit, et c'est lui qu'on garde. Les
   * morceaux déjà reçus que la nouvelle taille rend faux (un morceau de fin coupé trop tôt) sont
   * oubliés. Tracé, parce qu'un écart dit que la description était périmée. Ne lève jamais.
   */
  checkTotal(res) {
    if (this.totalChecked) return;
    try {
      const header = res.headers?.get?.("Content-Range");
      const total = header ? Number(header.split("/")[1]) : NaN;
      if (!Number.isFinite(total) || total <= 0) return;
      this.totalChecked = true;
      this.lastModified = res.headers?.get?.("Last-Modified") ?? null;
      try {
        this.disk?.verify(total, this.lastModified);
      } catch {
      }
      if (total === this.total) return;
      trace(`r\xE9seau : le serveur annonce ${total} octets, la source \xE9tait ouverte sur ${this.total} \u2014 taille corrig\xE9e`);
      this.total = total;
      for (const [index, bytes] of this.chunks) {
        if (bytes.byteLength !== this.expectedLength(index)) this.chunks.delete(index);
      }
      this.sizeCorrected = true;
      this.onSizeCorrected?.();
    } catch {
    }
  }
  /** Une requête terminée, comptée dans la fenêtre du saut en cours. Ne lève jamais. */
  note(sentAt, headersAt, endAt, bytes, res) {
    const w = this.window;
    if (!w) return;
    try {
      const serverTiming = res.headers?.get?.("Server-Timing") ?? null;
      w.requests += 1;
      w.bytes += bytes;
      w.lastEnd = Math.max(w.lastEnd, endAt);
      w.fbMin = Math.min(w.fbMin, headersAt - sentAt);
      w.fbMax = Math.max(w.fbMax, headersAt - sentAt);
      w.slowest = Math.max(w.slowest, endAt - sentAt);
      const server = serverTimingApp(serverTiming);
      if (server !== null) w.server = Math.max(w.server ?? 0, server);
      const protocol = protocolOf(this.url);
      if (protocol !== null) w.protocols[protocol] = (w.protocols[protocol] ?? 0) + 1;
    } catch {
    }
  }
  /**
   * Une ouverture en cours de film attend sa première image : l'avance réduite d'un saut, jusqu'à ce
   * qu'elle soit là (`seekSettled`, appelé au premier envoi) ou que `SEEK_FOCUS_MS` passe.
   *
   * Une reprise est un saut fait à l'ouverture, et elle souffrait de ce que `SEEK_PREFETCH_CHUNKS` a
   * corrigé pour les sauts : le morceau où elle tombe arrive seul, puis ceux qu'il faut encore pour la
   * première image partagent le lien avec la lecture en avance entière. Banc du 24/11/2026, 50 Mb/s et
   * 40 ms de latence, reprise à dix minutes : voir docs/rd-ouverture.md. Rien n'est coupé ici — il n'y a
   * pas d'ancienne position à abandonner.
   */
  focusOpening() {
    this.focusUntil = performance.now() + SEEK_FOCUS_MS;
  }
  seekSettled() {
    if (this.focusUntil === 0) return;
    this.focusUntil = 0;
    if (this.lastDemanded >= 0) this.prefetchAfter(this.lastDemanded);
  }
  networkSinceSeek() {
    const w = this.window;
    if (!w || w.requests === 0) return null;
    return {
      requests: w.requests,
      bytes: w.bytes,
      elapsedMs: Math.round(w.lastEnd - w.since),
      firstByteMinMs: Math.round(w.fbMin),
      firstByteMaxMs: Math.round(w.fbMax),
      slowestMs: Math.round(w.slowest),
      serverMaxMs: w.server,
      protocols: { ...w.protocols },
      demand: Object.fromEntries(Object.entries(w.demand).map(([who, d]) => [who, { ...d }]))
    };
  }
  held() {
    return { size: this.size, lastModified: this.lastModified, chunks: new Map(this.chunks) };
  }
  keep(from, to) {
    if (!(to > from)) {
      this.kept = null;
      return;
    }
    const first = Math.max(0, Math.floor(from / CHUNK_SIZE));
    const last = Math.min(Math.floor((to - 1) / CHUNK_SIZE), first + MAX_KEPT_CHUNKS - 1);
    this.kept = { first, last };
  }
  /**
   * Le plus ancien d'abord — un démultiplexeur lit presque toujours en avant, donc le plus ancien
   * est d'ordinaire le moins utile —, sauf la zone gardée. Si tout ce qui reste est gardé, le plus
   * ancien part quand même : la borne de mémoire passe avant la préférence.
   */
  evict() {
    while (this.chunks.size > MAX_CACHED_CHUNKS) {
      let victim;
      for (const index of this.chunks.keys()) {
        if (!this.kept || index < this.kept.first || index > this.kept.last) {
          victim = index;
          break;
        }
      }
      victim ??= this.chunks.keys().next().value;
      if (victim === void 0) break;
      this.chunks.delete(victim);
    }
  }
  /**
   * Ferme une source de préparation en laissant ses morceaux à l'ouverture qui suivra — voir `prepared`.
   * Ses requêtes en cours meurent avec elle, et le relais d'une réouverture n'est pas touché.
   */
  closePrepared(key) {
    if (this.controller.signal.aborted) return;
    const chunks = this.chunks;
    const size = this.size;
    this.close(false);
    leavePrepared(key, size, chunks);
  }
  /**
   * @param leaveForNext laisser ses morceaux au relais (voir `handover`). Faux pour une source qui
   *   ne sert qu'à préparer un autre fichier — l'épisode suivant — et qui, sinon, prendrait la place
   *   unique du relais au film en cours.
   */
  close(leaveForNext = true) {
    if (this.controller.signal.aborted) return;
    this.controller.abort();
    if (typeof document !== "undefined") document.removeEventListener("visibilitychange", this.onVisibility);
    if (typeof window !== "undefined" && typeof window.removeEventListener === "function") window.removeEventListener("online", this.onOnline);
    this.silentAttempts.clear();
    for (const own of this.inflightControllers.values()) own.abort();
    this.inflightControllers.clear();
    if (leaveForNext) leaveHandover(this.url, this.size, this.chunks, this.kept, this.reserve);
    this.chunks = /* @__PURE__ */ new Map();
    this.reserve = /* @__PURE__ */ new Map();
    this.reserveInflight.clear();
    this.inflight.clear();
  }
};

// src/engine/matroskaIds.ts
var ID = {
  EBML: 440786851,
  Segment: 408125543,
  SeekHead: 290298740,
  Seek: 19899,
  SeekID: 21419,
  SeekPosition: 21420,
  Info: 357149030,
  TimestampScale: 2807729,
  Duration: 17545,
  /** Les étiquettes — lues seulement pour la durée, quand l'en-tête ne la donne pas. */
  Tags: 307544935,
  Tag: 29555,
  SimpleTag: 26568,
  TagName: 17827,
  TagString: 17543,
  Tracks: 374648427,
  TrackEntry: 174,
  TrackNumber: 215,
  TrackType: 131,
  CodecID: 134,
  CodecPrivate: 25506,
  /**
   * La configuration Dolby Vision, rangée là où Matroska range les extensions de piste.
   *
   * `BlockAdditionMapping` décrit ce qui s'ajoute aux blocs d'une piste ; pour le Dolby Vision il
   * ne s'agit pas de données par bloc mais d'un enregistrement de configuration, porté une fois
   * par `BlockAddIDExtraData` et nommé par `BlockAddIDType` — « dvcC » ou « dvvC », selon la
   * version du format. C'est exactement l'enregistrement que le MP4 attend dans sa propre boîte.
   *
   * Relevé sur un film : présent à l'octet 4612, donc dans l'en-tête que cet
   * analyseur lit déjà, et nommé `dvvC`.
   */
  BlockAdditionMapping: 16868,
  BlockAddIDType: 16871,
  BlockAddIDExtraData: 16877,
  DefaultDuration: 2352003,
  Language: 2274716,
  LanguageBCP47: 2274717,
  TrackName: 21358,
  FlagDefault: 136,
  FlagForced: 21930,
  /** `FlagHearingImpaired` — les sous-titres qui décrivent aussi les sons, pas seulement les mots. */
  FlagHearingImpaired: 21931,
  FlagEnabled: 185,
  Video: 224,
  PixelWidth: 176,
  PixelHeight: 186,
  DisplayWidth: 21680,
  DisplayHeight: 21690,
  Colour: 21936,
  MatrixCoefficients: 21937,
  TransferCharacteristics: 21946,
  Primaries: 21947,
  ColourRange: 21945,
  /** The brightest and dimmest the content itself ever gets, in nits. Often absent. */
  MaxCll: 21948,
  MaxFall: 21949,
  /** How bright the display it was graded on could go. This is what a tone map normalises to. */
  MasteringMetadata: 21968,
  PrimaryRChromaticityX: 21969,
  PrimaryRChromaticityY: 21970,
  PrimaryGChromaticityX: 21971,
  PrimaryGChromaticityY: 21972,
  PrimaryBChromaticityX: 21973,
  PrimaryBChromaticityY: 21974,
  WhitePointChromaticityX: 21975,
  WhitePointChromaticityY: 21976,
  LuminanceMax: 21977,
  LuminanceMin: 21978,
  BitsPerChannel: 21938,
  Audio: 225,
  SamplingFrequency: 181,
  OutputSamplingFrequency: 30901,
  Channels: 159,
  AudioBitDepth: 25188,
  Cues: 475249515,
  CuePoint: 187,
  CueTime: 179,
  CueTrackPositions: 183,
  CueTrack: 247,
  CueClusterPosition: 241,
  CueRelativePosition: 240,
  Cluster: 524531317,
  Timestamp: 231,
  SimpleBlock: 163,
  BlockGroup: 160,
  Block: 161,
  BlockDuration: 155,
  ReferenceBlock: 251
};
var TRACK_TYPE = { video: 1, audio: 2, subtitle: 17 };

// src/engine/ebml.ts
function widthOf(firstByte) {
  for (let width = 1; width <= 8; width++) {
    if (firstByte & 128 >> width - 1) return width;
  }
  return 0;
}
function readElementId(bytes, at) {
  if (at >= bytes.length) return null;
  const width = widthOf(bytes[at]);
  if (width === 0 || at + width > bytes.length) return null;
  let value = 0;
  for (let i = 0; i < width; i++) value = value * 256 + bytes[at + i];
  return { value, width };
}
function readVarSize(bytes, at) {
  if (at >= bytes.length) return null;
  const width = widthOf(bytes[at]);
  if (width === 0 || at + width > bytes.length) return null;
  let value = bytes[at] & 255 >> width;
  let allOnes = value === 255 >> width;
  for (let i = 1; i < width; i++) {
    const byte = bytes[at + i];
    if (byte !== 255) allOnes = false;
    value = value * 256 + byte;
  }
  return { value: allOnes ? null : value, width };
}
function readVarInt(bytes, at) {
  const raw = readVarSize(bytes, at);
  if (!raw || raw.value === null) return null;
  const bias = 2 ** (7 * raw.width - 1) - 1;
  return { value: raw.value - bias, width: raw.width };
}
function readUint(bytes) {
  let value = 0;
  for (const byte of bytes) value = value * 256 + byte;
  return value;
}
function readFloat(bytes) {
  const view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length === 4) return view2.getFloat32(0);
  if (bytes.length === 8) return view2.getFloat64(0);
  return 0;
}
function readString(bytes) {
  return new TextDecoder().decode(bytes).replace(/\0+$/, "");
}
var HEADER_WINDOW = 16;
async function readElementAt(source, offset) {
  const header = await readElementHeader(source, offset);
  return header === UNREADABLE ? null : header;
}
var UNREADABLE = "illisible";
async function readElementHeader(source, offset) {
  if (offset >= source.size) return null;
  const window2 = await source.read(offset, HEADER_WINDOW);
  const id = readElementId(window2, 0);
  if (!id) return windowComplete(window2, source, offset) && window2[0] === 0 ? UNREADABLE : null;
  const size = readVarSize(window2, id.width);
  if (!size) return windowComplete(window2, source, offset) && id.width < window2.length && window2[id.width] === 0 ? UNREADABLE : null;
  const headerSize = id.width + size.width;
  return { id: id.value, size: size.value, offset: offset + headerSize, headerSize };
}
function windowComplete(window2, source, offset) {
  return window2.length > 0 && window2.length >= Math.min(HEADER_WINDOW, source.size - offset);
}
async function forEachChild(source, start, end, visit, onUnreadable) {
  let cursor = start;
  while (cursor < end) {
    const element = await readElementHeader(source, cursor);
    if (element === UNREADABLE) {
      if (onUnreadable) await onUnreadable(cursor);
      return;
    }
    if (!element) return;
    if (element.size !== null && element.offset + element.size > end + element.headerSize) {
      return;
    }
    if (await visit(element) === "stop") return;
    if (element.size === null) return;
    cursor = element.offset + element.size;
  }
}

// src/engine/rememberedHeaders.ts
function rememberedHeaders(max) {
  const parsed3 = /* @__PURE__ */ new Map();
  return {
    get(key) {
      return parsed3.get(key);
    },
    forget(key) {
      parsed3.delete(key);
    },
    remember(key, file) {
      parsed3.set(key, file);
      while (parsed3.size > max) {
        const oldest = parsed3.keys().next().value;
        if (oldest === void 0) break;
        parsed3.delete(oldest);
      }
    }
  };
}

// src/engine/matroska.ts
var NS_PER_US = 1e3;
var DEFAULT_TIMESTAMP_SCALE_NS = 1e6;
function trackTypeOf(raw) {
  if (raw === TRACK_TYPE.video) return "video";
  if (raw === TRACK_TYPE.audio) return "audio";
  if (raw === TRACK_TYPE.subtitle) return "subtitle";
  return "other";
}
async function payload(source, element) {
  if (element.size === null) return new Uint8Array(0);
  return source.read(element.offset, element.size);
}
async function readSeekHead(source, offset, end, segmentDataStart, into) {
  await forEachChild(source, offset, end, async (seek) => {
    if (seek.id !== ID.Seek) return "continue";
    let id = 0;
    let position = -1;
    await forEachChild(source, seek.offset, seek.offset + (seek.size ?? 0), async (s) => {
      if (s.id === ID.SeekID) id = readUint(await payload(source, s));
      if (s.id === ID.SeekPosition) position = readUint(await payload(source, s));
      return "continue";
    });
    if (id && position >= 0) into.set(id, segmentDataStart + position);
    return "continue";
  });
}
async function followSeekHeadLink(source, segmentDataStart, positions, needed) {
  const at = positions.get(ID.SeekHead);
  if (!needed || at === void 0 || at >= source.size) return;
  const el = await readElementAt(source, at);
  if (!el || el.id !== ID.SeekHead || el.size === null) return;
  const found = /* @__PURE__ */ new Map();
  await readSeekHead(source, el.offset, Math.min(el.offset + el.size, source.size), segmentDataStart, found);
  for (const [id, position] of found) if (!positions.has(id)) positions.set(id, position);
}
async function parseTrackEntry(source, start, end) {
  const track = {
    number: 0,
    type: "other",
    codecId: "",
    codecPrivate: null,
    language: null,
    name: null,
    isDefault: false,
    isForced: false,
    isHearingImpaired: false,
    isEnabled: true,
    defaultDurationNs: null
  };
  let langueDeclaree = false;
  await forEachChild(source, start, end, async (el) => {
    switch (el.id) {
      case ID.TrackNumber:
        track.number = readUint(await payload(source, el));
        break;
      case ID.TrackType:
        track.type = trackTypeOf(readUint(await payload(source, el)));
        break;
      case ID.CodecID:
        track.codecId = readString(await payload(source, el));
        break;
      case ID.CodecPrivate:
        track.codecPrivate = new Uint8Array(await payload(source, el));
        break;
      case ID.Language:
      case ID.LanguageBCP47: {
        const lu = readString(await payload(source, el));
        if (lu) langueDeclaree = true;
        track.language = lu || track.language;
        break;
      }
      case ID.TrackName:
        track.name = readString(await payload(source, el));
        break;
      case ID.FlagDefault:
        track.isDefault = readUint(await payload(source, el)) === 1;
        break;
      case ID.FlagHearingImpaired:
        track.isHearingImpaired = readUint(await payload(source, el)) === 1;
        break;
      case ID.FlagForced:
        track.isForced = readUint(await payload(source, el)) === 1;
        break;
      case ID.FlagEnabled:
        track.isEnabled = readUint(await payload(source, el)) !== 0;
        break;
      case ID.DefaultDuration:
        track.defaultDurationNs = readUint(await payload(source, el));
        break;
      case ID.BlockAdditionMapping: {
        let type = null;
        let record2 = null;
        await forEachChild(source, el.offset, el.offset + (el.size ?? 0), async (b) => {
          if (b.id === ID.BlockAddIDType) {
            const value = readUint(await payload(source, b));
            type = String.fromCharCode(value >>> 24 & 255, value >>> 16 & 255, value >>> 8 & 255, value & 255);
          } else if (b.id === ID.BlockAddIDExtraData) {
            record2 = new Uint8Array(await payload(source, b));
          }
        });
        if ((type === "dvcC" || type === "dvvC") && record2) track.dolbyVision = { type, record: record2 };
        break;
      }
      case ID.Video: {
        const video = { width: 0, height: 0 };
        await forEachChild(source, el.offset, el.offset + (el.size ?? 0), async (v) => {
          switch (v.id) {
            case ID.PixelWidth:
              video.width = readUint(await payload(source, v));
              break;
            case ID.PixelHeight:
              video.height = readUint(await payload(source, v));
              break;
            case ID.DisplayWidth:
              video.displayWidth = readUint(await payload(source, v));
              break;
            case ID.DisplayHeight:
              video.displayHeight = readUint(await payload(source, v));
              break;
            case ID.Colour: {
              const colour = {};
              await forEachChild(source, v.offset, v.offset + (v.size ?? 0), async (c) => {
                switch (c.id) {
                  case ID.MatrixCoefficients:
                    colour.matrixCoefficients = readUint(await payload(source, c));
                    break;
                  case ID.TransferCharacteristics:
                    colour.transferCharacteristics = readUint(await payload(source, c));
                    break;
                  case ID.Primaries:
                    colour.primaries = readUint(await payload(source, c));
                    break;
                  case ID.ColourRange:
                    colour.range = readUint(await payload(source, c));
                    break;
                  case ID.BitsPerChannel:
                    colour.bitsPerChannel = readUint(await payload(source, c));
                    break;
                  case ID.MaxCll: {
                    const nits = readUint(await payload(source, c));
                    if (nits > 0) colour.maxContentLightNits = nits;
                    break;
                  }
                  case ID.MaxFall: {
                    const nits = readUint(await payload(source, c));
                    if (nits > 0) colour.maxFrameAverageNits = nits;
                    break;
                  }
                  case ID.MasteringMetadata: {
                    const chroma = {};
                    await forEachChild(source, c.offset, c.offset + (c.size ?? 0), async (m) => {
                      const value = readFloat(await payload(source, m));
                      if (m.id === ID.LuminanceMax && value > 0) colour.masteringMaxNits = value;
                      else if (m.id === ID.LuminanceMin && value >= 0) colour.masteringMinNits = value;
                      else if (m.id >= ID.PrimaryRChromaticityX && m.id <= ID.WhitePointChromaticityY) chroma[m.id] = value;
                      return "continue";
                    });
                    const at = (id) => chroma[id];
                    const ids = [
                      ID.PrimaryRChromaticityX,
                      ID.PrimaryRChromaticityY,
                      ID.PrimaryGChromaticityX,
                      ID.PrimaryGChromaticityY,
                      ID.PrimaryBChromaticityX,
                      ID.PrimaryBChromaticityY,
                      ID.WhitePointChromaticityX,
                      ID.WhitePointChromaticityY
                    ];
                    if (ids.every((id) => typeof at(id) === "number" && at(id) > 0 && at(id) < 1)) {
                      colour.masteringPrimaries = {
                        r: [at(ID.PrimaryRChromaticityX), at(ID.PrimaryRChromaticityY)],
                        g: [at(ID.PrimaryGChromaticityX), at(ID.PrimaryGChromaticityY)],
                        b: [at(ID.PrimaryBChromaticityX), at(ID.PrimaryBChromaticityY)],
                        white: [at(ID.WhitePointChromaticityX), at(ID.WhitePointChromaticityY)]
                      };
                    }
                    break;
                  }
                }
                return "continue";
              });
              video.colour = colour;
              break;
            }
          }
          return "continue";
        });
        track.video = video;
        break;
      }
      case ID.Audio: {
        const audio = { sampleRate: 8e3, channels: 1 };
        await forEachChild(source, el.offset, el.offset + (el.size ?? 0), async (a) => {
          switch (a.id) {
            case ID.SamplingFrequency:
              audio.sampleRate = readFloat(await payload(source, a));
              break;
            // SBR/HE-AAC stores the real output rate here; it wins when present because that is
            // the rate the decoder actually produces.
            case ID.OutputSamplingFrequency:
              audio.sampleRate = readFloat(await payload(source, a));
              break;
            case ID.Channels:
              audio.channels = readUint(await payload(source, a));
              break;
            case ID.AudioBitDepth:
              audio.bitDepth = readUint(await payload(source, a));
              break;
          }
          return "continue";
        });
        track.audio = audio;
        break;
      }
    }
    return "continue";
  });
  if (!langueDeclaree) track.language = "eng";
  return track.number > 0 ? track : null;
}
var parsed = rememberedHeaders(4);
function forgetMatroskaHeader(key) {
  parsed.forget(key);
}
async function parseMatroska(source, key) {
  const remembered = key === void 0 ? void 0 : parsed.get(key);
  if (remembered && remembered.segmentEnd <= source.size) return remembered;
  const file = await readMatroska(source);
  if (key !== void 0) parsed.remember(key, file);
  return file;
}
async function tagsDuration(source, start, end) {
  let longest = null;
  await forEachChild(source, start, end, async (tag) => {
    if (tag.id !== ID.Tag) return "continue";
    await forEachChild(source, tag.offset, tag.offset + (tag.size ?? 0), async (simple) => {
      if (simple.id !== ID.SimpleTag) return "continue";
      let name = "";
      let value = "";
      await forEachChild(source, simple.offset, simple.offset + (simple.size ?? 0), async (field) => {
        if (field.id === ID.TagName) name = new TextDecoder().decode(await payload(source, field));
        if (field.id === ID.TagString) value = new TextDecoder().decode(await payload(source, field));
        return "continue";
      });
      const seconds = name.toUpperCase() === "DURATION" ? parseTagDuration(value) : null;
      if (seconds !== null && (longest === null || seconds > longest)) longest = seconds;
      return "continue";
    });
    return "continue";
  });
  return longest;
}
function parseTagDuration(value) {
  const match = /^\s*(\d+):(\d{1,2}):(\d{1,2}(?:\.\d+)?)\s*$/.exec(value.replace(/\0/g, ""));
  if (!match) return null;
  const seconds = Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]);
  return Number.isFinite(seconds) && seconds > 0 ? seconds : null;
}
async function realignCues(source, file) {
  if (file.cues.length < 2 || file.firstClusterOffset === null) return;
  const earliest = file.cues.reduce((min, cue) => Math.min(min, cue.clusterOffset), Infinity);
  if (earliest === file.firstClusterOffset) return;
  const isCluster = async (offset) => {
    if (offset < 0 || offset >= source.size) return false;
    try {
      return (await readElementAt(source, offset))?.id === ID.Cluster;
    } catch {
      return false;
    }
  };
  const probe = file.cues[Math.floor(file.cues.length / 2)].clusterOffset;
  if (await isCluster(probe)) return;
  const delta = file.firstClusterOffset - earliest;
  if (!await isCluster(probe + delta)) return;
  for (const cue of file.cues) cue.clusterOffset += delta;
}
async function readMatroska(source) {
  const first = await readElementAt(source, 0);
  if (!first || first.id !== ID.EBML) throw new Error("Ce fichier n'est pas un conteneur Matroska.");
  let cursor = first.offset + (first.size ?? 0);
  let segment = await readElementAt(source, cursor);
  while (segment && segment.id !== ID.Segment) {
    if (segment.size === null) break;
    cursor = segment.offset + segment.size;
    segment = await readElementAt(source, cursor);
  }
  if (!segment || segment.id !== ID.Segment) throw new Error("Segment Matroska introuvable.");
  const segmentDataStart = segment.offset;
  const segmentEnd = segment.size === null ? source.size : Math.min(segment.offset + segment.size, source.size);
  const file = {
    timestampScaleNs: DEFAULT_TIMESTAMP_SCALE_NS,
    durationSeconds: null,
    tracks: [],
    cues: [],
    segmentDataStart,
    segmentEnd,
    segmentSized: segment.size !== null,
    firstClusterOffset: null
  };
  const seekPositions = /* @__PURE__ */ new Map();
  let taggedDuration = null;
  await forEachChild(source, segmentDataStart, segmentEnd, async (el) => {
    switch (el.id) {
      case ID.SeekHead:
        await readSeekHead(source, el.offset, el.offset + (el.size ?? 0), segmentDataStart, seekPositions);
        return "continue";
      case ID.Info: {
        let durationTicks = null;
        await forEachChild(source, el.offset, el.offset + (el.size ?? 0), async (info) => {
          if (info.id === ID.TimestampScale) file.timestampScaleNs = readUint(await payload(source, info)) || DEFAULT_TIMESTAMP_SCALE_NS;
          if (info.id === ID.Duration) durationTicks = readFloat(await payload(source, info));
          return "continue";
        });
        if (durationTicks !== null) file.durationSeconds = durationTicks * file.timestampScaleNs / 1e9;
        return "continue";
      }
      case ID.Tracks: {
        const end = el.offset + (el.size ?? 0);
        const buffered = await SlicedSource.of(source, el.offset, end);
        await forEachChild(buffered, el.offset, end, async (entry) => {
          if (entry.id !== ID.TrackEntry) return "continue";
          const track = await parseTrackEntry(buffered, entry.offset, entry.offset + (entry.size ?? 0));
          if (track) file.tracks.push(track);
          return "continue";
        });
        return "continue";
      }
      case ID.Cues: {
        const end = el.offset + (el.size ?? 0);
        await parseCues(await SlicedSource.of(source, el.offset, end), el.offset, end, segmentDataStart, file);
        return "continue";
      }
      case ID.Tags: {
        const end = el.offset + (el.size ?? 0);
        taggedDuration = await tagsDuration(await SlicedSource.of(source, el.offset, end), el.offset, end);
        return "continue";
      }
      case ID.Cluster:
        file.firstClusterOffset = el.offset - el.headerSize;
        return "stop";
    }
    return "continue";
  });
  await followSeekHeadLink(source, segmentDataStart, seekPositions, file.tracks.length === 0 || file.cues.length === 0);
  if (file.durationSeconds === null) {
    if (taggedDuration === null) {
      const tagsOffset = seekPositions.get(ID.Tags);
      if (tagsOffset !== void 0 && tagsOffset < source.size) {
        const tags = await readElementAt(source, tagsOffset);
        if (tags && tags.id === ID.Tags && tags.size !== null) {
          const end = tags.offset + tags.size;
          taggedDuration = await tagsDuration(await SlicedSource.of(source, tags.offset, end), tags.offset, end);
        }
      }
    }
    if (taggedDuration !== null) file.durationSeconds = taggedDuration;
  }
  if (file.cues.length === 0) {
    const cuesOffset = seekPositions.get(ID.Cues);
    if (cuesOffset !== void 0 && cuesOffset < source.size) {
      const cues = await readElementAt(source, cuesOffset);
      if (cues && cues.id === ID.Cues && cues.size !== null) {
        const end = cues.offset + cues.size;
        await parseCues(await SlicedSource.of(source, cues.offset, end), cues.offset, end, segmentDataStart, file);
      }
    }
  }
  if (file.tracks.length === 0) {
    const tracksOffset = seekPositions.get(ID.Tracks);
    if (tracksOffset !== void 0 && tracksOffset < source.size) {
      const tracks = await readElementAt(source, tracksOffset);
      if (tracks && tracks.id === ID.Tracks && tracks.size !== null) {
        const end = tracks.offset + tracks.size;
        const buffered = await SlicedSource.of(source, tracks.offset, end);
        await forEachChild(buffered, tracks.offset, end, async (entry) => {
          if (entry.id !== ID.TrackEntry) return "continue";
          const track = await parseTrackEntry(buffered, entry.offset, entry.offset + (entry.size ?? 0));
          if (track) file.tracks.push(track);
          return "continue";
        });
      }
    }
  }
  if (file.tracks.length === 0) throw new Error("Aucune piste lisible dans ce fichier.");
  file.cues.sort((a, b) => a.timeUs - b.timeUs);
  await realignCues(source, file);
  return file;
}
async function parseCues(source, start, end, segmentDataStart, file) {
  await forEachChild(source, start, end, async (point) => {
    if (point.id !== ID.CuePoint) return "continue";
    let time = -1;
    const positions = [];
    await forEachChild(source, point.offset, point.offset + (point.size ?? 0), async (c) => {
      if (c.id === ID.CueTime) time = readUint(await payload(source, c));
      if (c.id === ID.CueTrackPositions) {
        let track = -1;
        let clusterPosition = -1;
        await forEachChild(source, c.offset, c.offset + (c.size ?? 0), async (p) => {
          if (p.id === ID.CueTrack) track = readUint(await payload(source, p));
          if (p.id === ID.CueClusterPosition && clusterPosition < 0) clusterPosition = readUint(await payload(source, p));
          return "continue";
        });
        if (track >= 0 && clusterPosition >= 0) positions.push({ track, clusterPosition });
      }
      return "continue";
    });
    if (time >= 0) {
      for (const { track, clusterPosition } of positions) {
        file.cues.push({
          track,
          timeUs: Math.round(time * file.timestampScaleNs / NS_PER_US),
          clusterOffset: segmentDataStart + clusterPosition
        });
      }
    }
    return "continue";
  });
}
function clusterOffsetForTime(file, timeUs, trackNumber) {
  const forTrack = trackNumber === void 0 ? file.cues : file.cues.filter((cue) => cue.track === trackNumber);
  const cues = forTrack.length > 0 ? forTrack : file.cues;
  if (cues.length === 0) return file.firstClusterOffset;
  let best = cues[0];
  for (const cue of cues) {
    if (cue.timeUs <= timeUs) best = cue;
    else break;
  }
  return best.clusterOffset;
}
function cueTimeAfter(file, timeUs, trackNumber) {
  const forTrack = trackNumber === void 0 ? file.cues : file.cues.filter((cue) => cue.track === trackNumber);
  const cues = forTrack.length > 0 ? forTrack : file.cues;
  for (const cue of cues) if (cue.timeUs > timeUs) return cue.timeUs;
  return null;
}
function cueTimeAtOrBefore(file, timeUs, trackNumber) {
  const forTrack = trackNumber === void 0 ? file.cues : file.cues.filter((cue) => cue.track === trackNumber);
  const cues = forTrack.length > 0 ? forTrack : file.cues;
  let best = null;
  for (const cue of cues) {
    if (cue.timeUs <= timeUs) best = cue.timeUs;
    else break;
  }
  return best;
}
function keptRangeAt(file, seconds, trackNumber, aheadSeconds = 4) {
  const forTrack = trackNumber === void 0 ? file.cues : file.cues.filter((cue) => cue.track === trackNumber);
  const cues = forTrack.length > 0 ? forTrack : file.cues;
  if (cues.length === 0) return null;
  const startUs = Math.max(0, seconds - 1) * 1e6;
  const endUs = (seconds + aheadSeconds) * 1e6;
  let from = cues[0].clusterOffset;
  let to = null;
  for (const cue of cues) {
    if (cue.timeUs <= startUs) from = cue.clusterOffset;
    else if (cue.timeUs >= endUs) {
      to = cue.clusterOffset;
      break;
    }
  }
  return { from, to: to ?? file.segmentEnd };
}
function unlace(data, flags) {
  const lacing = flags >> 1 & 3;
  if (lacing === 0) return [data];
  const frameCount = data[0] + 1;
  let at = 1;
  const sizes = [];
  if (lacing === 2) {
    const size = Math.floor((data.length - at) / frameCount);
    for (let i = 0; i < frameCount; i++) sizes.push(size);
  } else if (lacing === 1) {
    for (let i = 0; i < frameCount - 1; i++) {
      let size = 0;
      while (at < data.length) {
        size += data[at];
        if (data[at++] !== 255) break;
      }
      sizes.push(size);
    }
  } else {
    const first = readVarSize(data, at);
    if (!first || first.value === null) return [data];
    at += first.width;
    sizes.push(first.value);
    for (let i = 1; i < frameCount - 1; i++) {
      const delta = readVarInt(data, at);
      if (!delta) return [data];
      at += delta.width;
      sizes.push(sizes[sizes.length - 1] + delta.value);
    }
  }
  const frames = [];
  for (const size of sizes) {
    if (at + size > data.length) return frames.length ? frames : [data];
    frames.push(data.subarray(at, at + size));
    at += size;
  }
  if (lacing !== 2 && at <= data.length) frames.push(data.subarray(at));
  return frames;
}
function parseBlock(data, clusterTimeTicks, timestampScaleNs, isSimple, blockGroupIsKey) {
  const track = readVarSize(data, 0);
  if (!track || track.value === null) return [];
  let at = track.width;
  if (at + 3 > data.length) return [];
  const view2 = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const relative = view2.getInt16(at);
  at += 2;
  const flags = data[at];
  at += 1;
  const isKey = isSimple ? (flags & 128) !== 0 : blockGroupIsKey;
  const usPerTick = timestampScaleNs / NS_PER_US;
  const timestampUs = Math.round((clusterTimeTicks + relative) * usPerTick);
  const frames = unlace(data.subarray(at), flags);
  return frames.map((frame) => ({
    trackNumber: track.value,
    timestampUs,
    durationUs: null,
    isKey,
    data: frame
  }));
}

// src/engine/mp4Demux.ts
var Mp4Refusal = class extends Error {
};
function fourcc(bytes, at) {
  return String.fromCharCode(bytes[at], bytes[at + 1], bytes[at + 2], bytes[at + 3]);
}
function view(bytes) {
  return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}
function u64(dv, at) {
  return dv.getUint32(at) * 2 ** 32 + dv.getUint32(at + 4);
}
function i64(dv, at) {
  return dv.getInt32(at) * 2 ** 32 + dv.getUint32(at + 4);
}
function children(bytes, from, to) {
  const dv = view(bytes);
  const boxes = [];
  let at = from;
  while (at + 8 <= to) {
    let size = dv.getUint32(at);
    const type = fourcc(bytes, at + 4);
    let header = 8;
    if (size === 1) {
      if (at + 16 > to) break;
      size = u64(dv, at + 8);
      header = 16;
    } else if (size === 0) {
      size = to - at;
    }
    if (size < header || at + size > to) break;
    boxes.push({ type, start: at, body: at + header, end: at + size });
    at += size;
  }
  return boxes;
}
function child(bytes, parent, type) {
  return children(bytes, parent.body, parent.end).find((b) => b.type === type);
}
function path(bytes, parent, ...types) {
  let current2 = parent;
  for (const type of types) {
    if (!current2) return void 0;
    current2 = child(bytes, current2, type);
  }
  return current2;
}
async function topLevel(source) {
  const boxes = [];
  let at = 0;
  for (let i = 0; i < 64 && at + 8 <= source.size; i++) {
    const head = await source.read(at, 16);
    if (head.length < 8) break;
    const dv = view(head);
    let size = dv.getUint32(0);
    const type = fourcc(head, 4);
    let header = 8;
    if (size === 1) {
      if (head.length < 16) break;
      size = u64(dv, 8);
      header = 16;
    } else if (size === 0) {
      size = source.size - at;
    }
    if (size < header) break;
    boxes.push({ type, start: at, body: at + header, end: Math.min(at + size, source.size) });
    if (type === "moof") break;
    at += size;
  }
  return boxes;
}
var ISO_FIRST_BOXES = /* @__PURE__ */ new Set(["ftyp", "moov", "mdat", "free", "skip", "wide", "pnot", "styp"]);
function isIsoBaseMedia(head) {
  return head.length >= 8 && ISO_FIRST_BOXES.has(fourcc(head, 4));
}
var MAC_LANGUAGES = ["eng", "fre", "ger", "ita", "dut", "swe", "spa", "dan", "por", "nor", "heb", "jpn", "ara", "fin", "gre"];
function mdhdLanguage(packed) {
  if (packed < 1024) return MAC_LANGUAGES[packed] ?? null;
  if (packed === 32767) return null;
  const code = String.fromCharCode((packed >> 10 & 31) + 96, (packed >> 5 & 31) + 96, (packed & 31) + 96);
  return /^[a-z]{3}$/.test(code) && code !== "und" ? code : null;
}
function meaningfulName(name) {
  const trimmed = name.replace(/\0/g, "").trim();
  if (!trimmed) return null;
  if (/handler|^(core media|gpac|l-smash|mainconcept|isomedia|apple|bento4|mp4box)\b/i.test(trimmed)) return null;
  return trimmed;
}
function cString(bytes, from, to) {
  let end = from;
  while (end < to && bytes[end] !== 0) end++;
  return new TextDecoder().decode(bytes.subarray(from, end));
}
function readEsds(bytes, from, to) {
  let at = from + 4;
  let objectType = 0;
  let config = null;
  const readLength = () => {
    let length = 0;
    for (let i = 0; i < 4 && at < to; i++) {
      const byte = bytes[at++];
      length = length << 7 | byte & 127;
      if ((byte & 128) === 0) break;
    }
    return length;
  };
  const walk = (end) => {
    while (at + 2 <= end && config === null) {
      const tag = bytes[at++];
      const length = readLength();
      const payloadEnd = Math.min(at + length, end);
      if (tag === 3) {
        const flags = bytes[at + 2];
        at += 3;
        if (flags & 128) at += 2;
        if (flags & 64) at += 1 + bytes[at];
        if (flags & 32) at += 2;
        walk(payloadEnd);
      } else if (tag === 4) {
        objectType = bytes[at];
        at += 13;
        walk(payloadEnd);
      } else if (tag === 5) {
        config = bytes.slice(at, payloadEnd);
      }
      at = payloadEnd;
    }
  };
  walk(to);
  return { objectType, config };
}
var ACMOD_CHANNELS = [2, 1, 2, 3, 3, 4, 4, 5];
var AC3_RATES = [48e3, 44100, 32e3];
function dac3Format(bytes, at) {
  const fscod = bytes[at] >> 6;
  const acmod = bytes[at + 1] >> 3 & 7;
  const lfe = bytes[at + 1] >> 2 & 1;
  return { channels: ACMOD_CHANNELS[acmod] + lfe, sampleRate: AC3_RATES[fscod] ?? 48e3 };
}
var CHAN_LOC_CHANNELS = [2, 2, 1, 1, 2, 2, 2, 1, 1];
function dec3Format(bytes, at, end) {
  if (at + 5 > end) return null;
  let bit = (at + 2) * 8;
  const read = (count) => {
    let value = 0;
    for (let i = 0; i < count; i++, bit++) value = value << 1 | bytes[bit >> 3] >> 7 - (bit & 7) & 1;
    return value;
  };
  const fscod = read(2);
  read(5);
  read(1);
  read(1);
  read(3);
  const acmod = read(3);
  const lfe = read(1);
  read(3);
  const dependents = read(4);
  let channels = ACMOD_CHANNELS[acmod] + lfe;
  if (dependents > 0 && bit + 9 <= end * 8) {
    const location2 = read(9);
    for (let i = 0; i < 9; i++) if (location2 & 1 << 8 - i) channels += CHAN_LOC_CHANNELS[i];
  }
  return { channels, sampleRate: AC3_RATES[fscod] ?? 48e3 };
}
function opusHeadFromDops(bytes, from, to) {
  if (to - from < 11) return null;
  const dv = view(bytes);
  const channels = bytes[from + 1];
  const family = bytes[from + 10];
  const table = family === 0 ? new Uint8Array(0) : bytes.subarray(from + 11, Math.min(to, from + 13 + channels));
  const head = new Uint8Array(19 + table.length);
  const out = view(head);
  head.set([79, 112, 117, 115, 72, 101, 97, 100]);
  head[8] = 1;
  head[9] = channels;
  out.setUint16(10, dv.getUint16(from + 2), true);
  out.setUint32(12, dv.getUint32(from + 4), true);
  out.setInt16(16, dv.getInt16(from + 8), true);
  head[18] = family;
  head.set(table, 19);
  return head;
}
function flacStreamInfo(blocks) {
  if (blocks.length < 4 + 18 || (blocks[0] & 127) !== 0) return null;
  const info = blocks.subarray(4);
  const sampleRate = info[10] << 12 | info[11] << 4 | info[12] >> 4;
  const channels = (info[12] >> 1 & 7) + 1;
  const bitDepth = ((info[12] & 1) << 4 | info[13] >> 4) + 1;
  return { sampleRate, channels, bitDepth };
}
function readColour(bytes, boxes) {
  const dv = view(bytes);
  const colour = {};
  let any = false;
  for (const box of boxes) {
    if (box.type === "colr" && box.end - box.body >= 10) {
      const kind = fourcc(bytes, box.body);
      if (kind === "nclx" || kind === "nclc") {
        colour.primaries = dv.getUint16(box.body + 4);
        colour.transferCharacteristics = dv.getUint16(box.body + 6);
        colour.matrixCoefficients = dv.getUint16(box.body + 8);
        if (kind === "nclx" && box.end - box.body >= 11) colour.range = bytes[box.body + 10] & 128 ? 2 : 1;
        any = true;
      }
    } else if (box.type === "mdcv" && box.end - box.body >= 24) {
      const nits = dv.getUint32(box.body + 16) / 1e4;
      if (nits > 0) colour.masteringMaxNits = nits;
      any = true;
    } else if (box.type === "clli" && box.end - box.body >= 4) {
      const nits = dv.getUint16(box.body);
      if (nits > 0) colour.maxContentLightNits = nits;
      any = true;
    }
  }
  return any ? colour : void 0;
}
function describeVisual(bytes, entry) {
  const dv = view(bytes);
  const width = dv.getUint16(entry.start + 32);
  const height = dv.getUint16(entry.start + 34);
  const boxes = children(bytes, entry.start + 86, entry.end);
  const payload2 = (type2) => {
    const box = boxes.find((b) => b.type === type2);
    return box ? bytes.slice(box.body, box.end) : null;
  };
  const video = { width, height };
  const pasp = boxes.find((b) => b.type === "pasp");
  if (pasp && pasp.end - pasp.body >= 8) {
    const h = dv.getUint32(pasp.body);
    const v = dv.getUint32(pasp.body + 4);
    if (h > 0 && v > 0 && h !== v) {
      video.displayWidth = Math.round(width * h / v);
      video.displayHeight = height;
    }
  }
  const colour = readColour(bytes, boxes);
  if (colour) video.colour = colour;
  const dvBox = boxes.find((b) => b.type === "dvcC" || b.type === "dvvC");
  const dolbyVision = dvBox ? { type: dvBox.type, record: bytes.slice(dvBox.body, dvBox.end) } : void 0;
  const type = entry.type;
  switch (type) {
    case "avc1":
    case "avc3":
    case "dvav":
    case "dva1":
      return { codecId: "V_MPEG4/ISO/AVC", codecPrivate: payload2("avcC"), video, dolbyVision };
    case "hvc1":
    case "hev1":
    case "dvh1":
    case "dvhe":
      return { codecId: "V_MPEGH/ISO/HEVC", codecPrivate: payload2("hvcC"), video, dolbyVision };
    case "av01":
      return { codecId: "V_AV1", codecPrivate: payload2("av1C"), video };
    case "vp09":
      return { codecId: "V_VP9", codecPrivate: null, video };
    case "vp08":
      return { codecId: "V_VP8", codecPrivate: null, video };
    case "mp4v": {
      const esds = boxes.find((b) => b.type === "esds");
      const { objectType, config } = esds ? readEsds(bytes, esds.body, esds.end) : { objectType: 0, config: null };
      if (objectType === 108 || objectType === 109) return { codecId: "V_MP4/jpeg", codecPrivate: null, video, still: true };
      if (objectType === 32) return { codecId: "V_MPEG4/ISO/ASP", codecPrivate: config, video };
      return { codecId: `V_MP4/mp4v-${objectType.toString(16)}`, codecPrivate: config, video };
    }
    case "jpeg":
    case "mjpa":
    case "mjpb":
    case "png ":
      return { codecId: `V_MP4/${type.trim()}`, codecPrivate: null, video, still: true };
    default:
      return { codecId: `V_MP4/${type.trim()}`, codecPrivate: null, video };
  }
}
function describeAudio(bytes, entry) {
  const dv = view(bytes);
  const version = dv.getUint16(entry.start + 16);
  let channels = dv.getUint16(entry.start + 24);
  let sampleRate = dv.getUint32(entry.start + 32) / 65536;
  let childrenAt = entry.start + 36;
  if (version === 1) childrenAt += 16;
  else if (version === 2) {
    sampleRate = dv.getFloat64(entry.start + 40);
    channels = dv.getUint32(entry.start + 48);
    childrenAt = entry.start + 72;
  }
  let boxes = children(bytes, childrenAt, entry.end);
  const wave = boxes.find((b) => b.type === "wave");
  if (wave) boxes = [...boxes, ...children(bytes, wave.body, wave.end)];
  const find = (type2) => boxes.find((b) => b.type === type2);
  const audio = { sampleRate, channels };
  const type = entry.type;
  switch (type) {
    case "mp4a": {
      const esds = find("esds");
      const { objectType, config } = esds ? readEsds(bytes, esds.body, esds.end) : { objectType: 64, config: null };
      if (objectType === 107 || objectType === 105) return { codecId: "A_MPEG/L3", codecPrivate: null, audio };
      if (objectType === 64 || objectType === 102 || objectType === 103 || objectType === 104) {
        return { codecId: "A_AAC", codecPrivate: config, audio: aacAudio(config, audio) };
      }
      return { codecId: `A_MP4/mp4a-${objectType.toString(16)}`, codecPrivate: config, audio };
    }
    case "ac-3": {
      const dac3 = find("dac3");
      return { codecId: "A_AC3", codecPrivate: null, audio: dac3 && dac3.end - dac3.body >= 3 ? dac3Format(bytes, dac3.body) : audio };
    }
    case "ec-3": {
      const dec3 = find("dec3");
      const format = dec3 ? dec3Format(bytes, dec3.body, dec3.end) : null;
      return { codecId: "A_EAC3", codecPrivate: null, audio: format ?? audio };
    }
    case "Opus": {
      const dOps = find("dOps");
      const head = dOps ? opusHeadFromDops(bytes, dOps.body, dOps.end) : null;
      return { codecId: "A_OPUS", codecPrivate: head, audio: { sampleRate: 48e3, channels: head ? head[9] : channels } };
    }
    case "fLaC": {
      const dfLa = find("dfLa");
      const blocks = dfLa ? bytes.slice(dfLa.body + 4, dfLa.end) : null;
      const codecPrivate = blocks ? new Uint8Array([102, 76, 97, 67, ...blocks]) : null;
      const info = blocks ? flacStreamInfo(blocks) : null;
      return {
        codecId: "A_FLAC",
        codecPrivate,
        audio: info ? { sampleRate: info.sampleRate, channels: info.channels, bitDepth: info.bitDepth } : audio
      };
    }
    case "mlpa":
      return { codecId: "A_TRUEHD", codecPrivate: null, audio };
    case "dtsc":
    case "dtsh":
    case "dtsl":
    case "dtse":
      return { codecId: "A_DTS", codecPrivate: null, audio };
    case ".mp3":
      return { codecId: "A_MPEG/L3", codecPrivate: null, audio };
    default:
      return { codecId: `A_MP4/${type.trim()}`, codecPrivate: null, audio };
  }
}
var ASC_RATES = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
function aacAudio(config, entry) {
  if (!config || config.length < 2) return entry;
  const objectType = config[0] >> 3;
  const core = ASC_RATES[(config[0] & 7) << 1 | config[1] >> 7];
  const configuration = config[1] >> 3 & 15;
  const channels = configuration === 7 ? 8 : configuration >= 1 && configuration <= 6 ? configuration : entry.channels;
  const sbr = objectType === 5 || objectType === 29 || entry.sampleRate === 2 * (core ?? 0);
  const sampleRate = core === void 0 ? entry.sampleRate : sbr ? Math.max(entry.sampleRate, core) : core;
  return { ...entry, sampleRate, channels };
}
function describeEntry(bytes, handler, entry) {
  if (handler === "vide") return { type: "video", ...describeVisual(bytes, entry) };
  if (handler === "soun") return { type: "audio", ...describeAudio(bytes, entry) };
  if (handler === "sbtl" || handler === "text" || handler === "subt") {
    if (entry.type === "tx3g") return { type: "subtitle", codecId: "S_TEXT/UTF8", codecPrivate: null };
    if (entry.type === "text") return { type: "other", codecId: "S_MP4/text", codecPrivate: null, chapters: true };
    return { type: "subtitle", codecId: `S_MP4/${entry.type.trim()}`, codecPrivate: null };
  }
  return { type: "other", codecId: `D_MP4/${handler.trim() || "?"}`, codecPrivate: null };
}
function sampleTable(bytes, stbl, number, timescale, shiftTicks, timedText2) {
  const dv = view(bytes);
  const boxes = children(bytes, stbl.body, stbl.end);
  const find = (type) => boxes.find((b) => b.type === type);
  let sizes;
  const stsz = find("stsz");
  const stz2 = find("stz2");
  if (stsz) {
    const fixed = dv.getUint32(stsz.body + 4);
    const count2 = dv.getUint32(stsz.body + 8);
    sizes = new Uint32Array(count2);
    if (fixed !== 0) sizes.fill(fixed);
    else for (let i = 0; i < count2; i++) sizes[i] = dv.getUint32(stsz.body + 12 + i * 4);
  } else if (stz2) {
    const field = bytes[stz2.body + 7];
    const count2 = dv.getUint32(stz2.body + 8);
    sizes = new Uint32Array(count2);
    const at = stz2.body + 12;
    for (let i = 0; i < count2; i++) {
      if (field === 16) sizes[i] = dv.getUint16(at + i * 2);
      else if (field === 8) sizes[i] = bytes[at + i];
      else sizes[i] = bytes[at + (i >> 1)] >> (i & 1 ? 0 : 4) & 15;
    }
  } else return null;
  const count = sizes.length;
  if (count === 0) return null;
  const stco = find("stco");
  const co64 = find("co64");
  const chunkCount = stco ? dv.getUint32(stco.body + 4) : co64 ? dv.getUint32(co64.body + 4) : 0;
  const chunkOffset = (c) => stco ? dv.getUint32(stco.body + 8 + c * 4) : u64(dv, co64.body + 8 + c * 8);
  const stsc = find("stsc");
  if (!stsc || chunkCount === 0) return null;
  const runs = dv.getUint32(stsc.body + 4);
  const offsets = new Float64Array(count);
  let sample = 0;
  for (let r = 0; r < runs && sample < count; r++) {
    const firstChunk = dv.getUint32(stsc.body + 8 + r * 12) - 1;
    const perChunk = dv.getUint32(stsc.body + 12 + r * 12);
    const nextFirst = r + 1 < runs ? dv.getUint32(stsc.body + 8 + (r + 1) * 12) - 1 : chunkCount;
    for (let c = firstChunk; c < nextFirst && c < chunkCount && sample < count; c++) {
      let at = chunkOffset(c);
      for (let k = 0; k < perChunk && sample < count; k++) {
        offsets[sample] = at;
        at += sizes[sample];
        sample++;
      }
    }
  }
  if (sample < count) return null;
  const stts = find("stts");
  if (!stts) return null;
  const dtsTicks = new Float64Array(count);
  let tick = 0;
  let lastDelta = 0;
  sample = 0;
  const sttsRuns = dv.getUint32(stts.body + 4);
  for (let r = 0; r < sttsRuns && sample < count; r++) {
    const n = dv.getUint32(stts.body + 8 + r * 8);
    const delta = dv.getUint32(stts.body + 12 + r * 8);
    for (let k = 0; k < n && sample < count; k++) {
      dtsTicks[sample++] = tick;
      tick += delta;
    }
    lastDelta = delta;
  }
  while (sample < count) {
    dtsTicks[sample++] = tick;
    tick += lastDelta;
  }
  const usPerTick = 1e6 / timescale;
  const dtsUs = new Float64Array(count);
  for (let i = 0; i < count; i++) dtsUs[i] = Math.round((dtsTicks[i] - shiftTicks) * usPerTick);
  let ctsUs = null;
  const ctts = find("ctts");
  if (ctts) {
    ctsUs = new Int32Array(count);
    const cttsRuns = dv.getUint32(ctts.body + 4);
    sample = 0;
    for (let r = 0; r < cttsRuns && sample < count; r++) {
      const n = dv.getUint32(ctts.body + 8 + r * 8);
      const offset = dv.getInt32(ctts.body + 12 + r * 8);
      for (let k = 0; k < n && sample < count; k++, sample++) {
        ctsUs[sample] = Math.round((dtsTicks[sample] + offset - shiftTicks) * usPerTick) - dtsUs[sample];
      }
    }
  }
  let sync = null;
  const stss = find("stss");
  if (stss) {
    sync = new Uint8Array(count);
    const n = dv.getUint32(stss.body + 4);
    for (let k = 0; k < n; k++) {
      const index = dv.getUint32(stss.body + 8 + k * 4) - 1;
      if (index >= 0 && index < count) sync[index] = 1;
    }
  }
  return { number, offsets, sizes, dtsUs, ctsUs, sync, lastDurationUs: Math.round(lastDelta * usPerTick), timedText: timedText2 };
}
function readTrak(bytes, trak, movieTimescale) {
  const dv = view(bytes);
  const tkhd = child(bytes, trak, "tkhd");
  const mdia = child(bytes, trak, "mdia");
  const mdhd = mdia && child(bytes, mdia, "mdhd");
  const hdlr = mdia && child(bytes, mdia, "hdlr");
  const stbl = mdia && path(bytes, mdia, "minf", "stbl");
  if (!tkhd || !mdhd || !hdlr || !stbl) return null;
  const tkhdVersion = bytes[tkhd.body];
  const enabled = (bytes[tkhd.body + 3] & 1) !== 0;
  const number = dv.getUint32(tkhd.body + (tkhdVersion === 1 ? 20 : 12));
  const mdhdVersion = bytes[mdhd.body];
  const timescale = dv.getUint32(mdhd.body + (mdhdVersion === 1 ? 20 : 12));
  const mediaDuration = mdhdVersion === 1 ? u64(dv, mdhd.body + 24) : dv.getUint32(mdhd.body + 16);
  const language = mdhdLanguage(dv.getUint16(mdhd.body + (mdhdVersion === 1 ? 32 : 20)) & 32767);
  if (!timescale) return null;
  const handler = fourcc(bytes, hdlr.body + 8);
  const handlerName = cString(bytes, hdlr.body + 24, hdlr.end);
  const stsd = child(bytes, stbl, "stsd");
  const entry = stsd ? children(bytes, stsd.body + 8, stsd.end)[0] : void 0;
  if (!entry) return null;
  const described = describeEntry(bytes, handler, entry);
  const name = path(bytes, trak, "udta", "name");
  const title = name ? meaningfulName(new TextDecoder().decode(bytes.subarray(name.body, name.end))) : meaningfulName(handlerName);
  let shiftTicks = 0;
  const elst = path(bytes, trak, "edts", "elst");
  if (elst) {
    const version = bytes[elst.body];
    const entries = dv.getUint32(elst.body + 4);
    let empty = 0;
    let media = null;
    const size = version === 1 ? 20 : 12;
    for (let e = 0; e < entries; e++) {
      const at = elst.body + 8 + e * size;
      const segment = version === 1 ? u64(dv, at) : dv.getUint32(at);
      const mediaTime = version === 1 ? i64(dv, at + 8) : dv.getInt32(at + 4);
      if (mediaTime === -1) {
        empty += segment;
        continue;
      }
      media = mediaTime;
      if (e + 1 < entries) trace(`mp4 : piste ${number}, liste de montage \xE0 ${entries} entr\xE9es \u2014 seule la premi\xE8re est suivie`);
      break;
    }
    if (media !== null) shiftTicks = media - Math.round(empty / (movieTimescale || 1) * timescale);
  }
  const track = {
    number,
    type: described.still ? "other" : described.type,
    codecId: described.codecId,
    codecPrivate: described.codecPrivate,
    language,
    name: title,
    isDefault: false,
    isForced: false,
    isHearingImpaired: false,
    // `tkhd` a bien un drapeau « activée », mais il ne dit pas ce que dit FlagEnabled : FFmpeg et
    // la plupart des multiplexeurs n'activent que la première piste de chaque type — c'est un
    // drapeau « par défaut », lu comme tel plus bas. Le reprendre ici aurait retiré du menu six
    // pistes de sous-titres sur six d'un film de la bibliothèque.
    isEnabled: true,
    defaultDurationNs: null
  };
  if (described.video) track.video = described.video;
  if (described.audio) track.audio = described.audio;
  if (described.dolbyVision) track.dolbyVision = described.dolbyVision;
  const indexed = track.type !== "other" && !described.chapters;
  const index = indexed ? sampleTable(bytes, stbl, number, timescale, shiftTicks, track.codecId === "S_TEXT/UTF8") : null;
  const sampleCount = index?.sizes.length ?? 0;
  if (index && sampleCount > 1) {
    const d = index.dtsUs[1] - index.dtsUs[0];
    let constant = true;
    for (let i = 2; i < Math.min(sampleCount, 64) && constant; i++) constant = index.dtsUs[i] - index.dtsUs[i - 1] === d;
    if (constant && track.type === "video") track.defaultDurationNs = d * 1e3;
  }
  return {
    track,
    enabled,
    index,
    still: !!described.still,
    chapters: !!described.chapters,
    sampleCount,
    durationSeconds: mediaDuration / timescale
  };
}
function lowerBound(values, target) {
  let low = 0;
  let high = values.length;
  while (low < high) {
    const mid = low + high >> 1;
    if (values[mid] < target) low = mid + 1;
    else high = mid;
  }
  return low;
}
function buildCues(video, all, starts) {
  const suffixMin = all.map((t) => {
    const m = new Float64Array(t.offsets.length + 1);
    m[t.offsets.length] = Infinity;
    for (let i = t.offsets.length - 1; i >= 0; i--) m[i] = Math.min(t.offsets[i], m[i + 1]);
    return m;
  });
  const cues = [];
  for (let k = 0; k < video.dtsUs.length; k++) {
    if (video.sync && !video.sync[k]) continue;
    const kfDts = video.dtsUs[k];
    let position = Infinity;
    all.forEach((t, i) => {
      position = Math.min(position, suffixMin[i][lowerBound(t.dtsUs, kfDts)]);
    });
    if (!Number.isFinite(position)) continue;
    const known = starts.get(position);
    if (known === void 0 || kfDts < known) starts.set(position, kfDts);
    cues.push({ track: video.number, timeUs: kfDts + (video.ctsUs?.[k] ?? 0), clusterOffset: position });
  }
  cues.sort((a, b) => a.timeUs - b.timeUs);
  return cues;
}
var parsed2 = rememberedHeaders(4);
function forgetMp4Header(key) {
  parsed2.forget(key);
}
async function parseMp4(source, key) {
  const remembered = key === void 0 ? void 0 : parsed2.get(key);
  if (remembered && remembered.segmentEnd <= source.size) return remembered;
  const file = await readMp4(source);
  if (key !== void 0) parsed2.remember(key, file);
  return file;
}
async function readMp4(source) {
  const top = await topLevel(source);
  const moovBox = top.find((b) => b.type === "moov");
  if (top.some((b) => b.type === "moof")) {
    throw new Mp4Refusal("MP4 fragment\xE9 : non pris en charge par ce lecteur.");
  }
  if (!moovBox) throw new Mp4Refusal("MP4 sans description (bo\xEEte moov introuvable).");
  const bytes = await source.read(moovBox.start, moovBox.end - moovBox.start);
  const moov = { type: "moov", start: 0, body: moovBox.body - moovBox.start, end: bytes.length };
  const dv = view(bytes);
  if (child(bytes, moov, "mvex")) throw new Mp4Refusal("MP4 fragment\xE9 : non pris en charge par ce lecteur.");
  const mvhd = child(bytes, moov, "mvhd");
  let movieTimescale = 1e3;
  let movieDuration = 0;
  if (mvhd) {
    const v = bytes[mvhd.body];
    movieTimescale = dv.getUint32(mvhd.body + (v === 1 ? 20 : 12)) || 1e3;
    movieDuration = v === 1 ? u64(dv, mvhd.body + 24) : dv.getUint32(mvhd.body + 16);
  }
  const traks = children(bytes, moov.body, moov.end).filter((b) => b.type === "trak");
  const chapterTracks = /* @__PURE__ */ new Set();
  for (const trak of traks) {
    const chap = path(bytes, trak, "tref", "chap");
    if (chap) for (let at = chap.body; at + 4 <= chap.end; at += 4) chapterTracks.add(dv.getUint32(at));
  }
  const raw = traks.map((trak) => readTrak(bytes, trak, movieTimescale)).filter((t) => t !== null);
  for (const r of raw) {
    if (chapterTracks.has(r.track.number) && r.track.type !== "video" && r.track.type !== "audio") {
      r.track.type = "other";
      r.index = null;
    }
  }
  for (const r of raw) {
    if (r.track.type === "video" && r.sampleCount <= 1) {
      r.track.type = "other";
      r.index = null;
    }
  }
  const withSamples = raw.filter((r) => r.index !== null);
  if (withSamples.length === 0) {
    throw new Mp4Refusal("MP4 fragment\xE9 : non pris en charge par ce lecteur.");
  }
  const videos = withSamples.filter((r) => r.track.type === "video");
  const main = videos.reduce((best, r) => !best || r.sampleCount > best.sampleCount ? r : best, null);
  for (const r of videos) {
    if (r !== main) {
      r.track.type = "other";
      r.index = null;
    }
  }
  for (const type of ["video", "audio", "subtitle"]) {
    const ofType = raw.filter((r) => r.track.type === type);
    const chosen = ofType.find((r) => r.enabled) ?? (type === "subtitle" ? void 0 : ofType[0]);
    if (chosen) chosen.track.isDefault = true;
  }
  const indexes = raw.map((r) => r.index).filter((i) => i !== null);
  const starts = /* @__PURE__ */ new Map();
  const videoIndex = main?.index ?? null;
  const cues = videoIndex ? buildCues(videoIndex, indexes, starts) : [];
  let firstOffset = Infinity;
  for (const index of indexes) for (let i = 0; i < index.offsets.length; i++) firstOffset = Math.min(firstOffset, index.offsets[i]);
  starts.set(firstOffset, -Infinity);
  const durationSeconds = movieDuration > 0 ? movieDuration / movieTimescale : Math.max(0, ...raw.map((r) => r.durationSeconds)) || null;
  const mdat = top.findIndex((b) => b.type === "mdat");
  const moovFirst = mdat < 0 || top.indexOf(moovBox) < mdat;
  trace(
    `mp4 : ${raw.length} pistes, ${indexes.reduce((n, i) => n + i.sizes.length, 0)} \xE9chantillons, ${cues.length} points d'acc\xE8s, moov ${moovFirst ? "en t\xEAte" : "en fin"}`
  );
  return {
    timestampScaleNs: 1e3,
    durationSeconds,
    tracks: raw.map((r) => r.track),
    cues,
    segmentDataStart: 0,
    segmentEnd: source.size,
    firstClusterOffset: firstOffset,
    mp4: { tracks: indexes, starts }
  };
}
var Mp4SampleReader = class {
  constructor(source, file, startOffset) {
    this.source = source;
    this.file = file;
    this.cursors = this.index.tracks.map(() => 0);
    this.seekTo(startOffset);
  }
  source;
  file;
  cursors;
  finished = false;
  get index() {
    return this.file.mp4;
  }
  /** Repart d'une position d'index — celle d'une image clé, ou le début du fichier. */
  seekTo(offset) {
    const tracks = this.index.tracks;
    let from = this.index.starts.get(offset);
    if (from === void 0) {
      from = Infinity;
      for (const t of tracks) {
        for (let i = 0; i < t.offsets.length; i++) {
          if (t.offsets[i] >= offset) {
            from = Math.min(from, t.dtsUs[i]);
            break;
          }
        }
      }
    }
    for (let i = 0; i < tracks.length; i++) {
      this.cursors[i] = from === -Infinity ? 0 : lowerBound(tracks[i].dtsUs, from);
    }
    this.finished = false;
  }
  get exhausted() {
    return this.finished;
  }
  async next() {
    const tracks = this.index.tracks;
    let pick = -1;
    for (let i2 = 0; i2 < tracks.length; i2++) {
      const at = this.cursors[i2];
      if (at >= tracks[i2].dtsUs.length) continue;
      if (pick < 0) {
        pick = i2;
        continue;
      }
      const best = tracks[pick];
      const bestAt = this.cursors[pick];
      const d = tracks[i2].dtsUs[at] - best.dtsUs[bestAt];
      if (d < 0 || d === 0 && tracks[i2].offsets[at] < best.offsets[bestAt]) pick = i2;
    }
    if (pick < 0) {
      this.finished = true;
      return null;
    }
    const track = tracks[pick];
    const i = this.cursors[pick]++;
    let data = await this.source.read(track.offsets[i], track.sizes[i]);
    if (track.timedText) data = timedText(data);
    const durationUs = i + 1 < track.dtsUs.length ? track.dtsUs[i + 1] - track.dtsUs[i] : track.lastDurationUs;
    return {
      trackNumber: track.number,
      timestampUs: track.dtsUs[i] + (track.ctsUs?.[i] ?? 0),
      durationUs,
      isKey: track.sync ? track.sync[i] === 1 : true,
      data
    };
  }
};
function timedText(data) {
  if (data.length < 2) return new Uint8Array(0);
  const length = data[0] << 8 | data[1];
  return data.subarray(2, Math.min(data.length, 2 + length));
}

// src/engine/unreadableZone.ts
var UNREADABLE_ZONE_PREFIX = "zone illisible dans le fichier";
function frenchSeconds(seconds) {
  return (Math.round(Math.max(0, seconds) * 10) / 10).toFixed(1).replace(".", ",");
}
function unreadableZoneMessage(seconds, byteOffset) {
  return `${UNREADABLE_ZONE_PREFIX} vers ${frenchSeconds(seconds)} s (octet ${Math.round(byteOffset)})`;
}
function isUnreadableZoneReason(reason) {
  return typeof reason === "string" && reason.startsWith(UNREADABLE_ZONE_PREFIX);
}
var UnreadableZone = class extends Error {
  constructor(byteOffset, seconds, safeSeconds) {
    super(unreadableZoneMessage(seconds, byteOffset));
    this.byteOffset = byteOffset;
    this.seconds = seconds;
    this.safeSeconds = safeSeconds;
    this.name = "UnreadableZone";
  }
  byteOffset;
  seconds;
  safeSeconds;
};
function isUnreadableZone(error) {
  return error instanceof UnreadableZone || error instanceof Error && error.name === "UnreadableZone" && isUnreadableZoneReason(error.message);
}

// src/engine/sampleReader.ts
var TOP_LEVEL = /* @__PURE__ */ new Set([
  ID.Cluster,
  ID.Cues,
  ID.SeekHead,
  ID.Info,
  ID.Tracks,
  307544935,
  272869232,
  423732329
  /* Attachments */
]);
var SampleReader = class {
  constructor(source, file, startOffset, options = {}) {
    this.source = source;
    this.file = file;
    this.options = options;
    this.cursor = startOffset;
  }
  source;
  file;
  options;
  cursor;
  queue = [];
  finished = false;
  /** Le début de la dernière grappe dont l'horodatage a été lu depuis la dernière reprise (µs). */
  lastClusterUs = null;
  /** Le dernier instant lu depuis la dernière reprise — grappe ou échantillon (µs). */
  lastTimeUs = null;
  /** Restarts reading at a cluster boundary — the offset comes from the cue index. */
  seekTo(offset) {
    this.cursor = offset;
    this.queue = [];
    this.finished = false;
    this.lastClusterUs = null;
    this.lastTimeUs = null;
  }
  get exhausted() {
    return this.finished && this.queue.length === 0;
  }
  async next() {
    while (this.queue.length === 0) {
      if (this.finished) return null;
      await this.readOneCluster();
    }
    return this.queue.shift() ?? null;
  }
  async readOneCluster() {
    if (this.cursor >= this.file.segmentEnd) {
      this.finished = true;
      return;
    }
    const element = await readElementHeader(this.source, this.cursor);
    if (element === UNREADABLE) {
      if (this.strict && this.filmBeyond(this.cursor)) throw this.zone(this.cursor, this.lastClusterUs);
      this.finished = true;
      return;
    }
    if (!element) {
      this.finished = true;
      return;
    }
    if (element.id !== ID.Cluster) {
      if (element.size === null) {
        this.finished = true;
        return;
      }
      this.cursor = element.offset + element.size;
      return;
    }
    const end = element.size === null ? this.file.segmentEnd : Math.min(element.offset + element.size, this.file.segmentEnd);
    let clusterTime = 0;
    let nextTopLevel = null;
    const previousClusterUs = this.lastClusterUs;
    let thisClusterUs = null;
    const unreadable = this.strict ? (offset) => {
      if (element.size !== null || this.filmBeyond(offset)) throw this.zone(offset, thisClusterUs ?? previousClusterUs);
    } : void 0;
    const checkBlock = (data, size, at) => {
      if (unreadable && data.length === size && data.length > 0 && data[0] === 0) unreadable(at);
    };
    await forEachChild(this.source, element.offset, end, async (child2) => {
      if (element.size === null && TOP_LEVEL.has(child2.id)) {
        nextTopLevel = child2.offset - child2.headerSize;
        return "stop";
      }
      switch (child2.id) {
        case ID.Timestamp:
          clusterTime = readUint(await this.source.read(child2.offset, child2.size ?? 0));
          if (this.strict) {
            thisClusterUs = Math.round(clusterTime * this.file.timestampScaleNs / 1e3);
            this.lastClusterUs = thisClusterUs;
            this.noteTime(thisClusterUs);
          }
          return "continue";
        case ID.SimpleBlock: {
          if (child2.size === null) return "stop";
          const data = await this.source.read(child2.offset, child2.size);
          checkBlock(data, child2.size, child2.offset);
          const samples = parseBlock(data, clusterTime, this.file.timestampScaleNs, true, false);
          if (this.strict) for (const sample of samples) this.noteTime(sample.timestampUs);
          this.queue.push(...samples);
          return "continue";
        }
        case ID.BlockGroup: {
          if (child2.size === null) return "stop";
          let block = null;
          let durationTicks = null;
          let hasReference = false;
          await forEachChild(
            this.source,
            child2.offset,
            child2.offset + child2.size,
            async (g) => {
              if (g.id === ID.Block && g.size !== null) {
                block = new Uint8Array(await this.source.read(g.offset, g.size));
                checkBlock(block, g.size, g.offset);
              }
              if (g.id === ID.ReferenceBlock) hasReference = true;
              if (g.id === ID.BlockDuration && g.size !== null) durationTicks = readUint(await this.source.read(g.offset, g.size));
              return "continue";
            },
            // Un groupe a sa taille : ses octets sont déclarés, un en-tête illisible y est une zone.
            unreadable
          );
          if (block) {
            const usPerTick = this.file.timestampScaleNs / 1e3;
            const samples = parseBlock(block, clusterTime, this.file.timestampScaleNs, false, !hasReference);
            for (const sample of samples) {
              if (durationTicks !== null) sample.durationUs = Math.round(durationTicks * usPerTick);
              if (this.strict) this.noteTime(sample.timestampUs);
            }
            this.queue.push(...samples);
          }
          return "continue";
        }
      }
      return "continue";
    }, unreadable);
    this.cursor = element.size !== null ? element.offset + element.size : nextTopLevel ?? this.file.segmentEnd;
  }
  get strict() {
    return this.options.unreadable === "throw";
  }
  noteTime(us) {
    if (this.lastTimeUs === null || us > this.lastTimeUs) this.lastTimeUs = us;
  }
  /**
   * Reste-t-il du film au-delà de cet octet ? Un point d'index qui y est ou plus loin le dit ; sans
   * index, seul un segment de taille déclarée (`segmentSized`) le dit. Sinon — des octets en trop
   * derrière la dernière grappe, un fichier enregistré en direct sans index — la lecture s'arrête
   * comme avant.
   */
  filmBeyond(offset) {
    if (offset >= this.file.segmentEnd) return false;
    if (this.file.cues.length > 0) return this.file.cues.some((cue) => cue.clusterOffset >= offset);
    return this.file.segmentSized === true;
  }
  /** L'instant d'index à cet octet ou avant (µs) — quand rien n'a encore été lu depuis la reprise. */
  cueTimeBefore(offset) {
    let best = null;
    for (const cue of this.file.cues) if (cue.clusterOffset <= offset && (best === null || cue.timeUs > best)) best = cue.timeUs;
    return best;
  }
  zone(offset, safeUs) {
    const fallback = this.cueTimeBefore(offset) ?? 0;
    const safe = safeUs ?? fallback;
    const seen = Math.max(this.lastTimeUs ?? fallback, safe);
    return new UnreadableZone(offset, seen / 1e6, safe / 1e6);
  }
};

// src/engine/codecConfig.ts
function hex(value, digits = 2) {
  return value.toString(16).toUpperCase().padStart(digits, "0");
}
function reverseBits32(value) {
  let out = 0;
  for (let i = 0; i < 32; i++) {
    out = out << 1 | value >>> i & 1;
  }
  return out >>> 0;
}
function hevcCodecString(hvcC) {
  if (hvcC.length < 13) return null;
  const profileSpace = hvcC[1] >> 6 & 3;
  const tier = hvcC[1] >> 5 & 1;
  const profileIdc = hvcC[1] & 31;
  const compatibility = reverseBits32(hvcC[2] << 24 | hvcC[3] << 16 | hvcC[4] << 8 | hvcC[5]);
  const level = hvcC[12];
  const space = ["", "A", "B", "C"][profileSpace];
  const constraints = [];
  for (let i = 6; i <= 11; i++) constraints.push(hex(hvcC[i]));
  while (constraints.length && constraints[constraints.length - 1] === "00") constraints.pop();
  return [
    `hvc1.${space}${profileIdc}`,
    compatibility.toString(16).toUpperCase(),
    `${tier ? "H" : "L"}${level}`,
    ...constraints
  ].join(".");
}
function dolbyVisionInfo(record2) {
  if (record2.length < 5) return null;
  const bits = record2[2] << 8 | record2[3];
  const profile = bits >> 9 & 127;
  const level = bits >> 3 & 63;
  if (profile === 0 || level === 0) return null;
  const pad = (n) => String(n).padStart(2, "0");
  return {
    codec: `dvh1.${pad(profile)}.${pad(level)}`,
    profile,
    level,
    compatibilityId: record2[4] >> 4 & 15
  };
}
function dolbyVisionCodecString(record2) {
  return dolbyVisionInfo(record2)?.codec ?? null;
}
function avcCodecString(avcC) {
  if (avcC.length < 4) return null;
  return `avc1.${hex(avcC[1])}${hex(avcC[2])}${hex(avcC[3])}`.toLowerCase();
}
function audioConfigFor(track) {
  if (track.type !== "audio" || !track.audio) return null;
  const base = { sampleRate: Math.round(track.audio.sampleRate), numberOfChannels: track.audio.channels };
  const priv = track.codecPrivate;
  switch (track.codecId) {
    case "A_AAC":
      return priv ? { codec: "mp4a.40.2", description: priv, ...base } : null;
    case "A_OPUS":
      return { codec: "opus", ...priv ? { description: priv } : {}, ...base };
    case "A_FLAC":
      return { codec: "flac", ...priv ? { description: priv } : {}, ...base };
    case "A_MPEG/L3":
      return { codec: "mp3", ...base };
    case "A_AC3":
      return { codec: "ac-3", ...base };
    case "A_EAC3":
      return { codec: "ec-3", ...base };
    case "A_VORBIS":
      return { codec: "vorbis", ...priv ? { description: priv } : {}, ...base };
    case "A_PCM/INT/LIT":
      return { codec: track.audio.bitDepth === 16 ? "pcm-s16" : "pcm-f32", ...base };
    default:
      return null;
  }
}
function nalLengthSize(codecId, codecPrivate) {
  if (!codecPrivate) return 4;
  if (codecId === "V_MPEGH/ISO/HEVC") return codecPrivate.length > 21 ? (codecPrivate[21] & 3) + 1 : 4;
  if (codecId === "V_MPEG4/ISO/AVC") return codecPrivate.length > 4 ? (codecPrivate[4] & 3) + 1 : 4;
  return 4;
}
function isRandomAccessPoint(data, codecId, lengthSize) {
  const hevc = codecId === "V_MPEGH/ISO/HEVC";
  if (!hevc && codecId !== "V_MPEG4/ISO/AVC") return true;
  let recovery = false;
  for (let at = 0; at + lengthSize + 1 <= data.byteLength; ) {
    let length = 0;
    for (let i = 0; i < lengthSize; i++) length = length * 256 + data[at + i];
    if (length <= 0 || at + lengthSize + length > data.byteLength) break;
    const header = data[at + lengthSize];
    if (hevc) {
      const type = header >> 1 & 63;
      if (type <= 31) return type >= 16 && type <= 23;
    } else {
      const type = header & 31;
      const unit = data.subarray(at + lengthSize, at + lengthSize + length);
      if (type === 6 && avcRecoveryPoint(unit)) recovery = true;
      if (type === 1 || type === 5) return type === 5 || recovery && avcIntraSlice(unit);
    }
    at += lengthSize + length;
  }
  return true;
}
function isRaslPicture(data, codecId, lengthSize) {
  if (codecId !== "V_MPEGH/ISO/HEVC") return false;
  for (let at = 0; at + lengthSize + 1 <= data.byteLength; ) {
    let length = 0;
    for (let i = 0; i < lengthSize; i++) length = length * 256 + data[at + i];
    if (length <= 0 || at + lengthSize + length > data.byteLength) return false;
    const type = data[at + lengthSize] >> 1 & 63;
    if (type <= 31) return type === 8 || type === 9;
    at += lengthSize + length;
  }
  return false;
}
function expGolomb(bytes, startBit) {
  const bit = (i2) => bytes[i2 >> 3] >> 7 - (i2 & 7) & 1;
  const total = bytes.byteLength * 8;
  let i = startBit;
  let zeros = 0;
  while (i < total && bit(i) === 0) {
    zeros += 1;
    i += 1;
    if (zeros > 31) return null;
  }
  if (i >= total) return null;
  i += 1;
  let suffix = 0;
  for (let k = 0; k < zeros; k++) {
    if (i >= total) return null;
    suffix = suffix * 2 + bit(i++);
  }
  return { value: 2 ** zeros - 1 + suffix, next: i };
}
function avcRecoveryPoint(unit) {
  const rbsp = unescapeRbsp(unit);
  let at = 1;
  while (at < rbsp.byteLength && rbsp[at] !== 128) {
    let payloadType = 0;
    while (at < rbsp.byteLength && rbsp[at] === 255) payloadType += rbsp[at++];
    if (at >= rbsp.byteLength) return false;
    payloadType += rbsp[at++];
    let payloadSize = 0;
    while (at < rbsp.byteLength && rbsp[at] === 255) payloadSize += rbsp[at++];
    if (at >= rbsp.byteLength) return false;
    payloadSize += rbsp[at++];
    if (payloadType === 6) {
      const count = expGolomb(rbsp.subarray(at, at + payloadSize), 0);
      return count !== null && count.value === 0;
    }
    at += payloadSize;
  }
  return false;
}
function avcIntraSlice(unit) {
  const header = unescapeRbsp(unit.subarray(1, 17));
  const firstMb = expGolomb(header, 0);
  if (!firstMb) return false;
  const sliceType = expGolomb(header, firstMb.next);
  return sliceType !== null && [2, 4, 7, 9].includes(sliceType.value);
}
function strayUnits(data, codecId, lengthSize) {
  const hevc = codecId === "V_MPEGH/ISO/HEVC";
  if (!hevc && codecId !== "V_MPEG4/ISO/AVC") return null;
  const before = [];
  const after = [];
  for (let at = 0; at + lengthSize + 1 <= data.byteLength; ) {
    let length = 0;
    for (let i = 0; i < lengthSize; i++) length = length * 256 + data[at + i];
    if (length <= 0 || at + lengthSize + length > data.byteLength) return null;
    const header = data[at + lengthSize];
    const unit = data.subarray(at, at + lengthSize + length);
    if (hevc) {
      const type = header >> 1 & 63;
      if (type <= 31) return null;
      const suffix = type === 36 || type === 37 || type === 38 || type === 40 || type >= 45 && type <= 47 || type >= 56;
      (suffix ? before : after).push(unit);
    } else {
      const type = header & 31;
      if (type >= 1 && type <= 5) return null;
      after.push(unit);
    }
    at += lengthSize + length;
  }
  return before.length + after.length > 0 ? { before, after } : null;
}
function withCappedLightLevels(data, lengthSize, capNits) {
  const kept = [];
  let changed = false;
  for (let at = 0; at + lengthSize + 2 <= data.byteLength; ) {
    let length = 0;
    for (let i = 0; i < lengthSize; i++) length = length * 256 + data[at + i];
    if (length <= 0 || at + lengthSize + length > data.byteLength) return data;
    const unit = data.subarray(at, at + lengthSize + length);
    at += lengthSize + length;
    const type = unit[lengthSize] >> 1 & 63;
    if (type === 39) {
      const capped = cappedSei(unit.subarray(lengthSize), capNits);
      if (capped) {
        const prefix = new Uint8Array(lengthSize);
        for (let i = 0, n = capped.length; i < lengthSize; i++) prefix[lengthSize - 1 - i] = n >> 8 * i & 255;
        kept.push(prefix, capped);
        changed = true;
        continue;
      }
    }
    kept.push(unit);
  }
  return changed ? joinBytes(kept) : data;
}
function cappedSei(nal, capNits) {
  const rbsp = unescapeRbsp(nal.subarray(2));
  let at = 0;
  let changed = false;
  while (at < rbsp.length && !(rbsp[at] === 128 && at === rbsp.length - 1)) {
    let type = 0;
    while (at < rbsp.length && rbsp[at] === 255) type += rbsp[at++];
    if (at >= rbsp.length) return null;
    type += rbsp[at++];
    let size = 0;
    while (at < rbsp.length && rbsp[at] === 255) size += rbsp[at++];
    if (at >= rbsp.length) return null;
    size += rbsp[at++];
    if (at + size > rbsp.length) return null;
    const view2 = new DataView(rbsp.buffer, rbsp.byteOffset + at, size);
    if (type === 144 && size >= 4) {
      for (const offset of [0, 2]) {
        if (view2.getUint16(offset) > capNits) {
          view2.setUint16(offset, capNits);
          changed = true;
        }
      }
    } else if (type === 137 && size >= 24) {
      if (view2.getUint32(16) > capNits * 1e4) {
        view2.setUint32(16, capNits * 1e4);
        changed = true;
      }
    }
    at += size;
  }
  if (!changed) return null;
  return joinBytes([nal.subarray(0, 2), escapeRbsp(rbsp)]);
}
function unescapeRbsp(bytes) {
  const out = new Uint8Array(bytes.length);
  let n = 0;
  let zeros = 0;
  for (const byte of bytes) {
    if (zeros >= 2 && byte === 3) {
      zeros = 0;
      continue;
    }
    out[n++] = byte;
    zeros = byte === 0 ? zeros + 1 : 0;
  }
  return out.subarray(0, n);
}
function escapeRbsp(bytes) {
  const out = [];
  let zeros = 0;
  for (const byte of bytes) {
    if (zeros >= 2 && byte <= 3) {
      out.push(3);
      zeros = 0;
    }
    out.push(byte);
    zeros = byte === 0 ? zeros + 1 : 0;
  }
  return Uint8Array.from(out);
}
function joinBytes(parts) {
  const out = new Uint8Array(parts.reduce((n, part) => n + part.byteLength, 0));
  let at = 0;
  for (const part of parts) {
    out.set(part, at);
    at += part.byteLength;
  }
  return out;
}
function av1CodecString(av1C) {
  if (av1C.length < 3 || (av1C[0] & 127) !== 1) return null;
  const profile = av1C[1] >> 5 & 7;
  const level = av1C[1] & 31;
  const tier = av1C[2] >> 7 & 1 ? "H" : "M";
  const highBitDepth = av1C[2] >> 6 & 1;
  const twelveBit = av1C[2] >> 5 & 1;
  const depth = twelveBit && profile === 2 ? 12 : highBitDepth ? 10 : 8;
  return `av01.${profile}.${String(level).padStart(2, "0")}${tier}.${String(depth).padStart(2, "0")}`;
}
var HEVC_PARAMETER_SETS = [32, 33, 34];
function hevcRecordHasParameterSets(hvcC) {
  if (hvcC.length < 23) return false;
  const found = /* @__PURE__ */ new Set();
  let at = 23;
  for (let a = 0; a < hvcC[22] && at + 3 <= hvcC.length; a++) {
    const type = hvcC[at] & 63;
    const count = hvcC[at + 1] << 8 | hvcC[at + 2];
    at += 3;
    for (let n = 0; n < count && at + 2 <= hvcC.length; n++) {
      const length = hvcC[at] << 8 | hvcC[at + 1];
      if (length > 0) found.add(type);
      at += 2 + length;
    }
  }
  return HEVC_PARAMETER_SETS.every((type) => found.has(type));
}
function hevcParameterSets(data, lengthSize) {
  const units = [];
  const seen = /* @__PURE__ */ new Set();
  for (let at = 0; at + lengthSize + 1 <= data.byteLength; ) {
    let length = 0;
    for (let i = 0; i < lengthSize; i++) length = length * 256 + data[at + i];
    if (length <= 0 || at + lengthSize + length > data.byteLength) break;
    const unit = data.subarray(at + lengthSize, at + lengthSize + length);
    const type = unit[0] >> 1 & 63;
    if (HEVC_PARAMETER_SETS.includes(type)) {
      const id = `${type}:${unit.join(",")}`;
      if (!seen.has(id)) {
        seen.add(id);
        units.push(unit.slice());
      }
    }
    at += lengthSize + length;
  }
  const types = new Set(units.map((u) => u[0] >> 1 & 63));
  return HEVC_PARAMETER_SETS.every((type) => types.has(type)) ? units : null;
}
function hevcRecordWithParameterSets(hvcC, units) {
  const arrays = [];
  let count = 0;
  for (const type of HEVC_PARAMETER_SETS) {
    const ofType = units.filter((u) => (u[0] >> 1 & 63) === type);
    if (ofType.length === 0) continue;
    count += 1;
    arrays.push(128 | type, ofType.length >> 8, ofType.length & 255);
    for (const unit of ofType) arrays.push(unit.length >> 8, unit.length & 255, ...unit);
  }
  const record2 = new Uint8Array(23 + arrays.length);
  record2.set(hvcC.subarray(0, 22));
  record2[22] = count;
  record2.set(arrays, 23);
  return record2;
}

// src/engine/mediaFile.ts
async function openMediaFile(source, key) {
  const known = key === void 0 ? void 0 : containers.get(key);
  const mp4 = known !== void 0 ? known === "mp4" : isIsoBaseMedia(await source.read(0, 12));
  if (key !== void 0) {
    containers.delete(key);
    containers.set(key, mp4 ? "mp4" : "matroska");
    while (containers.size > REMEMBERED_CONTAINERS) containers.delete(containers.keys().next().value);
  }
  const file = mp4 ? await parseMp4(source, key) : await parseMatroska(source, key);
  await completeParameterSets(source, file);
  return file;
}
function mediaHeaderKey(streamUrl, fileVersion) {
  return fileVersion ? `${streamUrl}#${fileVersion}` : streamUrl;
}
function forgetMediaHeader(key) {
  containers.delete(key);
  forgetMatroskaHeader(key);
  forgetMp4Header(key);
}
var PARAMETER_SET_SEARCH = 400;
async function completeParameterSets(source, file) {
  for (const track of file.tracks) {
    if (track.type !== "video" || track.codecId !== "V_MPEGH/ISO/HEVC" || !track.codecPrivate) continue;
    if (track.codecPrivate.length < 23 || hevcRecordHasParameterSets(track.codecPrivate)) continue;
    try {
      const lengthSize = nalLengthSize(track.codecId, track.codecPrivate);
      const reader = createSampleReader(source, file, file.firstClusterOffset ?? file.segmentDataStart);
      let found = false;
      for (let n = 0; n < PARAMETER_SET_SEARCH && !found; n++) {
        const sample = await reader.next();
        if (!sample) break;
        if (sample.trackNumber !== track.number) continue;
        const units = hevcParameterSets(sample.data, lengthSize);
        if (!units) continue;
        track.codecPrivate = hevcRecordWithParameterSets(track.codecPrivate, units);
        trace(`en-t\xEAte HEVC sans jeux de param\xE8tres : compl\xE9t\xE9 depuis la premi\xE8re image cl\xE9 (${units.length} unit\xE9s)`);
        found = true;
      }
      if (!found) trace(`en-t\xEAte HEVC sans jeux de param\xE8tres : aucun trouv\xE9 dans les ${PARAMETER_SET_SEARCH} premiers \xE9chantillons`);
    } catch (error) {
      trace(`en-t\xEAte HEVC sans jeux de param\xE8tres : lecture impossible (${error instanceof Error ? error.message : String(error)})`);
    }
  }
}
var containers = /* @__PURE__ */ new Map();
var REMEMBERED_CONTAINERS = 16;
function createSampleReader(source, file, startOffset, options) {
  return file.mp4 ? new Mp4SampleReader(source, file, startOffset) : new SampleReader(source, file, startOffset, options);
}

export {
  configureHost,
  hostBuild,
  withHostHeaders,
  traceReset,
  trace,
  traceText,
  traceElapsed,
  traceRecent,
  networkUnstable,
  subscribeNetworkTrouble,
  diagInterval,
  diagNow,
  diagMedia,
  diagStallFacts,
  CHUNK_SIZE,
  NetworkUnavailable,
  describeNetwork,
  readingAs,
  SessionEnded,
  isReadAbandoned,
  isNetworkFailure,
  holdsHandover,
  holdsPrepared,
  HttpByteSource,
  clusterOffsetForTime,
  cueTimeAfter,
  cueTimeAtOrBefore,
  keptRangeAt,
  isUnreadableZone,
  hevcCodecString,
  dolbyVisionInfo,
  dolbyVisionCodecString,
  avcCodecString,
  audioConfigFor,
  nalLengthSize,
  isRandomAccessPoint,
  isRaslPicture,
  strayUnits,
  withCappedLightLevels,
  joinBytes,
  av1CodecString,
  openMediaFile,
  mediaHeaderKey,
  forgetMediaHeader,
  createSampleReader
};
//# sourceMappingURL=lumen-chunk-RIJONPO7.js.map
